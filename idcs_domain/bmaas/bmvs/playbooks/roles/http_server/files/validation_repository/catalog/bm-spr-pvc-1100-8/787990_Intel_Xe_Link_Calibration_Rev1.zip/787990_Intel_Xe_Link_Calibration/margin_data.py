#!/usr/bin/env python3

#
# Copyright (C) 2023 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""Collect link margin summary data"""

import argparse
import socket
import sys
import time

# Prevent Python from creating cache files for local libraries:
sys.dont_write_bytecode = True

import data
import iaf
import out
import valid_version

# Tool details
SUMMARY = "Collect link margin data"
DETAIL = """
Vary DCC index to collect BER data at various margin settings, then
both DCC index and interpolator settings to collect BER data at four
points. Pass criteria is no long correctable or uncorrectable error
sequences encountered. Require multiple passes for a configuration
and margin to be considered valid.
"""

# Block size, symbol size, longest correctible error by FEC mode:
FEC_INFO = {
    "F132": (132, 8, 2),
    "F528": (528, 10, 8),
    "F544": (544, 10, 15),
}
# To ensure consistency, insist on heavy FEC only
SUPPORTED_FEC = "F528"
CERR_LEN = FEC_INFO[SUPPORTED_FEC][2]

# other constants
NUM_LANES = 4
NO_MARGIN = 0
MIDDLE_DCC_INDEX = 7
FORMAT_CHOICES = ['csv', 'spaces', 'table', 'unix', 'tabs', 'list']
SCRIPT_DEVELOPMENT_MODE = False


class LinkMarginOpts:
    """
    Options for margin data collection. To specify options for
    perform_margin_test(), inherit this class and override.
    """
    # Also used to set parse_command_line() defaults:
    output = "margin_summary.csv"
    results = "margin_results.csv"
    format = FORMAT_CHOICES[0]
    desired_margin = 5
    minimum_margin = 3
    passes_needed = 3
    link_wait_timeout = 120
    sample_interval = 1
    settle_interval = 2
    step_interval = 1
    host_name = socket.gethostname()
    device = ["all:all:all"]
    link = []

    # Set but not used by parse_command_line():
    square = False
    diamond = False
    rhombus = False
    keep_going = False
    lane = None
    only_headers = False
    dry_run = False
    verbose = False
    quiet = False


def flat_zip(*args):
    """zip into a single flat list"""
    return [i for s in zip(*args) for i in s]


class MarginTables:
    """Summary and detail tables for margin testing"""

    CONFIGS = [(3, 0), (3, 1), (7, 0), (7, 1), (1, 0), (1, 1)]
    DETAILS = [
        "hostname",
        "tx lane",
        "sweep",
        "corner",
        "ticks",
        "delay",
        "revpd",
        "starting dcc",
        "min dcc",
        "max dcc",
        "starting interp",
        "min interp",
        "max interp",
        "tx guid",
        "rx lane",
        "rx guid",
        "start ok",
        "sweep good",
        *map(lambda i: f"fec cerr{i}", range(1, 6)),
        "sweep errs",
        "sweep ok",
        "p1 errors",
        "p1 ok",
        "p2 errors",
        "p2 ok",
        "p3 errors",
        "p3 ok",
        "p4 errors",
        "p4 ok",
        "still up",
    ]

    def __init__(self, opts=LinkMarginOpts):
        self.desired_tunings = [(opts.desired_margin, t, r) for t, r in self.CONFIGS]
        self.minimum_tunings = [(opts.minimum_margin, t, r) for t, r in self.CONFIGS]
        self.tunings = self.desired_tunings + self.minimum_tunings
        summaries = [
            "host name",
            "tx lane" + " " * 8,
            "result",
            "delay",
            "revpd",
            "testing details" + " " * 48,
            "tx guid" + " " * 9,
            "rx lane" + " " * 8,
            "rx guid" + " " * 9,
        ]
        self.summary = data.Writer(opts.output, *summaries, format=opts.format)
        self.detail = data.Writer(opts.results, *self.DETAILS, format=opts.format)
        self.passes = 0
        self.failures = 0

    def add_details(self, port, lane, results, opts=LinkMarginOpts):
        """Add an entry to the detailed results table"""

        self.detail.add_row(
            opts.host_name,
            port.lane_id(lane),
            *["PASS" if r else "FAIL" for r in results],
            port.current_margin,
            port.current_delay,
            port.current_revpd,
            port.starting_dcc,
            port.min_dcc,
            port.max_dcc,
            port.starting_interp,
            port.min_interp,
            port.max_interp,
            port.subdevice.guid,
            port.neighbor.lane_id(port.tx_swizzle[lane]),
            port.neighbor.subdevice.guid,
            port.start_ok,
            *port.sweep_counts[:6],
            sum(port.sweep_counts[6:]),
            port.sweep_ok,
            *flat_zip(port.corner_totals, port.corner_ok),
            port.tx_width == 4
        )

    def add_summary(self, port, lane, opts=LinkMarginOpts):
        """Add an entry to the summary table"""
        if port.margin > 0:
            self.passes += 1
        else:
            self.failures += 1
        rx_lane = port.tx_swizzle[lane]
        # there are 3 pairs of delay settings though the encoding supports 4
        reserved = ["-", "-"]
        high_corner = [port.corner_results[t] for t in self.desired_tunings] + reserved
        high_sweep = [port.sweep_results[t] for t in self.desired_tunings] + reserved
        good_corner = [port.corner_results[t] for t in self.minimum_tunings] + reserved
        good_sweep = [port.sweep_results[t] for t in self.minimum_tunings] + reserved
        testing_details = high_corner + high_sweep + good_corner + good_sweep
        self.summary.add_row(
            opts.host_name,
            port.lane_id(lane),
            "PASS" if port.margin > 0 else "FAIL",
            port.delay,
            port.revpd,
            " ".join(str(count) for count in testing_details),
            port.subdevice.guid,
            port.neighbor.lane_id(rx_lane),
            port.neighbor.subdevice.guid
        )

    def display_totals(self):
        """Report total counts"""
        out.pr("Lane results summary:")
        out.pr(f"{self.failures} FAIL")
        out.pr(f"{self.passes} PASS")


def check_opts(opts, output_file, dflt):
    """validate and clean up option values"""
    if not SCRIPT_DEVELOPMENT_MODE:
        opts.desired_margin = dflt.desired_margin
        opts.minimum_margin = dflt.minimum_margin
        opts.sample_interval = dflt.sample_interval
        opts.settle_interval = dflt.settle_interval
        opts.step_interval = dflt.step_interval
        opts.square = dflt.square
        opts.diamond = dflt.diamond
        opts.rhombus = dflt.rhombus

    if opts.desired_margin < opts.minimum_margin:
        out.error("desired margin cannot be less than minimum margin")

    if isinstance(opts.output, str):
        opts.output = output_file(opts.output)

    if isinstance(opts.results, str):
        opts.results = output_file(opts.results)

    if not opts.link:
        opts.link = dflt.link

    if not opts.device:
        opts.device = []
        for link in opts.link:
            opts.device += link.split("-", 1)

    # Use default value if device not specified
    if not opts.device:
        opts.device = dflt.device

    return opts


def parse_command_line(dflt=LinkMarginOpts):
    """Parse command line options"""

    def help_format(prog):
        """preferred help format"""
        return argparse.HelpFormatter(prog, max_help_position=40)

    def int_in_range(txt, low, high):
        """constrained integer value"""
        val = int(txt, 0)
        if low <= val <= high:
            return val
        raise ValueError(f"{val} not in range [{low}:{high}]")

    output_file = argparse.FileType('w')
    version = valid_version.Version(__file__)
    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
        '-o', '--output',
        type=output_file,
        default=dflt.output,
        metavar="FILE",
        help=f"output data to file (default: {dflt.output})"
    )

    parser.add_argument(
        '-r', '--results',
        type=output_file,
        default=dflt.results,
        metavar="FILE",
        help=f"output detailed test results to file (default: {dflt.results})"
    )

    parser.add_argument(
        '-f', '--format',
        choices=FORMAT_CHOICES,
        default=dflt.format,
        metavar="FORMAT",
        help=f"format: csv/spaces/table/unix/tabs/list (default: {dflt.format})"
    )

    if SCRIPT_DEVELOPMENT_MODE:
        parser.add_argument(
            '-d', '--desired-margin',
            type=lambda x: int_in_range(x, 1, 7),
            default=dflt.desired_margin,
            metavar="N",
            help=f"desired margin (1-7, default: {dflt.desired_margin})"
        )

        parser.add_argument(
            '-m', '--minimum-margin',
            type=lambda x: int_in_range(x, 1, 7),
            default=dflt.minimum_margin,
            metavar="N",
            help=f"minimum margin (1-7, default: {dflt.minimum_margin})"
        )

    parser.add_argument(
        '-p', '--passes-needed',
        type=lambda x: int_in_range(x, 1, 20),
        default=dflt.passes_needed,
        metavar="N",
        help=f"passes needed for success (1-20, default: {dflt.passes_needed})"
    )

    parser.add_argument(
        '--link-wait-timeout',
        type=lambda x: int_in_range(x, 0, 300),
        default=dflt.link_wait_timeout,
        metavar="SEC",
        help=f"seconds to wait for link bounce (default: {dflt.link_wait_timeout})"
    )

    if SCRIPT_DEVELOPMENT_MODE:
        parser.add_argument(
            '--sample-interval', '--dwell',
            type=lambda x: int_in_range(x, 0, 300),
            default=dflt.sample_interval,
            metavar="SEC",
            help=f"seconds to gather error data (default: {dflt.sample_interval})"
        )

        parser.add_argument(
            '--settle-interval',
            type=lambda x: int_in_range(x, 0, 300),
            default=dflt.settle_interval,
            metavar="SEC",
            help=f"seconds to wait around bounce operations (default: {dflt.settle_interval})"
        )

        parser.add_argument(
            '--step-interval',
            type=lambda x: int_in_range(x, 0, 1000),
            default=dflt.step_interval,
            metavar="MS",
            help=f"milliseconds between DCC steps (default: {dflt.step_interval})"
        )

    parser.add_argument(
        '--host-name',
        default=dflt.host_name,
        metavar="HOST",
        help=f"specify host name to use in output (default: {dflt.host_name})"
    )

    parser.add_argument(
        '--device',
        action='append',
        metavar="DEV_OR_PORT",
        help="collect data for device[:subdevice[:port]] (default: all:all:all)"
    )

    parser.add_argument(
        '--link',
        action='append',
        metavar="PORT-PORT",
        help="specify port or neighbor port pairs (default: all ports)"
    )

    if SCRIPT_DEVELOPMENT_MODE:
        parser.add_argument(
            '--square',
            action='store_true',
            help="Limit interp margining to min/max from margined DCC sweep"
        )

        parser.add_argument(
            '--diamond',
            action='store_true',
            help="use diamond-shaped region for four point test"
        )

        parser.add_argument(
            '--rhombus',
            action='store_true',
            help="use rhombus-shaped region for four point test"
        )

    parser.add_argument(
        '--keep-going',
        action='store_true',
        help="try all possible configurations even after one passes"
    )

    parser.add_argument(
        '--lane',
        type=lambda x: int_in_range(x, 0, 7),
        metavar="MASK",
        help="test only one lane (0-3 forward, 4-7 reverse; default: test all)"
    )

    parser.add_argument(
        '--only-headers',
        action='store_true',
        help="only print the row headers and exit"
    )

    parser.add_argument(
        '--dry-run',
        action='store_true',
        help="only display the ports to be tested and exit"
    )

    parser.add_argument(
        '--verbose',
        action='store_true',
        help="output extra informational messages"
    )

    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help="suppress some informational messages"
    )

    parser.add_argument(
        '-v', '--version',
        action='version',
        version=str(version),
        help="report version and exit"
    )

    opts = parser.parse_args()
    return check_opts(opts, output_file, dflt)


def wait_for_port_phy_state(state, ports_to_test, opts=LinkMarginOpts):
    """Wait for ports and their neighbors to reach a given PHY state"""
    remaining = [*ports_to_test] + [port.neighbor for port in ports_to_test]
    start_time = time.time()
    while time.time() - start_time <= opts.link_wait_timeout and remaining:
        time.sleep(1)
        next_remaining = []
        for port in remaining:
            if port.update().phy_state != state:
                next_remaining.append(port)
        remaining = next_remaining

    if opts.verbose and remaining:
        out.warn(f"Timeout reaching {state}: {[p.ident for p in remaining]}")


def wait_for_ports_down(ports_to_test, opts=LinkMarginOpts):
    """Wait for ports and their neighbors to go down"""
    wait_for_port_phy_state("DISABLED", ports_to_test, opts)


def wait_for_ports_up(ports_to_test, opts=LinkMarginOpts):
    """Wait for ports and their neighbors to come up"""
    wait_for_port_phy_state("LINKUP", ports_to_test, opts)


def wait_for_link_settle(opts=LinkMarginOpts):
    """wait for the settle interval"""
    time.sleep(opts.settle_interval)


def bounce_links(ports_to_test, opts=LinkMarginOpts):
    """bounce a set of ports and their neighbors"""

    wait_for_link_settle(opts)

    for port in ports_to_test:
        port.disable_pair()

    wait_for_ports_down(ports_to_test, opts)

    wait_for_link_settle(opts)

    for port in ports_to_test:
        port.up_at = -1
        port.enable_pair()

    wait_for_ports_up(ports_to_test, opts)


def check_link_states(ports_to_test, opts=LinkMarginOpts):
    """verify initial link states"""
    wait_for_link_settle(opts)

    for port in ports_to_test:
        port.start_ok = port.update().tx_width == 4
        if port.start_ok and port.fec_mode != port.initial_fec_mode:
            details = f"during bounce, {port.phy_state}/{port.log_state}"
            out.warn(f"{port.ident} switched to FEC mode {port.fec_mode} ({details})")


def list_ports(ports, file=sys.stdout):
    """Summary port listing"""

    def _p(port):
        """port identifier"""
        if not port:
            return "UNKNOWN"
        return port.ident

    table = data.Writer(file,
                        "txPort" + " " * 8,
                        "width",
                        "health  ",
                        "fec_mode",
                        "rxPort" + " " * 8,
                        format="table")

    for port in ports:
        table.add_row(_p(port), port.tx_width, port.health, port.fec_mode, _p(port.neighbor))


def check_tx_ports(ports, opts=LinkMarginOpts):
    """Check that requested ports are in a valid state to begin"""
    used_ports = []
    unused_ports = []

    for ident, port in ports.items():
        # list_ports() shows the cause if any of these fail:
        if (port.up() and port.neighbor and port.tx_width == 4 and
                port.fec_mode == port.initial_fec_mode):
            if not 0 < int(port.subdevice.guid, 16) < 0xffffffffffffffff:
                # this should never fail: issue an explicit warning if it does
                out.warn(f"{port.ident} has illegal GUID {port.subdevice.guid}")
            else:
                # all checks passed, indicate usable and move to next port
                used_ports.append(ident)
                continue
        # one or more checks failed, indicate port is unusable
        unused_ports.append(ident)

    if used_ports and (opts.verbose or opts.dry_run):
        out.pr("Tuning the following ports:")
        list_ports((ports[p] for p in used_ports))

    if unused_ports:
        out.warn("The following ports cannot be tuned now:")
        list_ports((ports[p] for p in unused_ports), file=sys.stderr)
        out.warn("To continue, use --device/--link to select usable ports")
        out.error("Stopping...")

    if not used_ports:
        out.error("No ports selected for tuning")


def identify_requested_ports(devs, opts=LinkMarginOpts):
    """extract list of requested ports from device hierarchy"""

    def add_selected_ports(requested_ports, subdev, sel):
        # port selectors already match port ids
        port_sel = sel[2] if sel[2:] else "all"
        for pname, port in subdev.ports.items():
            if port_sel in [pname, "all"]:
                requested_ports[port.ident] = port

    def add_selected_subdevices(requested_ports, dev, sel):
        # normalize subdevice selectors to match subdevice ids
        sd_sel = "sd." + sel[1] if sel[1:] else "sd.all"
        for sdname, subdev in dev.sds.items():
            if sd_sel in [sdname, "sd.all"]:
                add_selected_ports(requested_ports, subdev, sel)

    def add_selected_devices(requested_ports, devs, sel):
        # normalize numeric device selectors to match fabric ids
        try:
            dev_sel = f"0x{int(sel[0], 16):08x}"
        except ValueError:
            dev_sel = sel[0]

        for devname, dev in devs.items():
            if dev_sel in [devname, dev.fabric_id, "all"]:
                add_selected_subdevices(requested_ports, dev, sel)

    requested_ports = {}
    for sel in [device.split(":") for device in opts.device]:
        add_selected_devices(requested_ports, devs, sel)

    # set neighbor data if requested
    for link in [lnk.split("-", 1) for lnk in opts.link]:
        if len(link) < 2:
            continue
        try:
            port1, port2 = [iaf.Port.find(port) for port in link]
        except (KeyError, ValueError):
            out.warn(f"Unrecognized port id in {'-'.join(link)}")
            continue
        for src, dst in [(port1, port2), (port2, port1)]:
            if src.neighbor and src.neighbor != dst:
                out.warn(src.ident,
                         "neighbor", src.neighbor.ident,
                         "overridden with", dst.ident)
            src.neighbor = dst

    check_tx_ports(requested_ports, opts)

    return requested_ports


def deswizzle(port):
    """compute swizzle from Tx perspective"""

    if None in port.rx_swizzle:
        out.error("Incomplete swizzle information in {port.ident}")

    return {d: i for i, d in enumerate(port.rx_swizzle)}


def split_port_list(tx_ports, opts=LinkMarginOpts):
    """split port list in two"""
    tune_first = []
    tune_second = []
    rx_ports = {}

    for ident in tx_ports.keys():
        if ident in rx_ports:
            tune_second.append(ident)
        else:
            tune_first.append(ident)
        rx_ports[tx_ports[ident].neighbor.ident] = tx_ports[ident].neighbor
        tx_ports[ident].tx_swizzle = deswizzle(tx_ports[ident].neighbor)

    # determine outer iteration values (port lists, lanes)
    if opts.lane is None:
        selected_ident_lists = [tune_first, tune_second]
        selected_lanes = range(NUM_LANES)
    elif opts.lane < 4:
        selected_ident_lists = [tune_first]
        selected_lanes = [opts.lane]
    else:
        selected_ident_lists = [tune_second]
        selected_lanes = [opts.lane - 4]

    return (selected_ident_lists, selected_lanes)


def save_tunings(ports):
    """set aside margining settings to be restored between tests"""
    def dcc_idx(port, lane):
        """Get DCC index with a fallback in case of invalid data"""
        try:
            return port.get_tx_dcc_index(lane)
        except KeyError as key:
            out.warn(f"{port.lane_id(lane)} bad initial DCCP/DCCNB: {key}")
            return MIDDLE_DCC_INDEX

    for port in ports.values():
        port.maint0 = port.get_maint_mode()
        port.tx_dcc_idx0 = [dcc_idx(port, i) for i in range(NUM_LANES)]
        port.tx_dcc_margin_params0 = port.get_tx_dcc_margin_params()


def set_tunings(lane, ports):
    """Set tuning values to next set to try"""
    for port in ports:
        margin, delay, revpd = current_tunings = port.tunings_to_try[0]
        if port.sweep_results[current_tunings] is None:
            port.sweep_results[current_tunings] = 0
        if port.corner_results[current_tunings] is None:
            port.corner_results[current_tunings] = 0
        port.set_maint_mode(1)
        port.set_tx_dcc_margin_lane_params(lane, delay, revpd)
        port.current_margin = margin
        port.current_delay = delay
        port.current_revpd = revpd


def restore_tunings(ports):
    """restore margining settings between tests"""
    for port in ports:
        port.set_maint_mode(port.maint0)
        for lane in range(NUM_LANES):
            port.set_tx_dcc_index(lane, port.tx_dcc_idx0[lane])
        port.set_tx_dcc_margin_params(port.tx_dcc_margin_params0)


def start_error_counters(ports_to_test):
    """start measuring errors from here"""
    for port in ports_to_test:
        port.start_ldc = port.update().link_down_count
        port.neighbor.update().start_lcb()


def wait_for_sweep_step(opts=LinkMarginOpts):
    """wait for the step interval"""
    time.sleep(opts.step_interval / 1000.0)


def perform_sweeps(lane, ports_to_test, opts=LinkMarginOpts):
    """sweep DCC to trigger errors"""
    for port in ports_to_test:
        try:
            cur_dcc = port.get_tx_dcc_index(lane)
        except KeyError as key:
            if port.update().tx_width == 4:
                out.warn(f"{port.lane_id(lane)} sweep had bad DCCP/DCCNB: {key}")
            port.disable_pair()
            cur_dcc = MIDDLE_DCC_INDEX
        port.starting_dcc = cur_dcc
        port.min_dcc = min_dcc = max(0, cur_dcc - port.current_margin)
        port.max_dcc = max_dcc = min(14, cur_dcc + port.current_margin)
        port.interp_vals = []
        step_dcc = 1

        for _ in range(2 * (max_dcc - min_dcc)):
            if cur_dcc >= max_dcc:
                step_dcc = -1
            if cur_dcc <= min_dcc:
                step_dcc = 1

            cur_dcc += step_dcc
            port.set_tx_dcc_index(lane, cur_dcc)
            wait_for_sweep_step(opts)

            port.interp_vals.append(int(port.get_tx_dcc_interp(lane)["tx_interp2_ctl"]))


def wait_for_margin_data(opts=LinkMarginOpts):
    """wait for sample data to be collected"""
    time.sleep(opts.sample_interval)


def error_counts(tx_port, when):
    """collect/normalize error counts for a channel"""
    rx_port = tx_port.neighbor
    tx_port.update()
    rx_port.update().update_lcb()

    start_ldc, current_ldc = tx_port.start_ldc, tx_port.link_down_count

    lane_ok = tx_port.tx_width == 4 and start_ldc == current_ldc

    if tx_port.fec_mode == "NONE":
        counts = [rx_port.good_ltp] + [0] * CERR_LEN + [rx_port.total_crc_err]
    else:
        counts = [rx_port.good_feccw]
        for i in range(1, CERR_LEN + 1):
            counts.append(rx_port.fec_cerr[i])
        counts.append(rx_port.fec_uerr_cnt)

    if lane_ok and sum(counts[6:]) < 1 and tx_port.fec_mode != tx_port.initial_fec_mode:
        details = f"during {when}, {tx_port.phy_state}/{tx_port.log_state}"
        out.warn(f"{tx_port.ident} switched to FEC mode {tx_port.fec_mode} ({details})")

    return lane_ok, counts


def compute_normalized_interp_val_range(port):
    """Find min/max port interp_vals in modulo space, adjusting for wrapping"""
    vals = sorted(port.interp_vals)
    # if normalization not needed, min/max are beginning/end of vals
    min_index = 0
    max_index = len(vals) - 1
    # gap from max to min in modulo space
    max_gap = vals[min_index] + 128 - vals[max_index]
    # look for gaps between other pairs of adjacent values
    other_max_index_candidates = range(max_index)
    for max_index_candidate in other_max_index_candidates:
        min_index_candidate = max_index_candidate + 1
        gap = vals[min_index_candidate] - vals[max_index_candidate]
        if gap > max_gap:
            # larger gap, reset max/min to surround it (normalization needed)
            max_gap = gap
            max_index = max_index_candidate
            min_index = min_index_candidate
    port.min_interp = vals[min_index]
    port.max_interp = vals[max_index]
    if port.max_interp < port.min_interp:
        # normalization needed, adjust max to be higher than min
        port.max_interp += 128
    if port.starting_interp < port.min_interp:
        # normalization moved min after starting value, adjust accordingly
        port.starting_interp += 128


def collect_four_point_data(ports_to_test, point, opts=LinkMarginOpts):
    """gather data for current point"""
    start_error_counters(ports_to_test)

    wait_for_margin_data(opts)

    for port in ports_to_test:
        lane_ok, counts = error_counts(port, f"corner {point}")
        port.corner_ok.append(lane_ok)
        port.corner_counts.append(counts)
        port.corner_totals.append(sum(counts[6:]))


def four_point_diamond_test(lane, ports_to_test, opts=LinkMarginOpts):
    """collect margin data for diamond-shaped four-point test"""

    # four point test, point 1 (min interp, starting dcc)
    for port in ports_to_test:
        interp = port.starting_interp
        port.set_tx_dcc_override_interp(lane, interp)
        port.set_tx_dcc_override_interp_enable(lane, True)
        while interp > port.min_interp:
            interp -= 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 1, opts)

    # four point test, point 2 (max interp, starting dcc)
    for port in ports_to_test:
        interp = port.min_interp
        while interp < port.max_interp:
            interp += 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 2, opts)

    # four point test, point 3 (min dcc, starting interp)
    for port in ports_to_test:
        interp = port.max_interp
        while interp > port.starting_interp:
            interp -= 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

        dcc_idx = port.starting_dcc
        while dcc_idx > port.min_dcc:
            dcc_idx -= 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 3, opts)

    # four point test, point 4 (max dcc, starting interp)
    for port in ports_to_test:
        dcc_idx = port.min_dcc
        while dcc_idx < port.max_dcc:
            dcc_idx += 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 4, opts)

    # back to start (starting interp, starting dcc)
    for port in ports_to_test:
        dcc_idx = port.max_dcc
        while dcc_idx > port.starting_dcc:
            dcc_idx -= 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)


def four_point_rhombus_test(lane, ports_to_test, opts=LinkMarginOpts):
    """collect margin data for rhombus-shaped four-point test"""

    # four point test, point 1 (min interp, min dcc)
    for port in ports_to_test:
        interp = port.starting_interp
        port.set_tx_dcc_override_interp(lane, interp)
        port.set_tx_dcc_override_interp_enable(lane, True)

        dcc_idx = port.starting_dcc
        while dcc_idx > port.min_dcc:
            dcc_idx -= 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

        while interp > port.min_interp:
            interp -= 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 1, opts)

    # four point test, point 2 (starting interp, min dcc)
    for port in ports_to_test:
        interp = port.min_interp
        while interp < port.starting_interp:
            interp += 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 2, opts)

    # four point test, point 3 (starting interp, max dcc)
    for port in ports_to_test:
        dcc_idx = port.min_dcc
        while dcc_idx < port.max_dcc:
            dcc_idx += 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 3, opts)

    # four point test, point 4 (max interp, max dcc)
    for port in ports_to_test:
        interp = port.starting_interp
        while interp < port.max_interp:
            interp += 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 4, opts)

    # back to start (starting interp, starting dcc)
    for port in ports_to_test:
        interp = port.max_interp
        while interp > port.starting_interp:
            interp -= 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

        dcc_idx = port.max_dcc
        while dcc_idx > port.starting_dcc:
            dcc_idx -= 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)


def four_point_edges_test(lane, ports_to_test, opts=LinkMarginOpts):
    """collect margin data for original four-point test"""

    # four point test, point 1 (min interp, min dcc)
    for port in ports_to_test:
        interp = port.starting_interp
        port.set_tx_dcc_override_interp(lane, interp)
        port.set_tx_dcc_override_interp_enable(lane, True)
        while interp > port.min_interp:
            interp -= 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

        dcc_idx = port.starting_dcc
        while dcc_idx > port.min_dcc:
            dcc_idx -= 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 1, opts)

    # four point test, point 2 (min interp, max dcc)
    for port in ports_to_test:
        dcc_idx = port.min_dcc
        while dcc_idx < port.max_dcc:
            dcc_idx += 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 2, opts)

    # four point test, point 3 (max interp, max dcc)
    for port in ports_to_test:
        interp = port.min_interp
        while interp < port.max_interp:
            interp += 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 3, opts)

    # four point test, point 4 (max interp, min dcc)
    for port in ports_to_test:
        dcc_idx = port.max_dcc
        while dcc_idx > port.min_dcc:
            dcc_idx -= 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

    collect_four_point_data(ports_to_test, 4, opts)

    # back to start (starting interp, starting dcc)
    for port in ports_to_test:
        dcc_idx = port.min_dcc
        while dcc_idx < port.starting_dcc:
            dcc_idx += 1
            port.set_tx_dcc_index(lane, dcc_idx)
            wait_for_sweep_step(opts)

        interp = port.max_interp
        while interp > port.starting_interp:
            interp -= 1
            port.set_tx_dcc_override_interp(lane, interp)
            wait_for_sweep_step(opts)


def collect_results(tables, port, lane, opts=LinkMarginOpts):
    """collect results for current port"""
    long_errs = sum(port.sweep_counts[6:])
    sweep_passed = port.start_ok and (long_errs < 1) and port.sweep_ok
    corner_passed = sweep_passed and all(port.corner_ok)

    current = port.tunings_to_try[0]

    tables.add_details(port, lane, [sweep_passed, corner_passed], opts)

    if sweep_passed:
        port.sweep_results[current] += 1
        if port.sweep_results[current] >= opts.passes_needed and not port.margin:
            # sweep pass: fallback if corner testing fails at this margin
            port.margin = port.current_margin
            port.delay = port.current_delay
            port.revpd = port.current_revpd

        if corner_passed:
            port.corner_results[current] += 1
            if port.corner_results[current] >= opts.passes_needed:
                # corner pass: prefer this result to fallback results
                previous = (port.margin, port.delay, port.revpd)
                if port.corner_results[previous] < opts.passes_needed:
                    port.margin = port.current_margin
                    port.delay = port.current_delay
                    port.revpd = port.current_revpd
                if opts.keep_going:
                    port.tunings_to_try.pop(0)
                else:
                    for untried in port.tunings_to_try[1:]:
                        port.sweep_results[untried] = "-"
                        port.corner_results[untried] = "-"
                    port.tunings_to_try = []
                return

        if port.sweep_results[current] < opts.passes_needed:
            return

    port.tunings_to_try.pop(0)

    if len(port.tunings_to_try) == len(tables.CONFIGS) and port.margin and not opts.keep_going:
        # before checking minimum margin, stop if there was a valid sweep
        for untried in port.tunings_to_try:
            port.sweep_results[untried] = "-"
            port.corner_results[untried] = "-"
        port.tunings_to_try = []


def collect_margin_data(tables, lane, ports_to_test, opts=LinkMarginOpts):
    """collect all margin data"""

    # collect dcc sweep margin data and prepare for four point test
    for port in ports_to_test:
        lane_ok, counts = error_counts(port, "sweep")
        port.sweep_ok = lane_ok
        port.sweep_counts = counts
        port.starting_interp = int(port.get_tx_dcc_interp(lane)['tx_interp2_ctl'])
        compute_normalized_interp_val_range(port)
        if not opts.square:
            port.min_interp -= port.current_margin
            port.max_interp += port.current_margin
        port.corner_ok = []
        port.corner_counts = []
        port.corner_totals = []

    if opts.diamond:
        four_point_diamond_test(lane, ports_to_test, opts)
    elif opts.rhombus:
        four_point_rhombus_test(lane, ports_to_test, opts)
    else:
        four_point_edges_test(lane, ports_to_test, opts)

    # end of four point test, restore values
    for port in ports_to_test:
        port.set_tx_dcc_override_interp_enable(lane, False)
        port.set_tx_dcc_index(lane, port.starting_dcc)

    # collect results and stop at first passing result per port
    for port in ports_to_test:
        collect_results(tables, port, lane, opts)


def perform_margin_test(opts=LinkMarginOpts):
    """collect all margin data"""

    if opts.only_headers:
        MarginTables(opts)
        return

    # configure system as needed (will auto-restore on exit)
    iaf.disable_flapping_detection()
    iaf.disable_routing()

    # determine which ports are being requested and split into two lists
    tx_ports = identify_requested_ports(iaf.get_devs(), opts)
    selected_ident_lists, selected_lanes = split_port_list(tx_ports, opts)

    if opts.dry_run:
        return

    tables = MarginTables(opts)
    step_count = len(selected_ident_lists) * len(selected_lanes)

    # record initial settings, to restore between test cycles
    save_tunings(tx_ports)

    # looping is by port set (first/second), then lane number, then port
    current_step = 0
    for ident_list in selected_ident_lists:
        for tx_lane in selected_lanes:
            if opts.output != sys.stdout and not opts.quiet:
                out.pr(f"Completed {current_step}/{step_count} steps")
            current_step += 1

            # start with full list and copy of tunings to try on each port
            ports_to_test = [tx_ports[ident] for ident in ident_list]
            for port in ports_to_test:
                port.tunings_to_try = [*tables.tunings]
                port.sweep_results = {t: None for t in tables.tunings}
                port.corner_results = {t: None for t in tables.tunings}
                port.margin = NO_MARGIN
                port.delay = "?"
                port.revpd = "?"

            # while there are ports to test, test the next set of tunings
            ports_left = [*ports_to_test]
            while ports_left:
                set_tunings(tx_lane, ports_left)
                bounce_links(ports_left, opts)
                check_link_states(ports_left, opts)
                start_error_counters(ports_left)
                perform_sweeps(tx_lane, ports_left, opts)
                wait_for_margin_data(opts)
                collect_margin_data(tables, tx_lane, ports_left, opts)
                # filter out ports with no tunings left to try
                ports_left = [p for p in ports_left if p.tunings_to_try]

            # report results and restore tunings before moving to next lane
            for port in ports_to_test:
                tables.add_summary(port, tx_lane, opts)

            restore_tunings(ports_to_test)

    if opts.output != sys.stdout and not opts.quiet:
        out.pr(f"Completed {current_step}/{step_count} steps")

    # try to restore all links when done
    bounce_links(tx_ports.values(), opts)

    if not opts.quiet:
        tables.display_totals()


def main():
    """script entry point"""
    opts = parse_command_line()
    perform_margin_test(opts)


if __name__ == "__main__":
    main()
