#!/usr/bin/env bash

echo "starting bm-virtual-sc validation"
#Insert bm-virtual specific validation commands here
sleep 60
echo "end of bm-virtual-sc validation"
