#!/usr/bin/env python3

# Copyright (C) 2023 Intel Corporation
# SPDX-License-Identifier: MIT

"""Create Tx calibration blob from link margin summary data"""

import argparse
import datetime
import struct
import sys

# Prevent Python from creating cache files for local libraries:
sys.dont_write_bytecode = True

import data
import out
import valid_version

# Tool details
SUMMARY = "Extract Tx calibration blob from link margin summary"
DETAIL = """
Extract Tx GUID and lane information from margin summary data and
create a corresponding Tx calibration blob to load into SPI flash.
"""

#
# CONSTANTS
#

# Corresponds to string data "Xe Tx Cal Blob\0\0"
TXCAL_BLOB_MAGIC = [0x54206558, 0x61432078, 0x6c42206c, 0x0000626f]

PORT_FABRIC_START = 1
PORT_FABRIC_END = 8
TXCAL_VERSION_V1 = 1
TXCAL_VERSION_CURRENT = TXCAL_VERSION_V1

TXCAL_HDR_FMT = "<IIIIIIIIIIII"
TXCAL_SETTINGS_FMT = "<QHHHHHHHH"

TXCAL_HDR_SIZE = struct.calcsize(TXCAL_HDR_FMT)
TXCAL_SETTINGS_SIZE = struct.calcsize(TXCAL_SETTINGS_FMT)

NOW = datetime.datetime.utcnow()

CRC32C_POLYNOMIAL = 0x82f63b78


#
# CLASSES
#

class TxCalOpts:
    """
    Options for calibration blob creation. To specify options directly, inherit
    this class or instantiate an object and override specific properties.
    """
    # Also used to set parse_command_line() defaults:
    output = "txcal.txbin"
    date = f"{NOW.year:04}{NOW.month:02}{NOW.day:02}"
    time = f"{NOW.hour:02}{NOW.minute:02}{NOW.second:02}"
    cfg_version = 1

    # Set but not used by parse_command_line():
    files = [sys.stdin]
    device = []
    guid = []
    host_name = []
    quiet = False
    verbose = False

    def __init__(self, **args):
        """Instantiate an options object with optional overrides"""
        self.__dict__.update(args)


#
# FUNCTIONS
#

def check_opts(opts):
    """validate and clean up option values"""

    if isinstance(opts.output, str):
        opts.output = argparse.FileType('wb')(opts.output)

    if isinstance(opts.date, str):
        opts.date = int(opts.date, 16)

    if isinstance(opts.time, str):
        opts.time = int(opts.time, 16)

    return opts


def parse_command_line(default=TxCalOpts):
    """Parse command line options"""

    def help_format(prog):
        """preferred help format"""
        return argparse.HelpFormatter(prog, max_help_position=40)

    def hex_input(txt):
        return int(txt, 16)

    def int_input(txt):
        return int(txt, 0)

    version = valid_version.Version(__file__)
    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
        "files",
        type=argparse.FileType('r', encoding='utf-8-sig'),
        metavar="FILE",
        nargs="+",
        help="input margin summary file"
    )

    parser.add_argument(
        '-o', '--output',
        type=argparse.FileType('wb'),
        default=default.output,
        metavar="FILE",
        help=f"output txcal blob to file (default: {default.output})"
    )

    parser.add_argument(
        '--host-name',
        action='append',
        metavar="HOST",
        help="specify host name to limit data for blob"
    )

    parser.add_argument(
        '-g', '--guid',
        action='append',
        type=hex_input,
        metavar="GUID",
        help="specify TX subdevice GUID to limit data for blob"
    )

    parser.add_argument(
        '-d', '--device',
        action='append',
        type=hex_input,
        metavar="DEV",
        help="specify TX device fabric ID to limit data for blob"
    )

    parser.add_argument(
        '--date',
        type=hex_input,
        default=default.date,
        metavar="DATE",
        help=f"specify UTC date as YYYYMMDD (default: {default.date})"
    )

    parser.add_argument(
        '--time',
        type=hex_input,
        default=default.time,
        metavar="TIME",
        help=f"specify UTC time as HHMMSS (default: {default.time})"
    )

    parser.add_argument(
        '--cfg-version',
        type=int_input,
        default=default.cfg_version,
        metavar="VER",
        help=f"specify config version (default: {default.cfg_version})"
    )

    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help="suppress informational messages"
    )

    parser.add_argument(
        '--verbose',
        action='store_true',
        help="produce detailed informational messages"
    )

    parser.add_argument(
        '-v', '--version',
        action='version',
        version=str(version),
        help="report version and exit"
    )

    return check_opts(parser.parse_args())


#
# There is no TileId class: device_num/tile_num tuples are used as sort keys
# for per-tile calibration data but do not directly appear in the calibration
# output file, which encodes only GUIDs and per-port calibration data. They
# are also used in output messages that need to map back to source rows.
#

def tile_ident(tile):
    """standard tile identifier from device_num/tile_num tuple"""
    return f"0x{tile[0]:08x}:{tile[1]}"


class LaneId:
    """lane identifier"""

    def __init__(self, port_num, lane_num):

        if not PORT_FABRIC_START <= port_num <= PORT_FABRIC_END:
            raise ValueError(f"Invalid port number {port_num}")
        if not 0 <= lane_num <= 3:
            raise ValueError(f"Invalid lane number {lane_num}")

        self.port_num, self.lane_num = port_num, lane_num

    def __str__(self):
        return f"{self.port_num}:{self.lane_num}"

    def ident(self, tile):
        """standard lane identifier"""
        return f"{tile_ident(tile)}:{self}"


def tile_lane_address(lane_str):
    """extract and validate lane address information from lane id"""

    dev_str, tile_str, port_str, lane_str = lane_str.split(":")
    dev_num, tile_num = int(dev_str, 16), int(tile_str)

    if not 0 <= tile_num <= 1:
        raise ValueError(f"Invalid tile number {tile_num}")

    tile = (dev_num, tile_num)

    port_num, lane_num = int(port_str), int(lane_str)
    lane = LaneId(port_num, lane_num)

    return tile, lane


class LaneParams:
    """Per-lane TX calibration parameters"""

    # per-nibble encodings for TX calibration params
    DELAY_ENCODINGS = {1: 0x4, 3: 0x0, 7: 0xc, 15: 0x8}
    SPECIFY_PD = 0x2

    def __init__(self, delay_str, revpd_str):
        if delay_str == revpd_str == "?":
            self.delay = self.revpd = None

        delay, revpd = int(delay_str), int(revpd_str)

        if delay not in self.DELAY_ENCODINGS:
            raise ValueError(f"Invalid delay {delay}")
        if not 0 <= revpd <= 1:
            raise ValueError(f"Invalid revpd {revpd}")

        self.delay, self.revpd = delay, revpd

    def nibble_value(self):
        """nibble encoding for lane parameters"""
        if self.delay is None or self.revpd is None:
            return 0

        return self.DELAY_ENCODINGS[self.delay] | self.revpd | self.SPECIFY_PD


class TileParams:
    """All port parameters for a tile"""
    def __init__(self, guid):
        self.guid = guid
        self.ports = {}

    def get_calibration(self, lane):
        """get calibration for a given lane"""
        if lane.port_num not in self.ports:
            return None
        return self.ports[lane.port_num][lane.lane_num]

    def set_calibration(self, lane, params):
        """set calibration for a given lane"""
        if lane.port_num not in self.ports:
            self.ports[lane.port_num] = [None] * 4
        self.ports[lane.port_num][lane.lane_num] = params

    def encode_lanes(self, port_num):
        """compute dcc margin param value for all four lanes of a port"""
        if port_num not in self.ports:
            return 0

        value = 0

        for lane_num, param in enumerate(self.ports[port_num]):
            if param is not None:
                value |= param.nibble_value() << lane_num * 4

        return value

    def cal_data(self):
        """calibration data for a tile"""
        result = [self.guid]

        for port_num in range(PORT_FABRIC_START, PORT_FABRIC_END + 1):
            result.append(self.encode_lanes(port_num))

        return result

    def print_verbose(self, tile):
        """print calibration data for a tile"""
        out.pr(f" 0x{self.guid:016x} / {tile_ident(tile)} :")
        for port_num in sorted(self.ports):
            out.pr(f"  port {port_num} - 0x{self.encode_lanes(port_num):04x}")


def all_selected_tx_cal_data(opts):
    """generate a sequence of all selected rows from all input files"""

    if not opts.quiet:
        out.pr("Generating TX calibration data from input file(s):")
        sep = "\n  "
        out.pr(f"  {sep.join(file.name for file in opts.files)}\n")

    guids = {}
    for file in opts.files:
        for row in data.Reader(file).data():
            try:
                tile, lane = tile_lane_address(row["tx lane"])
                guid = int(row["tx guid"], 16)
                params = LaneParams(row["delay"], row["revpd"])
                if guids.setdefault(guid, tile) != tile:
                    out.error(f"Multiple tiles match guid 0x{guid:016x}")
                if opts.host_name and row["host name"] not in opts.host_name:
                    continue
                if opts.device and tile[0] not in opts.device:
                    continue
                if opts.guid and guid not in opts.guid:
                    continue
                yield (tile, guid, lane, params)
            except (KeyError, ValueError):
                out.error(f"invalid data row in {file.name}: {row}")


def crc32c(byte_data, crc=0):
    """Compute CRC32C for an array of bytes"""
    # Performance isn't important, so a bitwise implementation is OK
    for each_byte in byte_data:
        crc ^= each_byte
        for _ in range(8):
            crc = (crc >> 1) ^ (CRC32C_POLYNOMIAL if crc & 1 else 0)

    return crc


def write_blob(tiles, opts=TxCalOpts):
    """write blob data from a set of tile data"""

    size = TXCAL_HDR_SIZE + TXCAL_SETTINGS_SIZE * len(tiles)

    if not opts.quiet:
        out.pr(f"Writing calibration blob: {opts.output.name}")
        out.pr(f" cfg version : {opts.cfg_version} (0x{opts.cfg_version:x})")
        out.pr(f" date stamp  : 0x{opts.date:08x}")
        out.pr(f" time stamp  : 0x{opts.time:08x}")
        out.pr(f" size        : {size} (0x{size:x})")
        out.pr(f" num tiles   : {len(tiles)} (0x{len(tiles):x})")

    if opts.verbose:
        out.pr("\nCalibration data by GUID/tile:")
        for tile, tile_params in sorted(tiles.items()):
            tile_params.print_verbose(tile)

    txcal_data = b''
    for _, tile_params in sorted(tiles.items()):
        txcal_data += struct.pack(TXCAL_SETTINGS_FMT, *tile_params.cal_data())

    hdr_data = [
        *TXCAL_BLOB_MAGIC,
        TXCAL_VERSION_CURRENT,
        opts.cfg_version,
        opts.date,
        opts.time,
        size,
        len(tiles),
        crc32c(txcal_data),
    ]
    hdr_data.append(crc32c(struct.pack(TXCAL_HDR_FMT[:-1], *hdr_data)))
    txcal_hdr = struct.pack(TXCAL_HDR_FMT, *hdr_data)

    opts.output.write(txcal_hdr)
    opts.output.write(txcal_data)


def create_blob(opts=TxCalOpts):
    """create blob from margin summary files"""

    # all_params is a dictionary of TileParams indexed by device/tile tuples
    all_params = {}

    for tile, guid, lane, params in all_selected_tx_cal_data(opts):
        if tile not in all_params:
            all_params[tile] = TileParams(guid)
        tile_params = all_params[tile]
        if tile_params.guid != guid:
            out.error(f"tile {tile_ident(tile)} has multiple guids")
        if tile_params.get_calibration(lane) is not None:
            out.error(f"lane {lane.ident(tile)} has multiple calibrations")
        tile_params.set_calibration(lane, params)

    write_blob(all_params, opts)


def main():
    """script entry point"""
    opts = parse_command_line()
    create_blob(opts)


if __name__ == "__main__":
    main()
