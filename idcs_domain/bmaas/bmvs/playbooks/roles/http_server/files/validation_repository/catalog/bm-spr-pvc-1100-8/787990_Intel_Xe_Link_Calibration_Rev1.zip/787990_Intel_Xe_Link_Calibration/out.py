#
# Copyright (C) 2022 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""
General output support

Provide replacements for print() which optionally duplicate all output
to another file and provide extensible qualified warning support with
automatic system exit on error.
"""


import sys


# Duplicate all output here: if set, should support file API
duplicate_output = None


def pr(*args, **kwargs):
    """Print and duplicate to duplicate_output if set, flushing by default"""
    kwargs.setdefault('flush', True)
    print(*args, **kwargs)
    if duplicate_output and duplicate_output != kwargs.get('file', sys.stdout):
        kwargs['file'] = duplicate_output
        print(*args, **kwargs)


def header(*args, **kwargs):
    """Block header for summary output"""
    HEADER_LINE_WIDTH = 96
    pr("#" * HEADER_LINE_WIDTH, **kwargs)
    pr("#", *args, **kwargs)
    pr("#" * HEADER_LINE_WIDTH, **kwargs)


def warn(*msg, qualifier=[]):
    """Optionally-prefixed warning message"""
    pr(*qualifier, "Warning:", *msg, file=sys.stderr)


def dev_warn(dev, *msg, qualifier=[]):
    """Device-prefixed warning message"""
    warn(*msg, qualifier=["Device", dev.fabric_id] + qualifier)


def sd_warn(sd, *msg, qualifier=[]):
    """Subdevice-prefixed warning message"""
    dev_warn(sd.dev, *msg, qualifier=["attach point", sd.attach] + qualifier)


def port_warn(port, *msg, qualifier=[]):
    """Port-prefixed warning message"""
    sd_warn(port.sd, *msg, qualifier=["port", port.number] + qualifier)


def lane_warn(port, lane, *msg, qualifier=[]):
    """Lane-prefixed warning message"""
    port_warn(port, *msg, qualifier=["lane", lane] + qualifier)


def error(*msg, qualifier=[]):
    """Optionally-prefixed error message (and quit)"""
    pr(*qualifier, "Error:", *msg, file=sys.stderr)
    sys.exit(1)


def dev_error(dev, *msg, qualifier=[]):
    """Device-prefixed error message (and quit)"""
    error(*msg, qualifier=["Device", dev.fabric_id] + qualifier)


def sd_error(sd, *msg, qualifier=[]):
    """Subdevice-prefixed error message (and quit)"""
    dev_error(sd.dev, *msg, qualifier=["attach point", sd.attach] + qualifier)


def port_error(port, *msg, qualifier=[]):
    """Port-prefixed error message (and quit)"""
    sd_error(port.sd, *msg, qualifier=["port", port.number] + qualifier)


def lane_error(port, lane, *msg, qualifier=[]):
    """Lane-prefixed error message (and quit)"""
    port_error(port, *msg, qualifier=["lane", lane] + qualifier)


if __name__ == "__main__":
    warn("This module has no command line support")
