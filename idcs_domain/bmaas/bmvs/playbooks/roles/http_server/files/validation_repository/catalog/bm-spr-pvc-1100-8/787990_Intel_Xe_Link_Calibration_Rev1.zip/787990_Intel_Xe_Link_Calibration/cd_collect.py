#!/usr/bin/env python3

#
# Copyright (C) 2023 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""Collect channel data"""

import argparse
import collections
import math
import sys
import time

sys.dont_write_bytecode = True

import valid_version
import data
import iaf
import out

# Tool details
SUMMARY = "Collect channel data"
DETAIL = """
Collect channel data for specified (or all) lanes, one or more times,
bouncing the channels between data collection. By default collect data
for all devices/ports.
"""

# number of lanes is constant for now, may support other options eventually
NUM_LANES = 4

# when no errors have been detected, rather than reporting a 0 BER rate report
# a BER that is a negative log and lower than 1 / bitcount -- currently divide
# by 10 although arguably an error model should dictate this factor (e.g., a
# gaussian model might suggest 1.2)
BER_GOOD_LANE_DIVISOR = 10

# BER to report when a lane is down: 0.5 is "statistically" correct (and is a
# negative log to facilitate error graphing), 1.0 could also have been used
BER_LANE_DOWN = 0.5

# Option selections
MODE_CHOICES = ['bounce', 'check']
FORMAT_CHOICES = ['csv', 'spaces', 'table', 'unix', 'tabs', 'list']

# Fields to output. Must start with:
#     "row", "iteration", "fabric_id", "tile", "lpn", "lane", "neighbor"
# and end with:
#     "tag"
CHANNEL_DATA_FIELDS = ["row",
                       "iteration",
                       "fabric_id ",
                       "tile",
                       "lpn",
                       "lane",
                       "neighbor".ljust(iaf.LaneId.WIDTH),
                       "phy_state",
                       "log_state",
                       "health".ljust(len("DEGRADED")),
                       "speed",
                       "tx_width",
                       "rx_width",
                       "up_at",
                       "agc1_ctl",
                       "agc1_peak",
                       "agc_targ",
                       "cdr_prop_mu",
                       "cdr_pherr_scale",
                       "tx_fir_eh_m1",
                       "tx_fir_eh_0",
                       "tx_fir_eh_1",
                       "tx_fir_eh_2",
                       "tx_fir_eh_3",
                       "cntr_ch_est_0",
                       "cntr_ch_est_1",
                       "cntr_ch_est_2",
                       "cntr_ch_est_3",
                       "cntr_ch_est_4",
                       "lms_sum_err",
                       "hcntr0",
                       "hcntr1",
                       "hcntr2",
                       "hcntr3",
                       "hcntr4",
                       "cdr_intg",
                       "hffe0",
                       "hffe1",
                       "hffe2",
                       "hffe3",
                       "hffe4",
                       "hffe5",
                       "hffe6",
                       "hffe7",
                       "hffe8",
                       "hffe9",
                       "hffe10",
                       "hffe11",
                       "hffe12",
                       "hffe13",
                       "hffe14",
                       "hffe15",
                       "hffe16",
                       "hffe17",
                       "hffe18",
                       "hffe19",
                       "hffe20",
                       "hffe21",
                       "hffe22",
                       "hffe23",
                       "hffe24",
                       "hffe25",
                       "hffe26",
                       "hffe27",
                       "hffe28",
                       "hffe29",
                       "gf0",
                       "hdfe",
                       "eq_targ0",
                       "eq_targ1",
                       "eq_targ2",
                       "eq_targ3",
                       "uerr_sum",
                       "ltp_ber",
                       "pre_fec_ber",
                       "post_fec_ber",
                       "good_fec_cw",
                       "fec_cerr1",
                       "fec_cerr2",
                       "fec_cerr3",
                       "fec_cerr4",
                       "fec_cerr5",
                       "fec_cerr6",
                       "fec_cerr7",
                       "fec_cerr8",
                       "fec_cerr9",
                       "fec_cerr10",
                       "fec_cerr11",
                       "fec_cerr12",
                       "fec_cerr13",
                       "fec_cerr14",
                       "fec_cerr15",
                       "fec_uerr_cnt",
                       "crc_err_ln",
                       "fec_err_ln",
                       "lane_fec_ber",
                       "cwer",
                       "cwer_passed",
                       "fec_mode",
                       "crc_mode",
                       "pll_lol_cnt",
                       "pmon_ulvt_freq",
                       "link_up_ms",
                       "tag".ljust(len("COLLECT"))]

# Other port attributes that could be shown include:
#
#    tx_packet_count
#    rx_packet_count
#    link_down_count
#    error_recovery_count
#    tx_replays
#    rx_replays
#    rx_fec_corr_count
#    link_quality


#
# Encoding constants for BER calculations
#
LTP_SIZE = 65 * 16 + 4 * 12
# Block size, symbol size, longest correctible error by FEC mode:
FEC_INFO = {"F132": (132, 8, 2),
            "F528": (528, 10, 8),
            "F544": (544, 10, 15)}


#
# Whether to suppress port bouncing (mostly for testing)
#
SUPPRESS_PORT_BOUNCE = False


class CollectChannelDataOpts:
    """
    Options for channel data collection. To specify options for
    collect_channel_data(), inherit this class and override.
    """

    # Also used to set parse_command_line() defaults:
    mode = 'bounce'
    iterations = 1
    start_iteration = 0
    format = 'csv'
    device = ["all:all:all"]
    link = []
    link_wait_timeout = 140
    sample_interval = 20
    sample_delay = 0
    stop_on_fec_uerr = 0
    lane_mask = 0xf

    # Set but not used by parse_command_line():
    output = sys.stdout
    no_neighbor = False
    no_header = False
    only_header = False
    sample_on_linkup = False
    collect_after_interval = False
    stop_on_error = False
    verbose = False


class CollectChannelDataErrors:
    """Consolidation for some link errors"""
    def __init__(self):
        self.linkup_err = False
        self.fec_uerr = False


def parse_command_line(default=CollectChannelDataOpts):
    """Parse options from the command line"""

    def help_format(prog):
        return argparse.ArgumentDefaultsHelpFormatter(prog, max_help_position=40)

    def int_in_range(txt, low, high):
        """constrained integer value"""
        val = int(txt, 0)
        if low <= val <= high:
            return val
        raise ValueError(f"{val} not in range [{low}:{high}]")

    version = valid_version.Version(__file__)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument('mode',
                        choices=MODE_CHOICES,
                        nargs='?',
                        default=default.mode,
                        help="bounce port or just check current values")

    parser.add_argument('-v', '--version',
                        action='version',
                        version=str(version),
                        help="report version and exit")

    parser.add_argument('-n', '--iterations',
                        type=lambda x: int(x, 0),
                        default=default.iterations,
                        metavar="N",
                        help="number of bounce/sample iterations")

    parser.add_argument('-s', '--start-iteration',
                        type=lambda x: int(x, 0),
                        default=default.start_iteration,
                        metavar="N",
                        help="value to start the iteration counter at")

    parser.add_argument('-o', '--output',
                        type=argparse.FileType('w'),
                        default="-",
                        metavar="FILE",
                        help="output data to file")

    parser.add_argument('-f', '--format',
                        choices=FORMAT_CHOICES,
                        default=default.format,
                        metavar="FORMAT",
                        help="format: csv/spaces/table/unix/tabs/list")

    parser.add_argument('-d', '--device',
                        metavar="DEV_OR_PORT",
                        action='append',
                        help="collect data for device[:subdevice[:port]]")

    parser.add_argument('--link',
                        metavar="PORT-PORT",
                        action='append',
                        help="specify pair of neighbor ports")

    parser.add_argument('--no-neighbor',
                        action='store_true',
                        help="do not automatically report on neighbors")

    parser.add_argument('--no-header',
                        action='store_true',
                        help="do not print the initial header row")

    parser.add_argument('--only-header',
                        action='store_true',
                        help="only print the row headers and exit")

    parser.add_argument('--sample-on-linkup',
                        action='store_true',
                        help="collect non-delta link stats at linkup")

    parser.add_argument('--link-wait-timeout',
                        type=lambda x: int_in_range(x, 0, 600),
                        default=default.link_wait_timeout,
                        metavar="SEC",
                        help="seconds to wait for link state changes")

    parser.add_argument('--sample-interval', '--dwell',
                        type=lambda x: int_in_range(x, 0, 300),
                        default=default.sample_interval,
                        metavar="SEC",
                        help="seconds to gather BER data")

    parser.add_argument('--sample-delay', '--delay',
                        type=lambda x: int_in_range(x, 0, 60),
                        default=default.sample_delay,
                        metavar="SEC",
                        help="seconds delay before gathering BER")

    parser.add_argument('--collect-after-interval',
                        action='store_true',
                        help="collect all data after sample interval")

    parser.add_argument('--stop-on-error',
                        action='store_true',
                        help="exit if any port fails to reach LINKUP")

    parser.add_argument('--stop-on-fec-uerr',
                        type=lambda x: int(x, 0),
                        default=default.stop_on_fec_uerr,
                        metavar="N",
                        help="stop on N uncorrectable errors [0 disables]")

    parser.add_argument('--lane-mask',
                        type=lambda x: int(x, 0),
                        default=default.lane_mask,
                        help="bitmask of lanes to test")

    parser.add_argument('--verbose',
                        action='store_true',
                        help="report additional detail")

    parser.add_argument('--mock',
                        action='store_true',
                        help="collect simulated test data only")

    opts = parser.parse_args()

    if not opts.link:
        opts.link = default.link

    if not opts.device:
        opts.device = []
        for link in opts.link:
            opts.device += link.split("-", 1)

    # Use default value if device not specified
    if not opts.device:
        opts.device = default.device

    for bad in [d for d in opts.device if len(d.split(":")) > 3]:
        good = ":".join(bad.split(":")[:3])
        out.warn("selections to port level only, treating",
                 bad,
                 "as",
                 good)

    iaf.verbose_reporting = opts.verbose

    if opts.mock:
        # pylint: disable=global-statement
        global SUPPRESS_PORT_BOUNCE
        global FEC_INFO

        opts.sample_delay = 0
        opts.sample_interval = 0
        SUPPRESS_PORT_BOUNCE = True
        FEC_INFO["NONE"] = FEC_INFO["F528"]

    return opts


def ber_ratio(errored_bits, total_bits):
    """Calculate BER ratio even when errored/total bits are zero"""
    if errored_bits < 1:
        errored_bits = 1
        total_bits *= BER_GOOD_LANE_DIVISOR

    return errored_bits / total_bits if total_bits > 0 else BER_LANE_DOWN


def update_ber(port):
    """Update BER-related value for a port"""
    # pylint: disable=too-many-locals

    if port.fec_mode == "F528":
        blocks_to_convert_to_uerrs = port.fec_cerr8
        bits_to_convert_to_uerrs = blocks_to_convert_to_uerrs * 8
    else:
        blocks_to_convert_to_uerrs = 0
        bits_to_convert_to_uerrs = 0

    port.uerr_sum = port.fec_uerr_cnt + blocks_to_convert_to_uerrs

    port.ltp_ber = ber_ratio(port.total_crc_err,
                             (port.good_ltp + port.total_crc_err) * LTP_SIZE)

    if port.fec_mode not in FEC_INFO:
        return

    block_size, symbol_size, longest_cerr = FEC_INFO[port.fec_mode]

    corrected_bins = range(1, longest_cerr + 1)

    corrected_blocks = sum(port.fec_cerr[i] for i in corrected_bins) - blocks_to_convert_to_uerrs

    corrected_bits = sum(i * port.fec_cerr[i] for i in corrected_bins) - bits_to_convert_to_uerrs
    uncorrected_bits = port.fec_uerr_cnt * (longest_cerr + 1) + bits_to_convert_to_uerrs

    block_count = port.good_feccw + corrected_blocks + port.fec_uerr_cnt
    total_bits = block_count * block_size * symbol_size

    port.pre_fec_ber = ber_ratio(corrected_bits + uncorrected_bits, total_bits)
    port.post_fec_ber = ber_ratio(uncorrected_bits, total_bits)

    long_error_blocks = (sum(port.fec_cerr[i]
                             for i in range(6, longest_cerr + 1)) + port.fec_uerr_cnt)

    if port.pre_fec_ber < 1 or long_error_blocks < 1 or block_count < 1:
        port.cwer = 0
    else:
        expected_long_errors = 1.04 * math.log10(port.pre_fec_ber) - 1.55
        actual_long_errors = math.log10(long_error_blocks / block_count)
        port.cwer = expected_long_errors - actual_long_errors

    port.cwer_passed = port.cwer >= 0

    if port.rx_width > 0:
        lane_bits = total_bits / port.rx_width
        port.lane_fec_ber = [ber_ratio(port.fec_err_ln[lane], lane_bits)
                             for lane in range(NUM_LANES)]
    else:
        port.lane_fec_ber = [BER_LANE_DOWN] * NUM_LANES


def output_port(table, iteration, tag, port, errors, uerr_cnt, lanes, *args):
    """output port information"""
    # pylint: disable=too-many-arguments

    info = [iteration, port.subdevice.dev.fabric_id, port.subdevice.attach, port.number]

    # Update BER counters as possible but don't require them
    try:
        update_ber(port)
    except (AttributeError, KeyError, IndexError, ValueError):
        pass

    for lane in lanes:
        if port.neighbor:
            lane_info = [lane, port.neighbor.lane_id(port.rx_swizzle[lane])]
        else:
            lane_info = [lane, None]
        port_data = [port.get_lane(f.strip(), lane) for f in args[7:-1]]
        row = [table.row_count] + info + lane_info + port_data + [tag]
        table.add_row(*row)
        table.row_count += 1

    if port.down():
        errors.linkup_err = True

    if uerr_cnt and port.uerr_sum >= uerr_cnt:
        errors.fec_uerr = True


def wait_for_ports_down(ports_to_bounce, timeout):
    """Wait for a set of ports to go down with timeout"""
    if ports_to_bounce:
        start_time = time.time()
        while time.time() - start_time < timeout:
            for port in ports_to_bounce.values():
                if port.update().phy_state != "DISABLED":
                    break
            else:
                break
            time.sleep(1)


def wait_for_ports_up(ports_to_bounce, timeout, sample_on_linkup):
    """
    Wait for a set of ports to come up with timeout, removing entries as
    ports come up
    """
    if ports_to_bounce:
        start_time = time.time()
        while time.time() - start_time < timeout:
            time.sleep(1)
            for port_id, port in list(ports_to_bounce.items()):
                if port.update().up():
                    port.up_at = int(time.time() - start_time)
                    del ports_to_bounce[port_id]
                    if sample_on_linkup:
                        port.update_lcb_raw()
                        port.update_eq()
            if not ports_to_bounce:
                break


def collect_channel_data(opts=CollectChannelDataOpts):
    """Collect and report channel data as requested"""
    # pylint: disable=too-many-statements disable=too-many-nested-blocks
    # pylint: disable=too-many-locals disable=too-many-branches

    table = data.Writer(opts.output,
                        *CHANNEL_DATA_FIELDS,
                        format=opts.format,
                        no_header=opts.no_header)

    table.row_count = 0

    if opts.only_header:
        return

    lanes = [i for i in range(NUM_LANES) if opts.lane_mask & 1 << i]
    if not lanes:
        out.error(f"No lanes in mask {opts.lane_mask:#x}")

    # configure system as needed (will auto-restore on exit)
    iaf.disable_flapping_detection()
    iaf.disable_routing()

    # analyze fabric
    devs = iaf.get_devs()

    # determine which ports are being requested
    requested_ports = {}
    for sel in [device.split(":") for device in opts.device]:
        # normalize numeric device selectors to match fabric ids
        try:
            dev_sel = f"0x{int(sel[0], 16):08x}"
        except (AttributeError, KeyError, IndexError, ValueError):
            dev_sel = sel[0]
        # normalize subdevice selectors to match subdevice ids
        sd_sel = "sd." + sel[1] if sel[1:] else "sd.all"
        port_sel = sel[2] if sel[2:] else "all"
        for devname, dev in devs.items():
            if dev_sel in [devname, dev.fabric_id, "all"]:
                for sdname, subdev in dev.sds.items():
                    if sd_sel in [sdname, "sd.all"]:
                        for pname, port in subdev.ports.items():
                            if port_sel in [pname, "all"]:
                                requested_ports[port.ident] = port

    # set neighbor data if requested
    for link in [ln.split("-", 1) for ln in opts.link]:
        if len(link) < 2:
            continue
        try:
            port1, port2 = [iaf.Port.find(port) for port in link]
        except (AttributeError, KeyError, IndexError, ValueError):
            out.warn(f"Unrecognized port id in {'-'.join(link)}")
            continue
        for src, dst in [(port1, port2), (port2, port1)]:
            if src.neighbor and src.neighbor != dst:
                out.warn(src.ident,
                         "neighbor", src.neighbor.ident,
                         "overridden with", dst.ident)
            src.neighbor = dst

    # neighbor data is collected unless opts.no_neighbor is specified,
    # in which case unrequested neighbors are only bounced
    bounce_only = {}
    for port in list(requested_ports.values()):
        if port.neighbor and port.neighbor.ident not in requested_ports:
            if opts.no_neighbor:
                bounce_only[port.neighbor.ident] = port.neighbor
            else:
                requested_ports[port.neighbor.ident] = port.neighbor

    # sort for consistent process ordering
    ports = collections.OrderedDict(sorted(requested_ports.items()))

    if not ports:
        out.error("No ports selected for analysis")

    errors = CollectChannelDataErrors()

    for iteration in range(opts.start_iteration,
                           opts.start_iteration + opts.iterations):
        if opts.mode == 'bounce':
            all_ports = list(ports.items()) + list(bounce_only.items())
            ports_to_bounce = collections.OrderedDict(all_ports)

            if SUPPRESS_PORT_BOUNCE:
                for port in ports_to_bounce.values():
                    port.up_at = 1 if port.update().up() else -1
                ports_to_bounce = {}

            for port in ports_to_bounce.values():
                try:
                    port.set_enable(False)
                except BlockingIOError:
                    out.warn("Detected application workload traffic. Cannot continue testing.")
                    out.warn("Please stop your application and restart the driver and rerun the test.")
                    out.error("Stopping...")

            wait_for_ports_down(ports_to_bounce, opts.link_wait_timeout)

            for port in ports_to_bounce.values():
                port.up_at = -1
                port.set_enable(True)

            wait_for_ports_up(ports_to_bounce,
                              opts.link_wait_timeout,
                              opts.sample_on_linkup)

            if opts.sample_on_linkup:
                # if needed, get data for any TIMED OUT ports:
                for port in ports_to_bounce.values():
                    port.update_lcb_raw()
                    port.update_eq()

                for port in ports.values():
                    output_port(table,
                                iteration,
                                'LINKUP',
                                port,
                                errors,
                                opts.stop_on_fec_uerr,
                                lanes,
                                *CHANNEL_DATA_FIELDS)

            time.sleep(opts.sample_delay)

            for port in ports.values():
                port.start_lcb()

        if not opts.collect_after_interval:
            for port in ports.values():
                port.update().update_eq()

        time.sleep(opts.sample_interval)

        for port in ports.values():
            port.update_lcb()
            if opts.collect_after_interval:
                port.update().update_eq()

        for port in ports.values():
            output_port(table,
                        iteration,
                        'COLLECT',
                        port,
                        errors,
                        opts.stop_on_fec_uerr,
                        lanes,
                        *CHANNEL_DATA_FIELDS)

        if opts.stop_on_error and errors.linkup_err:
            break
        if opts.stop_on_fec_uerr and errors.fec_uerr:
            break


def main():
    """Entry point when called as a script"""
    opts = parse_command_line()
    collect_channel_data(opts)


if __name__ == "__main__":
    main()
