#!/usr/bin/env bash

echo "starting bm-virtual validation"
#Insert bm-virtual specific validation commands here
sleep 5
echo "end of bm-virtual validation"
