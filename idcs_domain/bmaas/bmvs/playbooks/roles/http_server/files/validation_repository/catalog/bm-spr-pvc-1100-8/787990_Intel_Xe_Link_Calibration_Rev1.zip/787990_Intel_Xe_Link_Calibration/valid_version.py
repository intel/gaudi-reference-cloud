#
# Copyright (C) 2022-2023 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""
Validated version support

This module checks the SHA hashes of all .py files in the installation
directory (where this file resides) against version.json (also in that
directory). If they match, it reports the version number contained in
that file, otherwise it emits an error message and reports an unknown
version indication.

When called as a script, this can be used to validate and (re)build the
JSON file and to set the version number. By default, it will bump the
version number and rebuild the JSON file if the SHAs do not match.
"""

import argparse
import hashlib
import json
import os
import pathlib
import re
import sys

sys.dont_write_bytecode = True

import out


# Tool details
SUMMARY = "Report checked version"
DETAIL = """
Update or check/report version information that is validated by
comparing SHA hashes of all source files ('report' displays the
configured version number even if the SHAs do not match).
"""

# version positions
MAJOR = 0
MINOR = 1
REVISION = 2

# version number to report if not known
UNKNOWN_VERSION = "UNKNOWN"

# JSON file containing version information
VERSION_INFO_FILE = "version.json"

# Matching for import lines
import_line_match = re.compile(r"import (\w+)")


class VersionChecker:
    """Read and check version from install location"""

    # Currently there is just one version for the entire directory. It
    # would be possible to have separate versions for each executable,
    # although this would require change the tooling flow: the current
    # model updates only a single version number for all.

    def __init__(self):
        self.root = pathlib.Path(__file__).resolve().parent
        self.json_path = self.root.joinpath(VERSION_INFO_FILE)
        self.sha = {}
        self.reported_version = None
        self.shas_match = None

    @staticmethod
    def str_to_str_mapping(dct):
        """Determine whether dct maps str to str only"""
        mapping_types = set((type(f), type(v)) for f, v in dct.items())
        return mapping_types == set([(str, str)])

    def installed_file(self, name):
        """Check that name refers to a file in installation dir"""
        path = self.root.joinpath(name)
        return path.parent == self.root and path.exists()

    def info_valid(self):
        """Indicate whether info file has been checked"""
        return self.reported_version is not None

    def read_info(self):
        """Read and validate an existing version JSON file"""
        self.sha = {}
        self.reported_version = None
        self.shas_match = None

        if not self.json_path.exists():
            return

        with open(self.json_path) as file:
            info = json.load(file)

        if (
            not isinstance(info, dict) or
            sorted(info.keys()) != ['sha', 'version'] or
            not isinstance(info['version'], str) or
            not isinstance(info['sha'], dict) or
            not self.str_to_str_mapping(info['sha'])
           ):
            raise ValueError("Improperly formatted version info")

        files = info['sha'].keys()
        if not all(self.installed_file(file) for file in files):
            raise ValueError("Version info refers to invalid file")

        self.sha = info['sha']
        self.reported_version = info['version']

    def sha_valid(self, name, expected_sha):
        """Check that all SHA values match"""
        with open(self.root.joinpath(name)) as file:
            file_sha = hashlib.sha256(file.read().encode()).hexdigest()
        return file_sha == expected_sha

    def all_shas_valid(self):
        """Check that all SHA values match"""
        if self.shas_match is None:
            self.shas_match = all(self.sha_valid(file, expected_sha)
                                  for file, expected_sha in self.sha.items())
        return self.shas_match

    def has_sha_for_file(self, file):
        """Indicate whether SHA for file is present"""
        return file in self.sha

    def find_hashable_files(self):
        """Locate candidates for hashing"""

        def recurse_imports(module, all_imports, processed, hashables):
            if module in processed:
                return
            processed.add(module)
            if module in all_imports:
                hashables.add(module)
                for mod in all_imports[module]:
                    recurse_imports(mod, all_imports, processed, hashables)

        version_module = pathlib.Path(__file__).with_suffix("").name
        hashables = set([version_module])
        version_module_users = set()
        processed = set()
        all_imports = {}
        for filename in sorted(self.root.glob("*.py")):
            module_name = filename.with_suffix("").name
            module_imports = set()
            with open(filename) as file:
                for line in file:
                    matched_line = import_line_match.match(line)
                    if matched_line:
                        imported_module = matched_line.group(1)
                        if imported_module == version_module:
                            version_module_users.add(module_name)
                        module_imports.add(imported_module)
            all_imports[module_name] = module_imports
        for module in version_module_users:
            recurse_imports(module, all_imports, processed, hashables)
        return sorted([pathlib.Path(h).with_suffix(".py") for h in hashables])

    def generate_hashes(self):
        """Generate SHA hashes for sources in installation directory"""
        sha = {}
        for filename in self.find_hashable_files():
            with open(filename) as file:
                name = filename.name
                sha[name] = hashlib.sha256(file.read().encode()).hexdigest()
        return sha

    def write_info(self, version):
        """Update info file in installation directory"""
        self.sha = self.generate_hashes()
        self.reported_version = str(version)
        self.shas_match = True
        info = {"sha": self.sha, "version": self.reported_version}

        # Format with 2-space indent and newline at end of file
        with open(self.json_path, "w") as file:
            json.dump(info, file, indent=2)
            print(file=file)


class Version:
    """
    Provide access to version information. Creates a singleton instance
    of VersionChecker to access the installation directory.
    """
    checker = None

    @staticmethod
    def next_version(reported_version, position=REVISION):
        """Report next version number based on position to update"""
        if reported_version is None:
            reported_version = "0.0.0"

        version = reported_version.split(".")

        if len(version) != 3:
            out.warn(f"version {reported_version} not of form N.N.N")
            return reported_version

        # increment number at position and zero numbers to the right
        version[position] = str(int(version[position]) + 1)
        for i in range(position + 1, REVISION + 1):
            version[i] = "0"

        return ".".join(version)

    def __init__(self, importer, *, throw_on_error=True, report_on_error=True):
        if not self.checker:
            self.checker = VersionChecker()
        self.throw_on_error = throw_on_error
        self.report_on_error = report_on_error
        self.checker.read_info()
        self.prog = pathlib.Path(importer).name

    def __repr__(self):
        """String representation of version"""
        if self.check():
            return self.info_version()

        if os.environ.get("AUTO_DEVELOPMENT_VERSION"):
            print("\n----------------------------")
            print("WARNING: DEVELOPMENT VERSION")
            print(f"BASED ON VERSION {self.info_version()}")
            print("VERSION DATA MUST BE UPDATED")
            print("----------------------------\n")
            return self.next_version(self.info_version()) + "_DEVEL"

        if self.report_on_error:
            out.warn("could not match version to installed files")
        if self.throw_on_error:
            raise ValueError("SHA mismatch of installed files")
        return UNKNOWN_VERSION

    def set(self, version):
        """Set version to a specific value and update info file"""
        self.checker.write_info(version)

    def check(self):
        """Check whether version info is valid"""
        return (
                self.checker.info_valid()
                and self.checker.all_shas_valid()
                and self.checker.has_sha_for_file(self.prog)
               )

    def info_version(self):
        """Unchecked reported version"""
        return self.checker.reported_version

    def bump(self, position=REVISION, always_update=False):
        """Bump version number if required and update info file"""
        if (
            self.checker.info_valid() and
            not always_update and
            self.checker.all_shas_valid() and
            self.checker.has_sha_for_file(self.prog)
           ):
            return

        self.set(self.next_version(self.info_version(), position))


def parse_command_line(version):
    """Parse command line for this tool and return options"""

    def version_string(string):
        """process version string in command line"""
        _, _, _ = [int(i) for i in string.split(".")]
        return string

    def position_string(string):
        """process position string in command line"""
        choices = {"major": MAJOR, "minor": MINOR, "revision": REVISION}
        return choices[string]

    def help_format(prog):
        """preferred help format"""
        return argparse.ArgumentDefaultsHelpFormatter(prog,
                                                      max_help_position=40)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument("action",
                        choices=["update", "check", "report"],
                        default="update",
                        nargs="?",
                        help="Update, check, or just report version info")

    parser.add_argument("-v", "--version",
                        action="version",
                        version=str(version),
                        help="report version and exit")

    parser.add_argument("-f", "--force",
                        action="store_true",
                        help="always bump version on update")

    parser.add_argument("-q", "--quiet",
                        action="store_true",
                        help="suppress all output")

    parser.add_argument("-p", "--position",
                        type=position_string,
                        default="revision",
                        metavar="POS",
                        help="bump major, minor, or revision number")

    parser.add_argument("-n", "--number",
                        type=version_string,
                        metavar="N.N.N",
                        help="set/expect a specific version number")

    parser.add_argument("-k", "--keep",
                        action="store_true",
                        help="keep version number, just update hashes")

    opts = parser.parse_args()

    return opts


def main():
    """Entry point: perform all script actions"""
    ver = Version(__file__, throw_on_error=False, report_on_error=False)
    opts = parse_command_line(ver)
    if opts.action == "update":
        if not opts.quiet:
            print(f"Initial version number is {ver.info_version()}")
        if opts.number:
            ver.set(opts.number)
        elif opts.keep and ver.info_version():
            ver.set(ver.info_version())
        else:
            ver.bump(opts.position, opts.force)
        if not opts.quiet:
            print(f"Updated version number is {Version(__file__)}")
    else:
        number = ver.info_version() if opts.action == "report" else str(ver)
        sha_result = "MATCH" if ver.check() else "DO NOT match"

        if not opts.quiet:
            print(f"Version = {number}")
            print(f"SHAs {sha_result}")

        if opts.number and opts.number != number:
            if not opts.quiet:
                out.warn(f"got version {number}, expected {opts.number}")
            sys.exit(1)

        if not ver.check():
            sys.exit(1)


if __name__ == "__main__":
    main()
