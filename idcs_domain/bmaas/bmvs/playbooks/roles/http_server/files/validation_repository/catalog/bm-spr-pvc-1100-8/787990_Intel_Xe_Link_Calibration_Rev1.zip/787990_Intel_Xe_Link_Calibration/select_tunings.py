#!/usr/bin/env python3

#
# Copyright (C) 2022 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""Extract selected tunings from files"""

import argparse
import datetime
import math
import os.path
import sys

sys.dont_write_bytecode = True

import valid_version
import data
import out


#
# TOOL DETAILS
#
SUMMARY="Select FIR tunings using fine calibration data"
DETAIL="""
Use fine tuning and insertion loss data to select FIR tunings for each
lane: apply filters for min(max(BER)), symmetry of coefficients, and
TxDB values (TxDB filtering requires insertion loss information). If
necessary, PRE and POST strengths are used for tie breakers (stronger
POST is preferred, then lowest POST strength).
"""

# BER to report if a lane is down
BER_LANE_DOWN = 0.5

# TxDB filtering factors
SHAPING_THRESHOLD = 12.0
ILDB_TO_MAX_TXDB_DIVISOR = 3.0
MAX_TO_MIN_TXDB_DIVISOR = 2.0
MAX_TO_MIN_TXDB_OFFSET = 1.0

#
# DEFAULT OUTPUT FILES
#
DEFAULT_OUTPUT_FILE = "tunings.csv"
DEFAULT_LOG_FILE = "tunings.log"


class Coefficients:
    """Set of TX FIR filter coefficients (pre/main/post)"""

    def __init__(self, pre, main, post):
        self.pre = pre
        self.main = main
        self.post = post

    def __eq__(self, other):
        return (self.pre == other.pre
                and self.main == other.main
                and self.post == other.post)

    def __repr__(self):
        return f"{self.values()}"

    def symmetric(self):
        """Test whether coefficients are symmetric"""
        return abs(self.pre - self.post) < 2

    def txdb(self):
        """Compute TxDB value for coefficients"""
        return 20.0 * math.log10((self.main - self.pre - self.post)
                                 / (self.main + self.pre + self.post))

    def values(self):
        """return values as a tuple"""
        return self.pre, self.main, self.post

    def post_stronger_than_pre(self):
        """
        Whether strength of POST is greater than strength of PRE

        PRE and POST are both negative so compare negated values
        """
        return -self.post > -self.pre


def il_db_preferences(il):
    """Return insertion-loss based preferences for TxDB filtering"""
    shaping_desired = il >= SHAPING_THRESHOLD
    max_txdb = il / ILDB_TO_MAX_TXDB_DIVISOR
    min_txdb = max_txdb / MAX_TO_MIN_TXDB_DIVISOR - MAX_TO_MIN_TXDB_OFFSET
    return shaping_desired, min_txdb, max_txdb


def parse_command_line():
    """Parse command line for this tool and return options"""
    input_file = argparse.FileType('r', encoding='utf-8-sig')
    output_file = argparse.FileType('w')
    help_format = lambda prog: argparse.ArgumentDefaultsHelpFormatter(prog,
            max_help_position=40)

    version = valid_version.Version(__file__)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument("files",
                        type=input_file,
                        metavar="FILE",
                        nargs="+",
                        help="fine calibration or insertion loss data file")

    parser.add_argument("-v", "--version",
                        action="version",
                        version=str(version),
                        help="report version and exit")

    parser.add_argument("-o", "--output",
                        type=output_file,
                        default=DEFAULT_OUTPUT_FILE,
                        metavar="FILE",
                        help="output selected tunings to file")

    parser.add_argument("--log",
                        type=output_file,
                        default=DEFAULT_LOG_FILE,
                        metavar="FILE",
                        help="log results to file")

    parser.add_argument("-f", "--format",
                        choices=["csv","spaces","table","unix","tabs","list"],
                        default="csv",
                        metavar="FORMAT",
                        help="output format: csv/spaces/table/unix/tabs/list")

    opts = parser.parse_args()

    data.default_format = opts.format

    print(f"Logging results to {opts.log.name}")

    print(f"{version.prog} version: {version}", file=opts.log)
    now = datetime.datetime.utcnow().strftime("%Y/%m/%d %H:%M")
    print(f"UTC time: {now}", file=opts.log)
    print(f"Log file: {opts.log.name}", file=opts.log)

    print(f"Input files: ({len(opts.files)})", file=opts.log)
    for file in opts.files:
        print(f" {file.name}", file=opts.log)
    print(file=opts.log)
    print(f"Tunings file: {opts.output.name} (format {opts.format})",
          file=opts.log)

    return opts


def process_insertion_loss_row(ils, lane, row):
    """Process row of insertion loss mapping file"""
    if lane in ils:
        out.error(f"Duplicate insertion loss for {lane}")
    # could throw an exception if the data isn't formatted correctly
    insertionLoss = float(row["insertionLoss"])
    if insertionLoss > 500:
        # IL often represented as db * 1000, silently convert to db
        insertionLoss /= 1000
    ils[lane] = insertionLoss


def process_fine_tuning_row(all_bers, coeffs, lane, row):
    """Process row of fine tuning results file"""
    # could throw an exception if the data isn't formatted correctly
    fir = int(row["firIdx"])
    fir_coeffs = Coefficients(*[int(row[f"txFirEh[{i}]"]) for i in range(1,4)])
    up = int(row["sToUp"]) >= 0
    ber = float(row["ber"]) if up else BER_LANE_DOWN
    if up and coeffs.setdefault(fir, fir_coeffs) != fir_coeffs:
        out.error(f"Conflicting definitions for firIdx {fir}:",
                  f"{coeffs[fir]} and {fir_coeffs}")
    bers = all_bers.setdefault(lane, {})
    bers[fir] = max(bers.setdefault(fir, ber), ber)


def read_input_files(files, log=None):
    """
    Process all input files and return a combined set of mappings.

    Input files should map lanes to either insertion loss values or
    collected fine data. For the latter, only lanes that came up are
    considered and ber and the coefficients themselves specify the
    criteria for selection.

    Returns mappings of lanes to firIdx to max(BER), lanes to
    insertionLoss, and firIdx to PRE/MAIN/POST filter coefficients.
    """
    all_bers, ils, coeffs = {}, {}, {}

    for file in files:
        try:
            for row in data.Reader(file).data():
                if "txLane" not in row:
                    out.error("txLane field not found")
                lane = row["txLane"]
                if "insertionLoss" in row:
                    try:
                        process_insertion_loss_row(ils, lane, row)
                    except (KeyError, ValueError, SystemExit):
                        out.error(f"Invalid insertion loss for {lane}")
                else:
                    try:
                        process_fine_tuning_row(all_bers, coeffs, lane, row)
                    except (KeyError, ValueError, SystemExit):
                        out.error(f"Invalid fine results for {lane}")
        except:
            if log:
                print(f"Invalid data in {file.name}", file=log)
            out.error(f"Error processing {file.name}")

    missing_il = [lane for lane in all_bers.keys() if lane not in ils]
    if missing_il:
        message = f"Missing insertion loss for {len(missing_il)} lanes:"
        while missing_il:
            message += "\n       " + " ".join(missing_il[:4])
            missing_il = missing_il[4:]
        out.warn(f"{message}")
        if log:
            print(f"{message}", file=log)

    return all_bers, ils, coeffs


def all_low_bers(bers):
    """Find firs with max BER values within one decade of the lowest"""
    best_ber_value = min(bers.values())
    ber_limit = best_ber_value * 10.0 if best_ber_value < BER_LANE_DOWN else 0
    return [fir for fir, ber in bers.items() if ber <= ber_limit]


def best_ber(firs, bers):
    """Find fir(s) with lowest max BER values"""
    bers = {fir : bers[fir] for fir in firs}
    best_ber_value = min(bers.values())
    return [fir for fir, ber in bers.items() if ber == best_ber_value]


def best_pre_post_ratio(firs, coeffs):
    """Filter using PRE/POST comparisons"""
    # Try to filter selected coefficients with higher POST than PRE
    # strengths, falling back on all. Negate the POST coefficients so
    # min() returns the lowest STRENGTH, to match PRE/POST algorithm
    # descriptions.
    post_strengths = {
        fir : -coeffs[fir].post for fir in firs
                                if coeffs[fir].post_stronger_than_pre()
    }
    if not post_strengths:
        post_strengths = {fir : -coeffs[fir].post for fir in firs}

    # most-symmetric coefficients will have lowest-strength POST
    least_post = min(post_strengths.values())
    firs = [ fir for fir, post in post_strengths if post == least_post ]
    return firs[0]


def best_il_based_txdb(firs, bers, txdbs, coeffs, il):
    """Match FIR values based on TxDB rules (based on insertion loss)"""
    shaping_desired, min_db, max_db = il_db_preferences(il)
    txdbs = {fir : txdbs[fir] for fir in firs}
    firs = []
    if shaping_desired:
        # Favor filters with some pre/post attenuation
        dbs = {fir : db for fir, db in txdbs.items() if min_db <= db <= max_db}
        if dbs:
            # min(TxDB) in range [min_db, max_db]
            lowest = min(dbs.values())
            firs = [fir for fir, db in dbs.items() if db == lowest]
        else:
            dbs = {fir : db for fir, db in txdbs.items() if db < min_db}
            if dbs:
                # max(TxDB) less than min_db
                highest = max(dbs.values())
                firs = [fir for fir, db in dbs.items() if db == highest]

    if not firs:
        # min(TxDB) - this will always produce at least one result
        lowest = min(txdbs.values())
        firs = [fir for fir, db in txdbs.items() if db == lowest]

    # check if case is unique
    if len(firs) == 1:
        return firs[0]

    # filter to lowest max(BER)
    firs = best_ber(firs, bers)
    if len(firs) == 1:
        return firs[0]

    # break ties using PRE/POST
    return best_pre_post_ratio(firs, coeffs)


def best_symmetric(lane, firs, bers, txdbs, coeffs, il):
    """Find best symmetric coefficients"""
    if len(firs) == 1:
        return firs[0]

    if il is None:
        out.error(f"Insertion loss required to process {lane}")

    return best_il_based_txdb(firs, bers, txdbs, coeffs, il)


def best_assymetric(firs, bers, txdbs, coeffs):
    """Find best assymetric coefficients"""
    # filter to lowest max(BER)
    firs = best_ber(firs, bers)
    if len(firs) == 1:
        return firs[0]

    # filter to lowest TXDB
    txdbs = {fir : txdbs[fir] for fir in firs}
    lowest = min(txdbs.values())
    firs = [fir for fir, db in txdbs.items() if db == lowest]
    if len(firs) == 1:
        return firs[0]

    # break ties using PRE/POST
    return best_pre_post_ratio(firs, coeffs)


def best_fir(lane, bers, symmetric_firs, txdbs, coeffs, il):
    """Select the best firIdx for a lane"""

    # Filter to max(BERs) within a decade of lowest
    low_ber_firs = all_low_bers(bers)
    if len(low_ber_firs) == 1:
        return low_ber_firs[0]
    if not low_ber_firs:
        return None

    firs = [fir for fir in low_ber_firs if fir in symmetric_firs]
    if firs:
        # Use rules for symmetric filters
        return best_symmetric(lane, firs, bers, txdbs, coeffs, il)

    # Use rules for assymmetric filters
    return best_assymetric(low_ber_firs, bers, txdbs, coeffs)


def report(firs, coeffs, file=sys.stdout, log=None):
    """Output selected best FIR tunings"""
    table = data.Writer(file,
                        "txLane".ljust(len("0x00000000:0:0:0")),
                        "txFirEh[1]",
                        "txFirEh[2]",
                        "txFirEh[3]",
                        "firIdx")
    for lane, fir in sorted(firs.items()):
        if fir is None:
            out.warn(f"No linkups detected for {lane}")
            if log:
                print(f"No valid coefficients for {lane}", file=log)
            table.add_row(lane, "NONE", "NONE", "NONE", "NONE")
        else:
            table.add_row(lane, *coeffs[fir].values(), fir)


def main():
    """Entry point: perform all script actions"""
    opts = parse_command_line()

    try:
        all_bers, ils, coeffs = read_input_files(opts.files, log=opts.log)

        symmetric_firs = set(fir for fir, fir_coeffs in coeffs.items()
                             if fir_coeffs.symmetric())
        txdbs = {fir : fir_coeffs.txdb() for fir, fir_coeffs in coeffs.items()}

        firs = {
            lane : best_fir(lane,
                            bers,
                            symmetric_firs,
                            txdbs,
                            coeffs,
                            ils.get(lane))
                   for lane, bers in all_bers.items()
        }

        print(f"Writing best FIR tunings to {opts.output.name}")

        report(firs, coeffs, file=opts.output, log=opts.log)
        print("Tunings file GENERATED", file=opts.log)

    except:
        print("Tunings file NOT generated", file=opts.log)


if __name__ == "__main__":
    main()
