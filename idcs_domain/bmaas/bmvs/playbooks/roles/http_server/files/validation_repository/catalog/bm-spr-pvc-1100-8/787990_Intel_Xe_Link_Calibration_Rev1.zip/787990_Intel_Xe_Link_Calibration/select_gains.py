#!/usr/bin/env python3

#
# Copyright (C) 2022-2023 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""Extract selected gains from files"""

import argparse
import collections
import datetime
import os
import os.path
import statistics
import sys

sys.dont_write_bytecode = True

import valid_version
import data
import out


#
# TOOL DETAILS
#
SUMMARY="Select DC gains using coarse calibration data"
DETAIL="""
Use coarse calibration data to select DC gains for each lane: Identify
ranges of gains valid in all input files that meets the filter criteria
and select the midpoint of each range. If no common range is identified
for a lane, progressively loosen the AGC criteria until one is found.
"""

#
# DEFAULTS FOR COARSE REPROCESSING
#
AGC_RANGE_STEP = (-1, +5)
DEFAULT_AGC_RANGE_LIMIT = (13, 127)
DEFAULT_AGC_RANGE = (21, 30)
DEFAULT_P4T_RANGE = (0.9, 1.2)

#
# DEFAULT OUTPUT FILES
#
DEFAULT_GAIN_FILE = "gains.csv"
DEFAULT_LOG_FILE = "gains.log"


def parse_command_line():
    """Parse command line for this tool and return options"""

    def int_range(low, high):
        """Type check an int range within lower and upper bounds"""
        def argument(string):
            bot, top = [int(i) for i in string.split(",",1)]
            if bot > top:
                out.warn(f"argument range {bot},{top} in wrong order")
                raise ValueError("illegal range")
            if bot < low or top > high:
                out.warn(f"argument range {bot},{top} not in [{low}:{high}]")
                raise ValueError("out of range")
            return bot, top
        return argument

    def float_range(low, high):
        """Type check a float range within lower and upper bounds"""
        def argument(string):
            bot, top = [float(i) for i in string.split(",",1)]
            if bot > top:
                out.warn(f"argument range {bot},{top} in wrong order")
                raise ValueError("illegal range")
            if bot < low or top > high:
                out.warn(f"argument range {bot},{top} not in [{low}:{high}]")
                raise ValueError("out of range")
            return bot, top
        return argument

    input_file = argparse.FileType('r', encoding='utf-8-sig')
    output_file = argparse.FileType('w')
    help_format = lambda prog: argparse.ArgumentDefaultsHelpFormatter(prog,
            max_help_position=43)

    version = valid_version.Version(__file__)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument("files",
                        type=input_file,
                        metavar="FILE",
                        nargs="+",
                        help="coarse calibration data file")

    parser.add_argument("-v", "--version",
                        action="version",
                        version=str(version),
                        help="report version and exit")

    parser.add_argument("-g", "--dc-gains",
                        action="store",
                        default=DEFAULT_GAIN_FILE,
                        metavar="FILE",
                        help="output selected dc gains to file on completion")

    parser.add_argument("--log",
                        type=output_file,
                        default=DEFAULT_LOG_FILE,
                        metavar="FILE",
                        help="log results to file")

    parser.add_argument("-s", "--start-agc",
                        type=int_range(0, 127),
                        default=DEFAULT_AGC_RANGE,
                        metavar="LOW,HIGH",
                        help="starting agc range to filter coarse data")

    parser.add_argument("-l", "--limit",
                        type=int_range(0, 127),
                        default=DEFAULT_AGC_RANGE_LIMIT,
                        metavar="LOW,HIGH",
                        help="limit to agc range to filter coarse data")

    parser.add_argument("-p", "--agc-peak4-ratio",
                        type=float_range(0.5, 2.0),
                        default=DEFAULT_P4T_RANGE,
                        metavar="LOW,HIGH",
                        help="agcPeak/4:agcTarg range to filter coarse data")

    parser.add_argument("-f", "--format",
                        choices=["csv","spaces","table","unix","tabs","list"],
                        default="csv",
                        metavar="FORMAT",
                        help="output format: csv/spaces/table/unix/tabs/list")

    parser.add_argument("-i", "--inline",
                        action="store_true",
                        help="automatically use/replace output files")

    parser.add_argument("--ignore-always-down-lanes",
                        action="store_true",
                        help="ignore lanes always down in any single file")

    parser.add_argument("-y", "--yes",
                        action="store_true",
                        help="do not ask for confirmations")

    parser.add_argument("--verbose",
                        action="store_true",
                        help="report additional detail")

    opts = parser.parse_args()

    print(f"Logging results to {opts.log.name}")

    print(f"{version.prog} version: {version}", file=opts.log)
    now = datetime.datetime.utcnow().strftime("%Y/%m/%d %H:%M")
    print(f"UTC time: {now}", file=opts.log)
    print(f"Log file: {opts.log.name}", file=opts.log)

    if not opts.yes and not opts.inline:
        files_being_overwritten = []
        if os.path.exists(opts.dc_gains):
            files_being_overwritten.append(opts.dc_gains)
        if files_being_overwritten:
            out.warn("will overwrite the following file(s):",
                     ", ".join(files_being_overwritten))
            answer = input("Continue? ")
            if answer[:1].lower() != "y":
                print("...operation aborted...", file=opts.log)
                sys.exit(0)

    # should only exist if tool identifies a complete set of gains
    if os.path.exists(opts.dc_gains):
        os.remove(opts.dc_gains)

    data.default_format = opts.format

    print(f"Input files: ({len(opts.files)})", file=opts.log)
    for file in opts.files:
        print(f" {file.name}", file=opts.log)
    if opts.ignore_always_down_lanes:
        print("(ignoring always-down lanes)", file=opts.log)
    print(file=opts.log)
    print(f"AGC filter range step: {AGC_RANGE_STEP}", file=opts.log)
    print(f"AGC filter range start: {opts.start_agc}", file=opts.log)
    print(f"AGC filter range limit: {opts.limit}", file=opts.log)
    print(f"AGC peak/4:target range: {opts.agc_peak4_ratio}", file=opts.log)
    print(file=opts.log)
    print(f"Gains file: {opts.dc_gains} (format {opts.format})", file=opts.log)

    return opts


def process_row(gains, lanes_up, row, agc_range, p4t_low, p4t_high, verbose):
    """
    Process one row of valid range or collected coarse data

    gains maps lanes to sets of valid gains and is updated in place. row
    is be a row of collected coarse data: use agc_range, p4t_low, and
    p4t_high with the "agc1Ctl", "agcPeak4", and "agcTarg" fields to
    determine which are valid and identify the gains using "dcGain" or
    "txFirEh*" fields.
    """
    if "txLane" not in row:
        out.error("Invalid input file, no TX lane found in", row)
    lane = row["txLane"]
    gSet = gains.setdefault(lane, set())
    if "agc1Ctl" in row and "agcPeak4" in row and "agcTarg" in row:
        up = int(row.get("sToUp",1)) >= 0 and row.get("linkUp","Y") != "N"
        agc = int(row['agc1Ctl'])
        agcTarg = int(row['agcTarg'])
        p4t = float(row['agcPeak4']) / agcTarg if agcTarg > 0 else 0
        if up:
            lanes_up.add(lane)

        if up and agc in agc_range and p4t_low <= p4t <= p4t_high:
            if "dcGain" in row:
                gSet.add(int(row["dcGain"]))
            elif ("txFirEh[1]" in row
                  or "txFirEh[2]" in row
                  or "txFirEh[3]" in row
                  or "txFirEhM1" in row
                  or "txFirEh[0]" in row):
                gSet.add(sum(int(row.get(f"txFirEh{i}", 0))
                          for i in ("[1]", "[2]", "[3]", "M1", "[0]")))
            else:
                out.error("Invalid input file, no DC gain info for", lane)
            if verbose:
                print("Found valid DC Gain for", lane)
        elif verbose:
            print("Detected invalid DC Gain for", lane)
    else:
        out.error("Invalid input file, no DC gain info for", lane)

def process_files(files,
                  starting_agc_range=DEFAULT_AGC_RANGE,
                  agc_range_limit=DEFAULT_AGC_RANGE_LIMIT,
                  p4t_range=DEFAULT_P4T_RANGE,
                  verbose=False,
                  ignore_always_down_lanes=False):
    """
    Process all input files and return a combined set of valid gains

    Input files should consist of collected coarse data. agc_range and
    p4t_range specify the criteria for valid lanes.

    The combined set of valid gains is the intersection of the results
    from each file.
    """
    gains = {}

    data_rows = {file.name: data.Reader(file).data() for file in files}

    first_pass = True
    found_all_gains = False

    agc_range = starting_agc_range
    always_failing_lanes = set()

    while not found_all_gains:
        print(f"searching for gains with agc range {agc_range}")
        for filename, rows in data_rows.items():
            per_file_gains = {}
            per_file_lanes_up = set()
            for row in rows:
                process_row(per_file_gains,
                            per_file_lanes_up,
                            row,
                            range(agc_range[0], agc_range[1]+1),
                            p4t_range[0],
                            p4t_range[1],
                            verbose)

            for lane, gSet in per_file_gains.items():
                if lane in per_file_lanes_up:
                    gRangeSet = set(range(min(gSet), max(gSet) + 1)) if gSet else set()
                    if lane in gains:
                        gains[lane] &= gRangeSet
                    else:
                        gains[lane] = gRangeSet
                else:
                    if ignore_always_down_lanes:
                        if first_pass:
                            out.warn(f"Lane {lane} always down in {filename}, ignoring")
                    else:
                        if first_pass:
                            out.warn(f"Lane {lane} always down in {filename}")
                        gains[lane] = set()
                        always_failing_lanes.add(lane)

        first_pass = False

        if agc_range == agc_range_limit:
            break

        agc_range = (max(agc_range_limit[0], agc_range[0] + AGC_RANGE_STEP[0]),
                     min(agc_range_limit[1], agc_range[1] + AGC_RANGE_STEP[1]))

        lanes_missing = False
        for lane in list(gains.keys()):
            if not gains[lane] and lane not in always_failing_lanes:
                del gains[lane]
                lanes_missing = True

        found_all_gains = not lanes_missing

    return gains


def report(gains,
           gain_file=DEFAULT_GAIN_FILE,
           odd_even_breakpoint=30):
    """
    Format selected gains into output files

    If all lanes have valid ranges, generate a selected gains file
    containing the midpoints of all valid ranges. Gains above
    odd_even_breakpoint are limited to even numbers only.
    """
    lanes_missing = False
    for lane, gSet in sorted(gains.items()):
        if not gSet:
            out.warn("Lane", lane, "has no valid DC Gains")
            lanes_missing = True

    if lanes_missing:
        return False

    print("DC Gain selection complete, outputting to", gain_file)
    with open(gain_file, "w") as file:
        table = data.Writer(file,
                            "txLane".ljust(len("0x00000000:0:0,0")),
                            "dcGain")
        for lane, gSet in sorted(gains.items()):
            if gSet:
                midpoint = statistics.mean((min(gSet),max(gSet)))
                if midpoint > odd_even_breakpoint:
                    val = int(midpoint) + int(midpoint) % 2
                else:
                    val = round(midpoint)
                table.add_row(lane, val)

    return True


def main():
    """Entry point: perform all script actions"""
    opts = parse_command_line()
    gains = process_files(opts.files,
                          starting_agc_range=opts.start_agc,
                          agc_range_limit=opts.limit,
                          p4t_range=opts.agc_peak4_ratio,
                          verbose=opts.verbose,
                          ignore_always_down_lanes=opts.ignore_always_down_lanes)
    if gains:
        ok = report(gains, gain_file=opts.dc_gains)

    gain_result = "GENERATED" if gains and ok else "NOT generated"
    print(f"Gains file {gain_result}", file=opts.log)

if __name__ == "__main__":
    main()
