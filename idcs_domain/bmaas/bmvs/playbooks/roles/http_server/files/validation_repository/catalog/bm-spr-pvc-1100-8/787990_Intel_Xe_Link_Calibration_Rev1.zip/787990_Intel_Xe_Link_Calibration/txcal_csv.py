#!/usr/bin/env python3

# Copyright (C) 2023 Intel Corporation
# SPDX-License-Identifier: MIT

#
# This module requires the 'igsc' tool be installed (and in the PATH) to
# validate data on PVC devices.
#
# As a program, this module validates and extracts PVC PSC/TXCAL blob data.
#
# As a library module, split_blob() validates and extracts PSC and TXCAL data
# from a blob (e.g., as returned by mei_access.existing_blob_data()), and
# get_file_data() uses it to collect PSC and TXCAL blobs from a set of files,
# returning the last valid data of each type encountered.
#

"""Recreate link margin summary CSV file from Tx calibration blob"""

import argparse
import csv
from pathlib import Path
import socket
import struct
import sys

#
# CONSTANTS
#

# Tool details
SUMMARY = "Create link margin summary CSV file from Tx calibration blob"
DETAIL = """
Extract Tx GUID and lane information from Tx calibration blob information and
use it in conjunction with DEBUGFS information to create a link margin summary
CSV file matching the one that created it. Only 'tx guid', 'delay', 'revpd',
'result', and the lane number portion of 'tx lane' can be determined directly
from the calibration data. However, if this system was used to create the
original summary file, it should be possible to recreate every field except
'testing details'.
"""

# Mapping error message
MAP_ERROR = "WARNING: mappings will be limited"

# Corresponds to string data "Xe Tx Cal Blob\0\0"
TXCAL_BLOB_MAGIC = (0x54206558, 0x61432078, 0x6c42206c, 0x0000626f)

# Supported TXCAL version
TXCAL_VERSION_CURRENT = 1

# TXCAL blob contents
TXCAL_HDR_FMT = "<IIIIIIIIIIII"
TXCAL_SETTINGS_FMT = "<QHHHHHHHH"
TXCAL_HDR_SIZE = struct.calcsize(TXCAL_HDR_FMT)
TXCAL_SETTINGS_SIZE = struct.calcsize(TXCAL_SETTINGS_FMT)

# decoding of per-nibble tx configuration settings
DECODE_DELAY = {0x0: 3, 0x4: 1, 0x8: 15, 0xc: 7}

# CSV dialects
csv.register_dialect('csv', delimiter=',', lineterminator='\n')

# summary file contents
SUMMARY_COLUMNS = [
    "host name",
    "tx lane",
    "result",
    "delay",
    "revpd",
    "testing details",
    "tx guid",
    "rx lane",
    "rx guid",
]


#
# CLASSES
#

class TxCalCsvOpts:
    """
    Summary CSV creation options. To specify options directly, inherit this
    class or instantiate an object and override specific properties.
    """
    # Also used to set parse_command_line() defaults:
    output = "margin_summary.csv"
    host_name = socket.gethostname()

    def __init__(self, **args):
        """Instantiate an options object with optional overrides"""
        self.__dict__.update(args)


class Port:
    """A single port on a subdevice"""
    # pylint: disable=too-many-instance-attributes

    port_ids = {}

    @classmethod
    def find_forward_swizzles(cls):
        """Match up all ports to their neighbors"""
        for port in cls.port_ids.values():
            try:
                reverse_swizzle = enumerate(port.neighbor.rx_swizzle)
                port.tx_swizzle = {int(d): i for i, d in reverse_swizzle}
            except (AttributeError, TypeError):
                print(f"{MAP_ERROR}: incomplete neighbor/swizzle data", file=sys.stderr)

    @staticmethod
    def normalize_id(i):
        """convert arbitrary port identifier to standard form"""
        first, rest = i.split(":", 1)
        try:
            device = f"0x{int(first, 16):08x}"
        except (AttributeError, ValueError):
            device = first
        return f"{device}:{rest}"

    @classmethod
    def find(cls, port_id):
        """find the port with a given identifier"""
        return cls.port_ids[cls.normalize_id(port_id)]

    def __init__(self, sd, node):
        self.subdevice = sd
        self.node = node
        self.port_info = parse_info(node / "port_show")

        self.number = int(self.port_info.get("Port Number", node.suffix[1:]))
        if self.number != int(node.suffix[1:]):
            print(f"{MAP_ERROR}: unexpected port number for {node}", file=sys.stderr)

        self.ident = f"0x{sd.dev.fabric_id:08x}:{sd.attach}:{self.number}"
        if self.ident in self.port_ids:
            print(f"{MAP_ERROR}: duplicate port ID {self.ident}", file=sys.stderr)
        self.port_ids[self.ident] = self

        remote_tx_lanes = node / "remote_tx_lanes"
        lanes = remote_tx_lanes.read_text().strip().split()
        self.rx_swizzle = [None if s in ("x", "?") else int(s) for s in lanes]

        # to be filled in after all subdevices/ports are identified
        self.neighbor = None
        # to be filled in after all neighbors are identified
        self.tx_swizzle = range(4)

    def neighbor_guid(self):
        """Neighbor GUID from port info"""
        if self.port_info["Neighbor GUID"]:
            return int(self.port_info["Neighbor GUID"], 16)
        return None

    def neighbor_port(self):
        """Neighbor port number from port info"""
        if self.port_info['Neighbor Port Number']:
            return int(self.port_info['Neighbor Port Number'])
        return None

    def __repr__(self):
        return f"Port<{self.node}>"


class Subdevice:
    """A single subdevice/tile on a device"""

    guids = {}

    @classmethod
    def find_neighbors(cls):
        """Match up all ports to their neighbors"""
        for subdevice in cls.guids.values():
            for port_number, port in subdevice.ports.items():
                try:
                    neighbor_sd = cls.guids[port.neighbor_guid()]
                    port.neighbor = neighbor_sd.ports[port.neighbor_port()]
                except (KeyError, AttributeError):
                    if port.neighbor_guid() or port.neighbor_port():
                        print(f"WARNING: {subdevice.guid:#016x} port {port_number} has",
                              f"unrecognized neighbor {port.neighbor_guid():#016x}",
                              f"port {port.neighbor_port()}", file=sys.stderr)

    @classmethod
    def find(cls, guid):
        """find the subdevice with a given guid"""
        return cls.guids[guid]

    def __init__(self, dev, node):
        self.dev = dev
        self.node = node
        self.attach = node.suffix[1:]
        self.ident = f"0x{dev.fabric_id:08x}:{self.attach}"

        self.guid = int(parse_info(node / "switchinfo")["IAF GUID"], 16)

        if self.guid in self.guids:
            print(f"{MAP_ERROR}: duplicate subdevice GUID", file=sys.stderr)

        self.guids[self.guid] = self

        self.ports = {}

        # port_show is only present for fabric ports
        for port_node in port_subnodes(node):
            if parse_info(port_node / "port_show")["Port Type"] != "DISCONNECTED":
                port = Port(self, port_node)
                self.ports[port.number] = port

    def __repr__(self):
        return f"Subdevice<{self.node}>"


class Device:
    """A single IAF device"""

    nodes = {}

    @classmethod
    def find_devices(cls):
        """gather device/subdevice/port information for all IAF devices"""

        for node in device_nodes():
            try:
                cls(node)
            except (FileNotFoundError, AttributeError, KeyError):
                print(f"{MAP_ERROR}: error processing {node}", file=sys.stderr)

        Subdevice.find_neighbors()
        Port.find_forward_swizzles()

    def __init__(self, node):
        self.node = node
        self.nodes[node.name] = node
        id_path = node / "fabric_id"
        self.fabric_id = int(id_path.read_text().strip(), 16)

        self.sds = {}
        for sd_dir in subdevice_subnodes(node):
            self.sds[sd_dir.name] = Subdevice(self, sd_dir)

    def __repr__(self):
        return f"Device<{self.node}>"


#
# FUNCTIONS
#

def check_opts(opts):
    """validate and clean up option values"""
    if isinstance(opts.output, str):
        opts.output = argparse.FileType('wb')(opts.output)

    return opts


def parse_command_line(defaults=TxCalCsvOpts):
    """Parse command line options"""

    def help_format(prog):
        """preferred help format"""
        return argparse.HelpFormatter(prog, max_help_position=40)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
        "input",
        type=argparse.FileType('rb'),
        metavar="BLOB",
        help="TX calibration blob file"
    )

    parser.add_argument(
        '-o', '--output',
        type=argparse.FileType('w'),
        metavar="FILE",
        default=defaults.output,
        help=f"specify summary CSV output file (default: {defaults.output})"
    )

    parser.add_argument(
        '--host-name',
        metavar="HOST",
        default=defaults.host_name,
        help=f"specify host name in output (default: {defaults.host_name})"
    )

    return check_opts(parser.parse_args())


def device_nodes():
    """iterate over all device DEBUGFS entries"""
    root = Path("/sys/kernel/debug/iaf")

    if not root.exists():
        print(f"{root} not accessible: check iaf module,",
              "debugfs mount, and user permissions", file=sys.stderr)
        sys.exit(1)

    return iter(f.parent for f in root.glob("*iaf.*/fabric_id") if f.is_file)


def subdevice_subnodes(node):
    """iterate over a device's subdevice DEBUGFS entries"""
    return iter(d for d in node.glob("sd.*") if d.is_dir())


def port_subnodes(node):
    """iterate over a subdevice's port DEBUGFS entries"""
    return iter(f.parent for f in node.glob("port.*/port_show") if f.is_file())


def parse_info(path):
    """Convert switch or port info sysfs entry into a dict"""
    result = {}
    for row in path.read_text().split("\n"):
        line = row.strip()
        if not line:
            continue
        field, value = line.split(":")
        name = field.strip()
        val = value.strip()
        result[name] = val if val != "N/A" else None

    return result


def crc32c(byte_data, crc=0):
    """Compute CRC32C for an array of bytes"""

    crc32c_polynomial = 0x82f63b78

    for each_byte in byte_data:
        crc ^= each_byte
        for _ in range(8):
            crc = (crc >> 1) ^ (crc32c_polynomial if crc & 1 else 0)

    return crc


def data_chunks(blob, count, size):
    """split a data block into fixed-size chunks"""
    return iter(blob[size * i:size * (i + 1)] for i in range(count))


def decode_lane(nibble):
    """decode calibration data for one lane (result, delay, revpd)"""
    return (bool(nibble & 2), DECODE_DELAY[nibble & 0xc], nibble & 1)


def decode_lanes(halfword):
    """decode calibration data for all lanes on a port"""
    return [decode_lane((halfword >> (4 * lane)) & 0xf) for lane in range(4)]


def decode_cal(all_sd_data):
    """decode calibration data for all subdevices"""
    calibration_data = {}

    for sd_data in all_sd_data:
        guid, *ports = struct.unpack(TXCAL_SETTINGS_FMT, sd_data)
        calibration_data[guid] = [decode_lanes(pd) for pd in ports]

    return calibration_data


def get_raw_txcal(blob):
    """Decompile TX calibration blob into summary CSV file"""

    if len(blob) < TXCAL_HDR_SIZE:
        print("ERROR: blob too small for a TXCAL data file", file=sys.stderr)
        return None

    hdr_data = struct.unpack(TXCAL_HDR_FMT, blob[:TXCAL_HDR_SIZE])
    hdr_magic = hdr_data[:4]
    hdr_format = hdr_data[4]
    size, count, data_crc, hdr_crc = hdr_data[-4:]
    data_size = count * TXCAL_SETTINGS_SIZE
    cal_data = blob[TXCAL_HDR_SIZE:]

    if hdr_magic != TXCAL_BLOB_MAGIC:
        print("ERROR: blob is not a TXCAL data file", file=sys.stderr)
        return None

    computed_hdr_crc = crc32c(struct.pack(TXCAL_HDR_FMT[:-1], *hdr_data[:-1]))
    computed_data_crc = crc32c(cal_data[:data_size])

    if hdr_crc != computed_hdr_crc or data_crc != computed_data_crc:
        print("ERROR: TXCAL CRC error", file=sys.stderr)
        return None

    if hdr_format != TXCAL_VERSION_CURRENT:
        print(f"ERROR: unsupported TXCAL version {hdr_format}", file=sys.stderr)
        return None

    if size != TXCAL_HDR_SIZE + data_size or len(cal_data) < data_size:
        print("ERROR: mismatched TXCAL size", file=sys.stderr)
        return None

    return decode_cal(data_chunks(cal_data, count, TXCAL_SETTINGS_SIZE))


def decompile(blob, writer, opts=TxCalCsvOpts):
    """Decompile TX calibration blob into summary CSV file"""
    # pylint: disable=too-many-locals

    Device.find_devices()

    writer.writerow(SUMMARY_COLUMNS)

    for tx_guid, ports in get_raw_txcal(blob).items():
        try:
            subdevice_ident = Subdevice.find(tx_guid).ident
        except KeyError:
            subdevice_ident = "UNKNOWN:?"

        for port_number, port_data in enumerate(ports, start=1):
            tx_port_ident = f"{subdevice_ident}:{port_number}"
            try:
                port = Port.find(tx_port_ident)
                rx_port_ident = port.neighbor.ident
                tx_swizzle = port.tx_swizzle
                rx_guid = f"{port.neighbor.subdevice.guid:#016x}"
            except (KeyError, AttributeError):
                rx_port_ident = "UNKNOWN:?:?"
                tx_swizzle = "?" * 4
                rx_guid = "UNKNOWN"

            for lane, (valid, *lane_data) in enumerate(port_data):
                if valid:
                    writer.writerow([
                        opts.host_name,
                        f"{tx_port_ident}:{lane}",
                        "PASS",
                        *lane_data,
                        "UNKNOWN",
                        f"{tx_guid:#016x}",
                        f"{rx_port_ident}:{tx_swizzle[lane]}",
                        rx_guid
                    ])


def main():
    """script entry point"""
    opts = parse_command_line()
    blob = opts.input.read()
    writer = csv.writer(opts.output, dialect='csv')
    decompile(blob, writer, opts)


if __name__ == "__main__":
    main()
