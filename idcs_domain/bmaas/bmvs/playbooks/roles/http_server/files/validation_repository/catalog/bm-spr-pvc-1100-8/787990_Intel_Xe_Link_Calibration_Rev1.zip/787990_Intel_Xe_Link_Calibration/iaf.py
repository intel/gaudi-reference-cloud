#
# Copyright (C) 2022-2023 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""
IAF kernel module access

This module provides access to DebugFS entries, parameters, and other
data and controls for the IAF kernel module and IAF devices
"""

import argparse
import atexit
import collections.abc
import math
import os
import os.path
import pathlib
import sys

sys.dont_write_bytecode = True

# Prevent linters from complaining about local imports after code:
# pylint: disable=wrong-import-position

import valid_version  # noqa: E402
import out            # noqa: E402

# pylint: enable=wrong-import-position


# Tool details
SUMMARY = "DebugFS entries"
DETAIL = """Report information about IAF module paths"""


def debugfs_path():
    """
    Report path to debugFS (assumes default debugfs location: could
    check mount table if flexibility needed) and check accessibility
    """
    root = os.path.abspath("/sys/kernel/debug/iaf")
    if not os.path.exists(root):
        out.error(f"{root} not accessible: check iaf module,",
                  "debugfs mount, and user permissions")
    return root


def parameter_path():
    """
    Report path to IAF module parameters and check accessibility
    """
    root = os.path.abspath("/sys/module/iaf/parameters")
    if not os.path.exists(root):
        out.error(f"{root} not accessible: verify iaf module loaded")
    return root


def restore_parameter(parameter, value, file=None):
    """Atexit handler for automatically restoring module parameters"""
    if file:
        out.pr("Restoring", parameter, "to", value, file=file)
    try:
        with open(parameter, 'w') as node:
            node.write(value)
    except (FileNotFoundError, PermissionError):
        out.error(f"{parameter} not writable: check user permissions")


def disable_flapping_detection(file=None):
    """
    Set IAF module parameter to disable flapping detection and arrange
    for it to be restored to its original value on exit.
    """
    parameter = os.path.join(parameter_path(),
                             "link_flapping_leaky_bucket_period")
    try:
        with open(parameter) as node:
            value = node.read()
    except (FileNotFoundError, PermissionError):
        out.error(f"{parameter} not readable: check user permissions")

    if value == "0":
        return

    parameter = os.path.join(parameter_path(), "link_flapping_threshold")
    try:
        with open(parameter, 'r+') as node:
            value = node.read()

            if value != "0":
                atexit.register(restore_parameter, parameter, value, file)
                if file:
                    out.pr("Setting", parameter, "to 0\n", file=file)
                node.write("0")
    except (FileNotFoundError, PermissionError):
        out.error(f"{parameter} not readable and writable:",
                  "check user permissions")


def disable_routing(file=None):
    """
    Set IAF module parameter to disable routing and arrange for it to be
    restored to its original value on exit.
    """
    parameter = os.path.join(parameter_path(), "routing_disable")
    try:
        with open(parameter, 'r+') as node:
            value = node.read()

            if value != "Y":
                atexit.register(restore_parameter, parameter, value, file)
                if file:
                    out.pr("Setting", parameter, "to Y\n", file=file)
                node.write("Y")
    except (FileNotFoundError, PermissionError):
        out.error(f"{parameter} not readable and writable:",
                  "check user permissions")


def dla_enabled():
    """ Return True when DLA is enabled. Otherwise return False """
    parameter = os.path.join(parameter_path(), "firmware_roption")
    dla_disable_mask = 0x2000
    try:
        with open(parameter) as node:
            value = int(node.read())
    except (FileNotFoundError, PermissionError):
        out.error(f"{parameter} not readable: check user permissions")
    return not value & dla_disable_mask


class LaneId:
    """Lane identifier"""
    def __init__(self, *args):
        self.ident = ":".join(str(arg) for arg in args)

    def __repr__(self):
        return self.ident

    def components(self):
        """split lane identifier into its component parts"""
        return self.ident.split(":")

    def port_id(self):
        """extract port identifier from lane identifier"""
        return ":".join(self.ident.split(":")[:3])

    def lane_num(self):
        """extract lane number from lane identifier"""
        return int(self.ident.split(":")[3])

    # Size of lane identifier
    WIDTH = len("0x00000000:0:0:0")


def parse_info(path):
    """Convert switch or port info sysfs entry into a dict"""
    result = {}
    with open(path) as file:
        for row in file:
            line = row.strip()
            if not line:
                continue
            field, value = line.split(":")
            name = field.strip()
            val = value.strip()
            result[name] = val if val != "N/A" else None

    return result


class LcbCtrs(collections.abc.Mapping):
    """Read and encapsulate lcb_ctrs information for a port

    All data is automatically decoded and may be accessed as object
    attributes or using dict-like accessors: obj[] or obj.get(). For
    CRC_ERR_LNn, FEC_CERR_n, and FEC_ERR_LNn fields, the base name
    without a number can be used and an accessor is returned to map
    indices into the correct data.

    For access, field names ignore case and embedded underscores, so
    fieldName, field_name, and FIELD_NAME are equivalent.
    """

    def __init__(self, path):
        if isinstance(path, dict):
            self._data = path
        else:
            self._data = {}
            with open(path) as file:
                for line in file:
                    field, value = line.strip().split()
                    self._data[field.lower().replace("_", "")] = int(value)

    class ArrayAccessor:
        """Helper for array accesses"""

        def __init__(self, obj, name):
            self.obj = obj
            self.field = name

        def __getitem__(self, index):
            return self.obj[f"{self.field}{index}"]

        def get(self, name, default):
            """array-type get"""
            return self.obj.get(f"{self.field}{name}", default)

    def __getattr__(self, name, error_type=AttributeError):
        field = name.lower().replace("_", "")
        if field in self._data:
            return self._data[field]
        if f"{field}3" in self._data:
            # CRC_ERR_LNn, FEC_CERR_n, FEC_ERR_LNn:
            return self.ArrayAccessor(self._data, field)
        raise error_type(f"{self} has no attribute {name}")

    def __getitem__(self, name):
        return self.__getattr__(name, error_type=KeyError)

    def __len__(self):
        return len(self._data)

    def __iter__(self):
        return iter(self._data)

    def _diff(self, fld, other_data):
        """Subtract two wrapping counter values"""
        minuend = self._data[fld]
        subtrahend = other_data[fld]
        if minuend < subtrahend:
            # if the minuend is smaller than the subtrahend, assume that it
            # wrapped, that the subtrahend is in the upper half of the field
            # range, and that the field size is a power of 2
            field_size = math.floor(math.log2(subtrahend)) + 1
            minuend += 2 ** field_size
        return minuend - subtrahend

    def __sub__(self, other):
        """Subtract one set of counters from another"""
        return self.__class__({f: self._diff(f, other._data) for f in self._data})

    def get(self, key, default=None):
        """dictionary-style get"""
        try:
            return self.__getattr__(key)
        except (KeyError, AttributeError):
            return default

    def zero(self):
        """Return a copy with all counter values set to 0"""
        return self.__class__({fld: 0 for fld in self._data.keys()})


class EqInfo(collections.abc.Mapping):
    """
    Read and encapsulate serdes_eqinfo information for a port

    All data is automatically decoded and may be accessed as object
    attributes or using dict-like accessors: obj[] or obj.get(). For
    fields ending in [N] (e.g., HCNTR[4]), the base name can also be
    used and an accessor is returned to map indices into the correct
    data.

    For access, field names ignore case and embedded underscores, so
    fieldName, field_name, and FIELD_NAME are equivalent.
    """

    def __init__(self, path):

        def signed_hex(bits):
            def function(txt):
                val = int(txt, 16) & ((1 << bits) - 1)
                return val if val < 1 << (bits - 1) else val - (1 << bits)
            return function

        def unsigned_hex(txt):
            return int(txt, 16)

        decoder = {"cdrIntg": signed_hex(8),
                   "cdrPhErrFlt": signed_hex(16),
                   "pphm": signed_hex(32),
                   "hcntr[0]": signed_hex(6),
                   "hcntr[1]": signed_hex(6),
                   "hcntr[2]": signed_hex(6),
                   "hcntr[3]": signed_hex(6),
                   "hcntr[4]": signed_hex(6),
                   "cntrChEst[0]": signed_hex(16),
                   "cntrChEst[1]": signed_hex(16),
                   "cntrChEst[2]": signed_hex(16),
                   "cntrChEst[3]": signed_hex(16),
                   "cntrChEst[4]": signed_hex(16),
                   "eqTarg[0]": signed_hex(16),  # FW sign extends to 16 bits
                   "eqTarg[1]": signed_hex(16),  # FW sign extends to 16 bits
                   "eqTarg[2]": signed_hex(16),  # FW sign extends to 16 bits
                   "eqTarg[3]": signed_hex(16),  # FW sign extends to 16 bits
                   "dfeNthr[0]": signed_hex(16),
                   "dfeNthr[1]": signed_hex(16),
                   "dfeZthr[0]": signed_hex(16),
                   "dfeZthr[1]": signed_hex(16),
                   "dfePthr[0]": signed_hex(16),
                   "dfePthr[1]": signed_hex(16),
                   "hffe[0]": signed_hex(16),
                   "hffe[1]": signed_hex(16),
                   "hffe[2]": signed_hex(16),
                   "hffe[3]": signed_hex(16),
                   "hffe[4]": signed_hex(16),
                   "hffe[5]": signed_hex(16),
                   "hffe[6]": signed_hex(16),
                   "hffe[7]": signed_hex(16),
                   "hffe[8]": signed_hex(16),
                   "hffe[9]": signed_hex(16),
                   "hffe[10]": signed_hex(16),
                   "hffe[11]": signed_hex(16),
                   "hffe[12]": signed_hex(16),
                   "hffe[13]": signed_hex(16),
                   "hffe[14]": signed_hex(16),
                   "hffe[15]": signed_hex(16),
                   "hffe[16]": signed_hex(16),
                   "hffe[17]": signed_hex(16),
                   "hffe[18]": signed_hex(16),
                   "hffe[19]": signed_hex(16),
                   "hffe[20]": signed_hex(16),
                   "hffe[21]": signed_hex(16),
                   "hffe[22]": signed_hex(16),
                   "hffe[23]": signed_hex(16),
                   "hffe[24]": signed_hex(16),
                   "hffe[25]": signed_hex(16),
                   "hffe[26]": signed_hex(16),
                   "hffe[27]": signed_hex(16),
                   "hffe[28]": signed_hex(16),
                   "hffe[29]": signed_hex(16),
                   "gf0": signed_hex(32),
                   "hdfe": signed_hex(16),
                   "txFirEh[0]": signed_hex(8),
                   "txFirEh[1]": signed_hex(8),
                   "txFirEh[2]": signed_hex(8),
                   "txFirEh[3]": signed_hex(8),
                   "txFirEhM1": signed_hex(8)}

        self._data = {}
        self.port = None
        with open(path) as file:
            for line in file:
                cols = line.strip().split()
                if len(cols) == 5:
                    name, *lanes = cols
                    field = name.lower().replace("_", "")
                    field = field.replace("[", "").replace("]", "")
                    decode = decoder.get(name, unsigned_hex)
                    self._data[field] = [decode(lane) for lane in lanes]
                elif len(cols) == 3 and cols[:2] == ["Logical", "Port"]:
                    self.port = int(cols[2])

    class _ArrayAccessor:
        """Helper for array accesses"""

        def __init__(self, obj, name):
            self.obj = obj
            self.field = name

        def __getitem__(self, index):
            return self.obj[f"{self.field}{index}"]

        def get(self, name, default):
            """array-type get"""
            return self.obj.get(f"{self.field}{name}", default)

    def __getattr__(self, name, error_type=AttributeError):
        field = name.lower().replace("_", "").replace("[", "").replace("]", "")
        if field in self._data:
            return self._data[field]
        if f"{field}0" in self._data:
            return self._ArrayAccessor(self._data, field)
        raise error_type(f"{self} has no attribute {name}")

    def __getitem__(self, name):
        return self.__getattr__(name, error_type=KeyError)

    def __len__(self):
        return len(self._data)

    def __iter__(self):
        return iter(self._data)

    def get(self, key, default=None):
        """dict-type get"""
        try:
            return self.__getattr__(key)
        except (KeyError, AttributeError):
            return default


# This class is too large and should be split. For now, disable lint errors:
# pylint: disable=too-many-public-methods disable=too-many-instance-attributes

class Port:
    """A single port on a subdevice"""

    port_ids = {}
    health_up = set(("HEALTHY", "DEGRADED"))
    DCC_TO_PNB = [(0x00, 0x00), (0x00, 0x01), (0x00, 0x03), (0x00, 0x07),
                  (0x00, 0x0f), (0x00, 0x1f), (0x00, 0x3f), (0x00, 0x7f),
                  (0x01, 0x7f), (0x03, 0x7f), (0x07, 0x7f), (0x0f, 0x7f),
                  (0x1f, 0x7f), (0x3f, 0x7f), (0x7f, 0x7f)]
    PNB_TO_DCC = {val: idx for idx, val in enumerate(DCC_TO_PNB)}

    @staticmethod
    def normalize_id(i):
        """convert arbitrary port identifier to standard form"""
        first, rest = i.split(":", 1)
        try:
            device = f"0x{int(first, 16):08x}"
        except AttributeError:
            device = first
        return f"{device}:{rest}"

    @classmethod
    def find(cls, port_id):
        """find the port with a given identifier"""
        return cls.port_ids[cls.normalize_id(port_id)]

    @classmethod
    def find_by_lane_id(cls, lane_id_or_str, available_ports):
        """find the port and lane with a given identifier"""
        lane_id = LaneId(lane_id_or_str)
        port, lane = cls.port_ids[lane_id.port_id()], lane_id.lane_num()
        return (port, lane) if port.path in available_ports else (None, None)

    @staticmethod
    def filter_list(port_list, ids):
        """filter a port list to a given set of identifiers"""
        valid_port_ids = set(":".join(i.split(":")[:3]) for i in ids)
        for path, port in list(port_list.items()):
            if port.ident not in valid_port_ids:
                del port_list[path]

    def __init__(self, sd, path, port_info):
        self.subdevice = sd
        self.path = path
        self.lcb_data = self.lcb_ctrs()
        self.lcb_start = self.lcb_data.zero()
        self.eq_data = self.eq_info()

        self.number = port_info.get("Port Number", path.suffix[1:])
        if self.number != path.suffix[1:]:
            out.port_warn(self, f"unexpected port number for {path}")

        self.ident = f"{sd.dev.fabric_id}:{sd.attach}:{self.number}"
        if self.ident in self.port_ids:
            out.port_error(self, "duplicate port ID found")
        self.port_ids[self.ident] = self

        with open(path.joinpath("remote_tx_lanes")) as rtx:
            lanes = rtx.read().strip().split()
        self.rx_swizzle = [None if s in ("x", "?") else int(s) for s in lanes]

        enable_path = path.joinpath("enable")
        if not os.path.exists(enable_path):
            out.port_error(self,
                           f"{enable_path} not found.",
                           "Newer IAF driver required")

        self._update_state(port_info)

        self.up_at = 0 if self.up() else -1

        self.port_type = port_info["Port Type"]
        self.neighbor_guid = port_info["Neighbor GUID"]
        self.neighbor_port = port_info['Neighbor Port Number']
        self.initial_fec_mode = port_info["FEC Mode"]

        # to be filled in after all subdevices are identified
        self.neighbor = None

    def __getattr__(self, name, error_type=AttributeError):
        """find an attribute which may be in eq/lcb data"""
        if name in self.__dict__:
            return self.__dict__[name]
        if name in self.eq_data:
            return self.eq_data[name]
        if name in self.lcb_data:
            return self.lcb_data[name]
        raise error_type(f"{self} has no attribute {name}")

    def _update_state(self, port_info):
        self.phy_state = port_info["FW Phys State"]
        self.log_state = port_info["FW Link State"]
        self.health = port_info["Port Health"]

        if port_info["Tx Width"]:
            self.tx_width = int(port_info["Tx Width"].rstrip("X"))
        else:
            self.tx_width = 0
        if port_info["Rx Width"]:
            self.rx_width = int(port_info["Rx Width"].rstrip("X"))
        else:
            self.rx_width = 0
        self.speed = port_info["Link Speed"]
        self.crc_mode = port_info["CRC Mode"]
        self.fec_mode = port_info["FEC Mode"]

        self.tx_packet_count = port_info["TX Packet Count"]
        self.rx_packet_count = port_info["RX Packet Count"]
        self.link_down_count = port_info["Link Down Count"]
        self.error_recovery_count = port_info["Error Recovery Count"]
        self.tx_replays = port_info["TX Replays"]
        self.rx_replays = port_info["RX Replays"]
        self.rx_fec_corr_count = port_info["RX FEC Corr Count"]
        self.link_quality = port_info["Link Quality"]
        self.link_up_ms = port_info["Link Up Milliseconds"]

    def update(self):
        """Update port state (can chain with attribute access)"""
        self._update_state(parse_info(self.path.joinpath("port_show")))
        return self

    def update_eq(self):
        """update equalization data"""
        self.eq_data = self.eq_info()
        return self

    def start_lcb(self):
        """save starting LCB data for error counting"""
        self.lcb_start = self.lcb_ctrs()
        return self

    def update_lcb(self):
        """update LCB data for error counting"""
        current_lcb_ctrs = self.lcb_ctrs()
        self.lcb_data = current_lcb_ctrs - self.lcb_start
        self.lcb_start = current_lcb_ctrs
        return self

    def update_lcb_raw(self):
        """update LCB data with current raw/total error counts"""
        self.lcb_data = self.lcb_ctrs()
        return self

    def lcb_ctrs(self):
        """return LCB data"""
        return LcbCtrs(self.path.joinpath("lcb_ctrs"))

    def eq_info(self):
        """return equalization data"""
        return EqInfo(self.path.joinpath("serdes_eqinfo"))

    # Disable lint warnings about "up" not being snake-case
    # pylint: disable=invalid-name

    def up(self):
        """report whether port is up"""
        return self.health in self.health_up

    # pylint: enable=invalid-name

    def down(self):
        """report whether port is down"""
        return self.health not in self.health_up

    def lane_id(self, lane):
        """generate lane ID for port"""
        return f"{self.ident}:{lane}"

    def get_tx_tuning(self, lane):
        """get tx tuning value (IL/FIR table index)"""
        path = os.path.join(self.path, "tx_tuning_current")
        with open(path) as node:
            tunings = node.read().split()
        return int(tunings[lane])

    def set_tx_tuning(self, lane, value):
        """set tx tuning value (IL/FIR table index)"""
        path = os.path.join(self.path, "tx_tuning_current")
        tunings = ["-"] * 4
        tunings[lane] = str(value)
        with open(path, "w") as node:
            node.write(" ".join(tunings) + "\n")

    def get_tx_firs(self, lane):
        """get tx pre/main/post FIR coefficients"""
        path = os.path.join(self.path, f"txfir_current_lane{lane}")
        with open(path) as node:
            tunings = node.read().split()
        return [int(i) for i in tunings[2:]]

    def set_tx_firs(self, lane, firs):
        """set tx pre/main/post FIR coefficients"""
        path = os.path.join(self.path, f"txfir_current_lane{lane}")
        tunings = [0] * 2 + list(firs)
        with open(path, "w") as node:
            node.write(" ".join(str(i) for i in tunings) + "\n")

    def enabled(self):
        """port enable"""
        path = os.path.join(self.path, "enable")
        with open(path) as node:
            return node.read().strip() == "Y"

    def set_enable(self, enabled):
        """port enable"""
        path = os.path.join(self.path, "enable")
        with open(path, "w") as node:
            node.write("Y\n" if enabled else "N\n")


    def enable_pair(self):
        """enable both port and neighbor port"""
        self.set_enable(True)
        self.neighbor.set_enable(True)

    def disable_pair(self):
        """disable both port and neighbor port"""
        try:
            self.set_enable(False)
            self.neighbor.set_enable(False)
        except BlockingIOError:
            out.warn("Detected application workload traffic. Cannot continue testing.")
            out.warn("Please stop your application and restart the driver and rerun the test.")
            out.error("Stopping...")

    def get(self, name, default=None):
        """get arbitrary data from port"""
        if name in self.eq_data:
            return self.eq_data[name]
        if name in self.lcb_data:
            return self.lcb_data[name]
        if name in self.__dict__:
            return self.__dict__[name]
        return default

    def get_lane(self, name, lane, default=None):
        """get arbitrary per-lane data from port"""
        if name in self.eq_data:
            val = self.eq_data[name][lane]
        elif name in self.lcb_data:
            val = self.lcb_data[name]
            if isinstance(val, LcbCtrs.ArrayAccessor):
                val = val[lane]
        elif name in self.__dict__:
            val = self.__dict__[name]
            if isinstance(val, (dict, list)):
                val = val[lane]
        else:
            val = default
        return val

    def get_maint_mode(self):
        """port maint mode"""
        path = os.path.join(self.path, "maint_mode")
        with open(path) as node:
            return node.read().strip()

    def set_maint_mode(self, value):
        """port maint mode"""
        path = os.path.join(self.path, "maint_mode")
        with open(path, "w") as node:
            node.write(f"{value}")

    def get_tx_dcc_interp(self, lane):
        """per-lane tx_dcc_interp values"""
        path = os.path.join(self.path, f"tx_dcc/interp_lane{lane}")
        if not os.path.exists(path):
            path = os.path.join(self.path, f"tx_dcc_interp_lane{lane}")
        return parse_info(path)

    def get_tx_dcc_index(self, lane):
        """per-lane current DCC index"""
        interp = self.get_tx_dcc_interp(lane)
        return self.PNB_TO_DCC[int(interp["dccp"]), int(interp["dccnb"])]

    def set_tx_dcc_index(self, lane, index):
        """per-lane current DCC index"""
        path = os.path.join(self.path, f"tx_dcc/index_lane{lane}")
        if not os.path.exists(path):
            path = os.path.join(self.path, f"tx_dcc_index_lane{lane}")
        with open(path, "w") as node:
            node.write(f"{index}")

    def get_tx_dcc_margin_params(self):
        """port dcc margin params"""
        path = os.path.join(self.path, "tx_dcc/margin_params")
        if not os.path.exists(path):
            path = os.path.join(self.path, "tx_dcc_margin_params")
        with open(path) as node:
            return int(node.read().strip())

    def set_tx_dcc_margin_params(self, value):
        """port dcc margin params"""
        path = os.path.join(self.path, "tx_dcc/margin_params")
        if not os.path.exists(path):
            path = os.path.join(self.path, "tx_dcc_margin_params")
        with open(path, "w") as node:
            node.write(f"{value}")

    def set_tx_dcc_margin_lane_params(self, lane, delay, reverse_pd):
        """port dcc margin params"""
        value = self.get_tx_dcc_margin_params()
        mux_value = {1: 0x4, 3: 0x0, 7: 0xc, 15: 0x8}[delay]
        phase_value = 0x3 if reverse_pd else 0x2
        lane_value = (mux_value | phase_value) << (lane * 4)
        lane_mask = 0xf << (lane * 4)
        value = (value & ~lane_mask) | lane_value
        self.set_tx_dcc_margin_params(value)

    def get_tx_dcc_override_interp(self, lane):
        """port interp override value"""
        path = os.path.join(self.path, f"tx_dcc/interp_override_lane{lane}")
        if not os.path.exists(path):
            return 0
        with open(path) as node:
            return int(node.read().strip())

    def set_tx_dcc_override_interp(self, lane, interp):
        """port interp override value"""
        path = os.path.join(self.path, f"tx_dcc/interp_override_lane{lane}")
        if not os.path.exists(path):
            return
        with open(path, "w") as node:
            node.write(f"{interp % 128}")

    def get_tx_dcc_override_interp_enable(self, lane):
        """port interp override enable"""
        path = os.path.join(self.path, f"tx_dcc/interp_override_enable_lane{lane}")
        if not os.path.exists(path):
            return 0
        with open(path) as node:
            return bool(node.read().strip())

    def set_tx_dcc_override_interp_enable(self, lane, value):
        """port interp override enable"""
        path = os.path.join(self.path, f"tx_dcc/interp_override_enable_lane{lane}")
        if not os.path.exists(path):
            return
        with open(path, "w") as node:
            node.write(f"{int(value)}")

# pylint: enable=too-many-public-methods enable=too-many-instance-attributes


class Subdevice:
    """A single subdevice/tile on a device"""

    guids = {}
    fw_versions = set()

    @classmethod
    def find_neighbors(cls):
        """Match up all ports to their neighbors"""
        for subdevice in cls.guids.values():
            for port in subdevice.ports.values():
                try:
                    neighbor_sd = cls.guids[port.neighbor_guid]
                    port.neighbor = neighbor_sd.ports[port.neighbor_port]
                except (KeyError, AttributeError):
                    if port.neighbor_guid or port.neighbor_port:
                        out.port_warn(port,
                                      "Unrecognized neighbor",
                                      port.neighbor_guid,
                                      "port",
                                      port.neighbor_port)

    def __init__(self, dev, path):
        self.dev = dev
        self.path = path
        self.attach = os.path.splitext(path.name)[1][1:]

        self.guid = parse_info(path.joinpath("switchinfo"))["IAF GUID"]
        self.fw_version = parse_info(path.joinpath("fw_version"))["FW Version"]
        self.fw_versions.add(self.fw_version)

        if self.guid in self.guids:
            out.sd_error(self, "duplicate subdevice GUID found")

        self.guids[self.guid] = self

        self.ports = {}

        # port_show is only present for fabric ports
        for fil in (f for f in path.glob("port.*/port_show") if f.is_file()):
            port_path = fil.parent
            port_info = parse_info(fil)
            if port_info['Port Type'] != "DISCONNECTED":
                port = Port(self, port_path, port_info)
                self.ports[port.number] = port

    def __repr__(self):
        return f"Subdevice<{self.path}>"


class Device:
    """A single IAF device"""

    def __init__(self, path):
        self.path = path
        id_path = os.path.join(path, "fabric_id")
        with open(id_path) as node:
            self.fabric_id = node.read().strip()

        self.sds = {}
        for sd_dir in (d for d in path.glob("sd.*") if d.is_dir()):
            self.sds[sd_dir.name] = Subdevice(self, sd_dir)

    def __repr__(self):
        return f"Device<{self.path}>"

    def __str__(self):
        return f"Device<{self.path}>"


def get_devs():
    """gather device/subdevice/port information for all IAF devices"""

    devs = {}
    root = pathlib.Path(debugfs_path())
    for fid in (f for f in root.glob("*iaf.*/fabric_id") if f.is_file):
        try:
            dev_path = fid.parent
            devs[dev_path.name] = Device(dev_path)
        except (FileNotFoundError, AttributeError, KeyError):
            out.error(f"error processing {fid.parent},",
                      "newer IAF driver may be required")

    Subdevice.find_neighbors()

    return devs


def module_parameters():
    """retrieve all IAF module parameters"""
    parameters = {}
    for name in pathlib.Path(parameter_path()).glob('*'):
        with open(name) as value:
            parameters[name.name] = value.read().strip()
    return parameters


def main():
    """Entry point: perform script actions"""

    def help_format(prog):
        return argparse.ArgumentDefaultsHelpFormatter(prog,
                                                      max_help_position=40)

    version = valid_version.Version(__file__, throw_on_error=False)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument("-v", "--version",
                        action="version",
                        version=str(version),
                        help="report version and exit")

    parser.add_argument("-s", "--show",
                        choices=["debugfs", "parameter", "both"],
                        default="both",
                        metavar="ROOT",
                        help="show root of: debugfs, parameter, both")

    parser.add_argument("--verbose",
                        action="store_true",
                        help="show contents also")

    opts = parser.parse_args()

    if opts.show in ["debug", "both"]:
        print("DebugFS root:", debugfs_path())
        if opts.verbose:
            print("Contents:")
            for file in sorted(pathlib.Path(debugfs_path()).glob('*')):
                print(f" {file.name}")
    if opts.show in ["parameter", "both"]:
        print("Parameter root:", parameter_path())
        if opts.verbose:
            print("Contents:")
            parameters = sorted(module_parameters().items())
            parameter_dump = "\n ".join(f"{p}: {v}" for p, v in parameters)
            print(f" {parameter_dump}")


if __name__ == "__main__":
    main()
