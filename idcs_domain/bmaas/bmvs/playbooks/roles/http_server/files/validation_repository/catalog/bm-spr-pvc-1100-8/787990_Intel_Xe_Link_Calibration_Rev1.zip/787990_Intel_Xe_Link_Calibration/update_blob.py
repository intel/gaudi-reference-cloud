#!/usr/bin/env python3

# Copyright (C) 2023 Intel Corporation
# SPDX-License-Identifier: MIT

#
# This module requires the 'igsc' tool be installed (and in the PATH) to
# function.
#
# As a program, this module verifies and replaces PSC/TXCAL data on PVC
# devices. As a library module, update() provides the same service.
#

"""Update PSC and/or TXCAL blob data"""

import argparse
import sys
import tempfile

# Prevent Python from creating cache files for local libraries:
sys.dont_write_bytecode = True

import blob_extract
import mei_access


#
# CONSTANTS
#

# Tool details
SUMMARY = "Update PSC and/or TX CAL blob for PVC devices"
DETAIL = """
Verify PSC/TXCAL blob data from the PSC SPI region on PVC devices (first
verifying that they are all identical) and replace PSC and/or TXCAL data
using (the last valid) data of each type from the specified FILEs.
"""


#
# CLASSES
#

class UpdateBlobOpts(blob_extract.CommonBlobOpts):
    """
    Options for blob update. To specify options directly, inherit this class
    or instantiate an object and override specific properties.
    """
    # Options set but not used by parse_command_line():
    device = []
    files = []


#
# FUNCTIONS
#

def parse_command_line():
    """Parse command line options"""

    def help_format(prog):
        """preferred help format"""
        return argparse.HelpFormatter(prog, max_help_position=40)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
        "files",
        type=argparse.FileType('rb'),
        metavar="FILE",
        nargs="*",
        help="PSC, TXCAL, or combined blob"
    )

    parser.add_argument(
        '-d', '--device',
        type=mei_access.device_identifier,
        action='append',
        metavar="DEV",
        help="device (MEI device or fabric ID) to update (default: all)"
    )

    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help="suppress some informational messages"
    )

    parser.add_argument(
        '--keep-going',
        action='store_true',
        help="do not stop on errors"
    )

    parser.add_argument(
        '--no-txcal',
        action='store_true',
        help="remove/do not program TXCAL blob"
    )

    parser.add_argument(
        '--no-psc',
        action='store_true',
        help="remove/do not program PSC blob (implies --no-txcal)"
    )

    opts = parser.parse_args()

    if opts.no_psc:
        opts.no_txcal = True

    if not opts.files and not opts.no_txcal:
        print("ERROR: must specify at least one file or --no-txcal")
        sys.exit(2)

    return opts


def update(opts=UpdateBlobOpts):
    """Update selected devices with specified blob(s)"""
    # extract and validate new data to be written
    new_psc_blob, new_txcal_blob = blob_extract.get_file_data(opts.files, opts)

    if not new_psc_blob and not new_txcal_blob and not opts.no_txcal:
        print("ERROR: no PSC or TXCAL data in input files")
        sys.exit(50)

    # parse sysfs hierarchy
    spi = mei_access.get_spi_map(opts.device)

    # extract and update existing blob data
    blob_data = mei_access.existing_blob_data(spi, opts.keep_going)
    psc_blob, txcal_blob = blob_extract.split_blob(blob_data, opts)

    # update blob sections with new data provided
    psc_blob = new_psc_blob or psc_blob
    txcal_blob = new_txcal_blob or txcal_blob

    if txcal_blob and not psc_blob:
        print("ERROR: must have PSC data to write TXCAL blob")
        sys.exit(53)

    # use temporary file to program blob into all (specified) devices
    with tempfile.NamedTemporaryFile() as blob_file:
        blob_file.write(psc_blob + txcal_blob)
        blob_file.flush()

        for mei in spi:
            mei_access.write_blob(blob_file, mei)


def main():
    """script entry point"""
    opts = parse_command_line()
    update(opts)


if __name__ == "__main__":
    main()
