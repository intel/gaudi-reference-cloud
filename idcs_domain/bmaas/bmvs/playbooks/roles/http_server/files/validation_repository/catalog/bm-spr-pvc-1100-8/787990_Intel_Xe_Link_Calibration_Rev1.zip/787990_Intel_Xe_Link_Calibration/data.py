#
# Copyright (C) 2022 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""
I/O support for table-based data

This module leverages CSV for reading and writing table-based data and
adds additional support for tables with aligned columns separated by
vertical bar (|) characters and for lists of records where each line
indicates the field name separated from its value by a colon (:) and
records are separated by a blank line.

The primary interfaces are the Writer and Reader classes, although other
classes provide replacements for csv-type interfaces and could be used
on their own.

When called as a script, this tool can be used to convert between file
formats.
"""

import argparse
import collections
import csv
import sys

sys.dont_write_bytecode = True

import valid_version


# Tool details
SUMMARY="Convert table-based data"
DETAIL="""Convert table-based data from one format to another"""

# Automatically register CSV dialects
csv.register_dialect('csv', delimiter=',', lineterminator='\n')
csv.register_dialect('spaces', delimiter=' ', lineterminator='\n')
csv.register_dialect('tabs', delimiter='\t', lineterminator='\n')

# Default output format: if not "table" or "list", treat as dialect
default_format = "csv"

# Duplicate all output here: if set, should support file API
duplicate_output = None


class TableWriter:
    """
    Replacement for csv.writer that generates a table with a header and
    aligned columns surrounded by vertical bar (|) characters. All data
    is written via the writerow() method. The first row written is the
    header, which determines the column widths and should be padded with
    spaces as needed.
    """

    def __init__(self, file, **kwargs):
        """
        Initialize a new TableWriter object

        file: output file, must support file API
        kwargs: if no_header is specified and set, suppress header,
        otherwise ignored (for compability with csv.writer)
        """
        self.file = file
        self.writerow = self._write_heading
        self.show_header = not kwargs.get('no_header')

    def _write_heading(self, row):
        """Write first row of data as headings"""
        self.headings = row
        if self.show_header:
            line = ["|"]
            for heading in row:
                line += [heading, "|"]
            print(*line, file=self.file)
            line = "|"
            for heading in row:
                line += "=" * (len(heading) + 2) + "|"
            print(line, file=self.file)
        self.writerow = self._write_row

    def _write_row(self, row):
        """Write data row"""
        line = ["|"]
        for heading, value in zip(self.headings, row):
            line += [str(value).ljust(len(heading)), "|"]
        print(*line, file=self.file)


class ListWriter:
    """
    Replacement for csv.writer that generates multi-line records which
    contain field name and value separated by colon (:) characters. All
    data is written via the writerow() method. The first row written
    defines the field names.
    """

    def __init__(self, file, **kwargs):
        """
        Initialize a new ListWriter object

        file: output file, must support file API
        kwargs: ignored, for compability with csv.writer
        """
        self.file = file
        self.writerow = self._write_heading

    def _write_heading(self, row):
        """Consume first row of data as headings"""
        self.headings = row
        self.writerow = self._write_row

    def _write_row(self, row):
        """Write data record"""
        for heading, value in zip(self.headings, row):
            print(heading, ":", value, file=self.file)
        print(file=self.file)


class CsvWriter:
    """
    Wrapper for csv.writer that optionally suppresses the first (header)
    row.
    """

    def __init__(self, file, **kwargs):
        """
        Initialize a new ListWriter object

        file: output file, must support file API
        kwargs: if no_header is specified and set, suppress header,
        otherwise pass on to csv.writer
        """
        kwargs.setdefault('no_header', False)
        self.show_rows = not kwargs.pop('no_header')
        self.csv = csv.writer(file, **kwargs)

    def writerow(self, row):
        """Write data record or header"""
        if self.show_rows:
            self.csv.writerow(row)
        self.show_rows = True


class DualWriter:
    """
    Provide a replacement for csv.writer that merely wraps two objects
    with the same interface and forwards writerow requests to both.
    """

    def __init__(self, writer1, writer2):
        """
        Initialize a new DualWriter object

        writer1, writer2 : csv.writer-like objects, must have writerow method
        """
        self.writer1 = writer1
        self.writer2 = writer2

    def writerow(self, row):
        """Write row using both contained writers"""
        self.writer1.writerow(row)
        self.writer2.writerow(row)


class Writer:
    """
    Create and encapsulate a csv-like table writer. If duplicate_output is
    set, create a second copy of the writer using it.
    """

    def __init__(self, file, *args, format=None, no_header=False):
        """
        Initialize a new Writer object

        file: output file, must support file API
        args: all headers, can be space-padded for "table" format
        format: format to use: "table", "list", or csv dialect name
        """
        self.file = file
        self.format = format if format is not None else default_format
        if self.format == "table":
            writer_type = TableWriter
        elif self.format == "list":
            writer_type = ListWriter
        else:
            writer_type = CsvWriter

        writer1 = writer_type(file,
                              dialect=self.format,
                              no_header=no_header)
        if duplicate_output and duplicate_output != file:
            writer2 = writer_type(duplicate_output,
                                  dialect=self.format,
                                  no_header=no_header)
            self.writer = DualWriter(writer1, writer2)
        else:
            self.writer = writer1

        headings = args if self.format=="table" else [a.strip() for a in args]
        self.writer.writerow(headings)

    def add_row(self, *args):
        """
        Emit a row of output

        args: entire row of data
        """
        self.writer.writerow(args)
        self.file.flush()
        if duplicate_output and duplicate_output != self.file:
            duplicate_output.flush()


class TableReader:
    """
    Replacement for csv.reader that parses a table with a header and
    columns surrounded by vertical bar (|) characters.
    """

    def __init__(self, file):
        """
        Initialize a TableReader object

        file: input file, must support file API
        """
        self.file = file

    def __iter__(self):
        """Return iterator for TableReader"""
        self.read = self._read_heading
        return self

    def __next__(self):
        """Return next iteration of TableReader"""
        return self.read(self.file)

    def _read_heading(self, file):
        """Return headings"""
        self.headings = []
        for line in file:
            self.headings = [field.strip() for field in line.split("|")[1:-1]]
            break
        if not self.headings:
            raise StopIteration
        self.read = self._read_first
        return self.headings

    def _read_first(self, file):
        """Skip heading separator and return first row"""
        marker = ""
        for line in file:
            marker = line.strip()
            break
        if not marker.startswith("|="):
            raise StopIteration
        self.read = self._read_row
        return self._read_row(file)

    def _read_row(self, file):
        """Return a row of data"""
        row = []
        for line in file:
            row = [field.strip() for field in line.split("|")[1:-1]]
            break
        if not row:
            raise StopIteration
        return row


class ListReader:
    """
    Replacement for csv.reader that parses a table of multi-line records
    of field name and value separated by colon (:) characters.
    """

    def __init__(self, file):
        """
        Initialize a ListReader object

        file: input file, must support file API
        """
        self.file = file

    def __iter__(self):
        """Return iterator for ListReader"""
        self.read = self._read_heading
        return self

    def __next__(self):
        """Return next iteration of ListReader"""
        return self.read(self.file)

    def _read_heading(self, file):
        """Return headings and save first data set for next read"""
        self.headings = []
        self.first_row = []
        for line in file:
            field_name, data = [field.strip() for field in line.split(":", 1)]
            self.headings.append(field_name)
            self.first_row.append(data)
        if not self.headings:
            raise StopIteration
        self.read = self._read_first_record
        return self.headings

    def _read_first_record(self, file):
        """Return first data set"""
        if not self.first_row:
            raise StopIteration
        self.read = self._read_record
        return self.first_row

    def _read_record(self, file):
        """Return next data set"""
        headings = []
        row = []
        for line in file:
            field_name, data = [field.strip() for field in line.split(":", 1)]
            headings.append(field_name)
            row.append(data)
        if not row or headings != self.headings:
            raise StopIteration
        return row


class Reader:
    """
    Create and encapsulate a csv-like table reader.
    """

    def __init__(self, file):
        """
        Initialize a Reader object, automatically detecting the data
        type by parsing the first line

        file: input file, must support file API
        """
        self.file = file
        self.reader = set()
        self.next_line = file.readline()
        comma = self.next_line.find(",")
        colon = self.next_line.find(":")
        tab = self.next_line.find("\t")
        quote = self.next_line[:1] == '"'
        bar = self.next_line[:1] == "|"
        if bar:
            self.reader = TableReader(self)
        elif not quote and colon > 0 and (comma < 0 or comma > colon):
            self.reader = ListReader(self)
        elif tab > 0 and (comma < 0 or comma > tab):
            self.reader = csv.reader(self, dialect='tabs')
        elif comma < 0:
            self.reader = csv.reader(self, dialect='spaces')
        else:
            self.reader = csv.reader(self, dialect='csv')

    def __iter__(self):
        """Reader iterator to pass file data to parser"""
        return self

    def __next__(self):
        """Return next iteration of data to parser"""
        line, self.next_line = self.next_line, self.file.readline()
        if line.strip() and line[:1] != "#":
            return line
        else:
            raise StopIteration

    def data(self, record_type=dict):
        """
        Return entire data file as a list of mapped header to data
        fields
        """
        headings = None
        table = []
        for row in self.reader:
            if headings:
                table.append(record_type(zip(headings, row)))
            else:
                headings = row
        return table


def parse_command_line():
    """Parse command line for this tool and return options"""

    input_file = argparse.FileType('r', encoding='utf-8-sig')
    output_file = argparse.FileType('w')
    help_format = lambda prog: argparse.ArgumentDefaultsHelpFormatter(prog,
            max_help_position=40)

    version = valid_version.Version(__file__, throw_on_error=False)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument("input",
                        type=input_file,
                        default="-",
                        help="input file to convert")

    parser.add_argument("output",
                        type=output_file,
                        default="-",
                        nargs="?",
                        help="output file to produce")

    parser.add_argument("-v", "--version",
                        action="version",
                        version=str(version),
                        help="report version and exit")

    parser.add_argument("-f", "--format",
                        choices=["csv","spaces","table","unix","tabs","list"],
                        default="csv",
                        metavar="FORMAT",
                        help="output format: csv/spaces/table/unix/tabs/list")

    parser.add_argument("-n", "--no-header",
                        action="store_true",
                        help="suppress header on output")

    opts = parser.parse_args()

    return opts


def main():
    """Entry point: perform all script actions"""
    opts = parse_command_line()
    rows = Reader(opts.input).data(collections.OrderedDict)
    if rows:
        widths = (len(key) for key in rows[0].keys())
        for row in rows:
            widths = (max(w,len(v)) for w,v in zip(widths,row.values()))
        keys = (key.ljust(w) for key,w in zip(rows[0].keys(),widths))
        outfile = Writer(opts.output,
                         *keys,
                         format=opts.format,
                         no_header=opts.no_header)
        for row in rows:
            outfile.add_row(*row.values())


if __name__ == "__main__":
    main()
