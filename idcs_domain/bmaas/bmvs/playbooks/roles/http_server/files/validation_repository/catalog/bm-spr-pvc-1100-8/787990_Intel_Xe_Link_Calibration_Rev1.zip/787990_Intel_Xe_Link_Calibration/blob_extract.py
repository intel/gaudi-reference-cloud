#!/usr/bin/env python3

# Copyright (C) 2023 Intel Corporation
# SPDX-License-Identifier: MIT

#
# This module requires the 'igsc' tool be installed (and in the PATH) to
# validate data on PVC devices.
#
# As a program, this module validates and extracts PVC PSC/TXCAL blob data.
#
# As a library module, split_blob() validates and extracts PSC and TXCAL data
# from a blob (e.g., as returned by mei_access.existing_blob_data()), and
# get_file_data() uses it to collect PSC and TXCAL blobs from a set of files,
# returning the last valid data of each type encountered.
#

"""Extract PSC and/or TXCAL blob data from files or devices"""

import argparse
from pathlib import Path
import struct
import sys

# Prevent Python from creating cache files for local libraries:
sys.dont_write_bytecode = True

import mei_access


#
# CONSTANTS
#

# Tool details
SUMMARY = "Extract PSC/TXCAL blob data from PVC devices or files"
DETAIL = """
Collect PSC/TXCAL blob data from the PSC SPI region on PVC devices (first
verifying that they are all identical) and verify the PSC and TXCAL data
contained within. If one or more BLOBs are specified, query PSC/TXCAL data
from them as well. If --psc-bin and/or --txcal-bin is specified, extract the
corresponding data to a file (from the last valid instance queried).
"""

# Full set of BLOB data as returned by NVMEM object
NVMEM_BLOB_SIZE = 2 ** 20 + 8192

#
# PSC BLOB CONTENTS
#

# Corresponds to string data "PSCB"
PSCBIN_MAGIC_NUMBER = 0x42435350

# Supported PSC versions
PSCBIN_VERSION_NULL = 0
PSCBIN_VERSION_MIN = 2
PSCBIN_VERSION_MAX = 3

MAX_SOCKET_IDS = 32
MAX_INIS = MAX_SOCKET_IDS * 2

PSC_HDR_FMT = "<" + "I" * 16 + "IIII" * MAX_INIS + "I" * 8
PSC_HDR_SIZE = struct.calcsize(PSC_HDR_FMT)

#
# TXCAL BLOB CONTENTS
#

# Corresponds to string data "Xe Tx Cal Blob\0\0"
TXCAL_BLOB_MAGIC = (0x54206558, 0x61432078, 0x6c42206c, 0x0000626f)

# Supported TXCAL version
TXCAL_VERSION_CURRENT = 1

TXCAL_HDR_FMT = "<IIIIIIIIIIII"
TXCAL_SETTINGS_FMT = "<QHHHHHHHH"
TXCAL_HDR_SIZE = struct.calcsize(TXCAL_HDR_FMT)
TXCAL_SETTINGS_SIZE = struct.calcsize(TXCAL_SETTINGS_FMT)


#
# CLASSES
#

class CommonBlobOpts:
    """
    Common blob extraction options. To specify options directly, inherit this
    class or instantiate an object and override specific properties.
    """
    # Options used but not set by parse_command_line(), set by module users:
    no_psc = False
    no_txcal = False
    # Options set but not used by parse_command_line():
    keep_going = False
    quiet = False

    def __init__(self, **args):
        """Instantiate an options object with optional overrides"""
        self.__dict__.update(args)


class BlobExtractOpts(CommonBlobOpts):
    """
    Options for blob extract. To specify options directly, inherit this class
    or instantiate an object and override specific properties.
    """
    # Options set but not used by parse_command_line():
    device = []
    files = []
    # Options set and used by parse_command_line():
    psc_bin = None
    txcal_bin = None


#
# FUNCTIONS
#

def parse_command_line(defaults=BlobExtractOpts):
    """Parse command line options"""

    def help_format(prog):
        """preferred help format"""
        return argparse.HelpFormatter(prog, max_help_position=40)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
        "files",
        type=argparse.FileType('rb'),
        metavar="BLOB",
        nargs="*",
        help="PSC, TXCAL, or combined blob"
    )

    parser.add_argument(
        '-d', '--device',
        type=mei_access.device_identifier,
        action='append',
        metavar="DEV",
        help="device (MEI device or fabric ID) to query (default: all)"
    )

    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help="suppress some informational messages"
    )

    parser.add_argument(
        '--keep-going',
        action='store_true',
        help="do not stop on errors"
    )

    parser.add_argument(
        '--psc-bin',
        type=Path,
        metavar="FILE",
        default=defaults.psc_bin,
        help="PSC binary file to extract"
    )

    parser.add_argument(
        '--txcal-bin',
        type=Path,
        metavar="FILE",
        default=defaults.txcal_bin,
        help="TXCAL binary file to extract"
    )

    opts = parser.parse_args()

    opts.no_psc = defaults.no_psc
    opts.no_txcal = defaults.no_txcal

    return opts


def crc32c(byte_data, crc=0):
    """Compute CRC32C for an array of bytes"""

    crc32c_polynomial = 0x82f63b78

    for each_byte in byte_data:
        crc ^= each_byte
        for _ in range(8):
            crc = (crc >> 1) ^ (crc32c_polynomial if crc & 1 else 0)

    return crc


def extract_psc_blob(blob_data, opts=BlobExtractOpts):
    """extract PSC blob from blob data"""
    if len(blob_data) < PSC_HDR_SIZE:
        return b''

    header = struct.unpack(PSC_HDR_FMT, blob_data[:PSC_HDR_SIZE])
    hdr_magic, hdr_format = header[:2]
    data_size = header[9]
    hdr_crc = header[-1]

    if hdr_magic != PSCBIN_MAGIC_NUMBER:
        return b''

    computed_hdr_crc = crc32c(struct.pack(PSC_HDR_FMT[:-1], *header[:-1]))

    if hdr_crc != computed_hdr_crc:
        print("ERROR: PSC CRC error")
        if not opts.keep_going:
            sys.exit(10)
        return b''

    supported_version = PSCBIN_VERSION_MIN <= hdr_format <= PSCBIN_VERSION_MAX

    if hdr_format != PSCBIN_VERSION_NULL and not supported_version:
        print(f"ERROR: unsupported PSC version {hdr_format}")
        if not opts.keep_going:
            sys.exit(11)
        return b''

    if len(blob_data) < PSC_HDR_SIZE + data_size:
        print("ERROR: missing PSC blob data")
        if not opts.keep_going:
            sys.exit(12)
        return b''

    return blob_data[:PSC_HDR_SIZE + data_size]


def extract_txcal_blob(blob_data, opts=BlobExtractOpts):
    """extract TXCAL blob from blob data"""
    if len(blob_data) < TXCAL_HDR_SIZE:
        return b''

    hdr_data = struct.unpack(TXCAL_HDR_FMT, blob_data[:TXCAL_HDR_SIZE])
    hdr_magic = hdr_data[:4]
    hdr_format = hdr_data[4]
    size, count, data_crc, hdr_crc = hdr_data[-4:]
    data_size = count * TXCAL_SETTINGS_SIZE
    txcal_data = blob_data[TXCAL_HDR_SIZE:]

    if hdr_magic != TXCAL_BLOB_MAGIC:
        return b''

    computed_hdr_crc = crc32c(struct.pack(TXCAL_HDR_FMT[:-1], *hdr_data[:-1]))
    computed_data_crc = crc32c(txcal_data[:data_size])

    if hdr_crc != computed_hdr_crc or data_crc != computed_data_crc:
        print("ERROR: TXCAL CRC error")
        if not opts.keep_going:
            sys.exit(20)
        return b''

    if hdr_format != TXCAL_VERSION_CURRENT:
        print(f"ERROR: unsupported TXCAL version {hdr_format}")
        if not opts.keep_going:
            sys.exit(21)
        return b''

    if size != TXCAL_HDR_SIZE + data_size or len(txcal_data) < data_size:
        print("ERROR: mismatched TXCAL size")
        if not opts.keep_going:
            sys.exit(22)
        return b''

    return blob_data[:size]


def split_blob(blob_data, opts=BlobExtractOpts):
    """extract and validate existing blob data"""

    # extract PSC blob, pad to 32-bit boundary if need be
    psc_blob = extract_psc_blob(blob_data, opts)
    if len(psc_blob) % 4:
        psc_blob += b'\x00' * (4 - (len(psc_blob) % 4))

    if psc_blob and not opts.quiet:
        print("PSC blob found in SPI")

    txcal_blob = extract_txcal_blob(blob_data[len(psc_blob):], opts)
    if txcal_blob and not opts.quiet:
        print("TXCAL blob found in SPI")

    if opts.no_psc:
        psc_blob = b''

    if opts.no_txcal:
        txcal_blob = b''

    return psc_blob, txcal_blob


def get_file_data(files, opts=BlobExtractOpts):
    """extract PSC and TXCAL blob data from opts.files"""
    psc_blob = txcal_blob = b''

    # if multiple files contain the same data, the later one wins
    for file in files:
        blob_data = file.read()

        # skip header if reading entire NVMEM data file
        if len(blob_data) >= NVMEM_BLOB_SIZE:
            blob_data = blob_data[8192:]

        psc_file, txcal_file = split_blob(blob_data, opts)

        if psc_file:
            psc_blob = psc_file
            if not opts.quiet:
                print(f"PSC blob found in {file.name}")

        if txcal_file:
            txcal_blob = txcal_file
            if not opts.quiet:
                print(f"TXCAL blob found in {file.name}")

    return psc_blob, txcal_blob


def validate_extract(opts=BlobExtractOpts):
    """validate and optionally extract blob data"""
    if opts.files:
        psc_blob, txcal_blob = get_file_data(opts.files, opts)
    else:
        spi = mei_access.get_spi_map(opts.device)
        blob_data = mei_access.existing_blob_data(spi, opts.keep_going)
        psc_blob, txcal_blob = split_blob(blob_data, opts)

    if psc_blob:
        print(f"Valid PSC blob found, size {len(psc_blob)}")
        if opts.psc_bin:
            print(f"Writing PSC blob to {opts.psc_bin}")
            opts.psc_bin.write_bytes(psc_blob)

    if txcal_blob:
        print(f"Valid TXCAL blob found, size {len(txcal_blob)}")
        if opts.txcal_bin:
            print(f"Writing TXCAL blob to {opts.txcal_bin}")
            opts.txcal_bin.write_bytes(txcal_blob)


def main():
    """script entry point"""
    opts = parse_command_line()
    validate_extract(opts)


if __name__ == "__main__":
    main()
