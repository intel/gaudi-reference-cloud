#!/usr/bin/env python3

#
# Copyright (C) 2022-2023 Intel Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

"""Collect coarse calibration data"""

import argparse
import datetime
import os
import os.path
import statistics
import sys
import time

sys.dont_write_bytecode = True

import valid_version
import data
import iaf
import out


# Tool details
SUMMARY="Collect coarse calibration data for TX tuning"
DETAIL="""
Only initially-connected ports will be calibrated. 'coarse' calibration
data files should be passed to select_gains.py to find valid DC gains.
"""

# number of lanes is constant for now, may support other options eventually
NUM_LANES = 4

# when no errors have been detected, rather than reporting a 0 BER rate report
# a BER that is a negative log and lower than 1 / bitcount -- currently divide
# by 10 although arguably an error model should dictate this factor (e.g., a
# gaussian model might suggest 1.2)
BER_GOOD_LANE_DIVISOR = 10

# BER to report when a lane is down: 0.5 is "statistically" correct (and is a
# negative log to facilitate error graphing), 1.0 could also have been used
BER_LANE_DOWN = 0.5

# Number of seconds to wait for link state changes
link_wait_timeout = 90

# Argument limits
MAX_DELAY = 60
# 10 minutes: the driver will stop waiting anyway
MAX_TIMEOUT = 600
# 2.5 minutes: lanes this bad are generally unusable anyway
MAX_RECOMMENDED_TIMEOUT = 150
# 5.25 hours: more than enough to positively measure a BER of 1e-15:
MAX_DWELL = 18900
# 3.5 minutes: more than enough to positively measure a BER of 1e-13:
MAX_RECOMMENDED_DWELL = 210


#
# SUMMARY PORT LISTING
#


def port_list(ports, paths, file, **kwargs):
    def dump(port):
        if not port:
            return "UNKNOWN"
        return f"{port.ident} ({os.path.join(*port.path.parts[-3:])})"

    table = data.Writer(file,
                        "txPort" + " " * 38,
                        "width",
                        "health  ",
                        "rxPort" + " " * 38,
                        **kwargs)

    for path in paths:
        port = ports[path]
        table.add_row(dump(port),
                      port.tx_width,
                      port.health,
                      dump(port.neighbor))


#
# PER-LANE BER COLLECTION
#


def read_start_lcbs(port_list):
    for tx_port in port_list:
        rx_port = tx_port.neighbor
        rx_port.start_lcb = rx_port.lcb_ctrs()


def clear_start_lcbs(port_list):
    for tx_port in port_list:
        rx_port = tx_port.neighbor
        rx_port.start_lcb = rx_port.lcb_ctrs().zero()


def rx_ber_per_lane_25g(tx_port, rx_port, rx_lane):
    lcb_diffs = rx_port.lcb_ctrs() - rx_port.start_lcb

    nlanes = rx_port.rx_width
    lane_errors = lcb_diffs["CRC_ERR_LN" + str(rx_lane)]
    block_count = lcb_diffs["TOTAL_CRC_ERR"] + lcb_diffs["GOOD_LTP"]
    block_size = 1088 / nlanes

    # instead of reporting 0 BER, set numerator to 1 and increase
    # denominator by a predetermined factor
    if lane_errors < 1:
        lane_errors = 1
        block_count *= BER_GOOD_LANE_DIVISOR

    return lane_errors / (block_count * block_size) if block_count else 0


def rx_ber_per_port_25g(tx_port, rx_port):
    lcb_diffs = rx_port.lcb_ctrs() - rx_port.start_lcb

    port_errors = lcb_diffs["TOTAL_CRC_ERR"]
    block_count = lcb_diffs["TOTAL_CRC_ERR"] + lcb_diffs["GOOD_LTP"]
    block_size = 1088

    if port_errors < 1:
        port_errors = 1
        block_count *= BER_GOOD_LANE_DIVISOR

    return port_errors / (block_count * block_size) if block_count else 0


def rx_ber_53g(tx_port, rx_port, rx_lane):
    count_fields = ("GOOD_FECCW",
                    "FEC_CERR_1",
                    "FEC_CERR_2",
                    "FEC_CERR_3",
                    "FEC_CERR_4",
                    "FEC_CERR_5",
                    "FEC_CERR_6",
                    "FEC_CERR_7",
                    "FEC_CERR_8",
                    "FEC_UERR_CNT")
    fec_bits = {'F132' : 132 * 8, "F528" : 528 * 10, "F544" : 544 * 10}

    nlanes = rx_port.rx_width
    block_size = fec_bits.get(rx_port.fec_mode, 5120) / nlanes if nlanes else 0

    lcb_diffs = rx_port.lcb_ctrs() - rx_port.start_lcb

    lane_errors = lcb_diffs["FEC_ERR_LN" + str(rx_lane)]
    block_count = sum([lcb_diffs[f] for f in count_fields])

    # instead of reporting 0 BER, set numerator to 1 and increase
    # denominator by a predetermined factor
    if lane_errors < 1:
        lane_errors = 1
        block_count *= BER_GOOD_LANE_DIVISOR

    return lane_errors / (block_count * block_size) if block_count else 0


#
# TUNING TABLE SUPPORT
#


class Tuning:
    headings = [ "pass",
                 "txLane".ljust(iaf.LaneId.WIDTH),
                 "dcGain",
                 "txFirEhM1",
                 "txFirEh[0]",
                 "txFirEh[1]",
                 "txFirEh[2]",
                 "txFirEh[3]",
                 "txPmon",
                 "firIdx",
                 "sToUp",
                 "condMet",
                 "rxLane".ljust(iaf.LaneId.WIDTH),
                 "agc1Ctl",
                 "agcPeak4",
                 "agcTarg",
                 "ber     ",
                 "lmsSumErr",
                 "cntrChEst[0]",
                 "cntrChEst[1]",
                 "cntrChEst[2]",
                 "cntrChEst[3]",
                 "cntrChEst[4]",
                 "cdrIntg",
                 "rxPmon",
                 "speed" ]

    fields = [ f.strip() for f in headings ]

    @classmethod
    def row(cls,
            attempt,
            tx_id,
            tx_fir,
            tx_pmon,
            fir_idx,
            rx_id,
            up_at,
            is_ok,
            dc_gain,
            ber,
            eq_info,
            speed):
        ok = "Y" if is_ok else "N"
        specified = { "pass"     : attempt,
                      "txLane"   : tx_id,
                      "dcGain"   : dc_gain,
                      **tx_fir,
                      "txPmon"   : tx_pmon,
                      "firIdx"   : fir_idx,
                      "sToUp"    : up_at,
                      "condMet"  : ok,
                      "rxLane"   : rx_id,
                      "agcPeak4" : eq_info['agc1Peak'] / 4,
                      "ber"      : f"{ber:.3g}",
                      "rxPmon"   : eq_info['pmonUlvtFreq'],
                      "speed"    : speed }
        return [specified.get(f, eq_info.get(f, None)) for f in cls.fields]


#
# TUNING INFORMATION REPORTS
#


tx_fir_fields = ("txFirEhM1",
                 "txFirEh[0]",
                 "txFirEh[1]",
                 "txFirEh[2]",
                 "txFirEh[3]")


# use real tuning data from devices by default
def get_real_tuning_data(tx_port, tx_lane, rx_port, up_at):
    def get_tx_eq_data(tx_port, tx_lane):
        eqinfo = tx_port.eq_info()
        fir = { field : eqinfo[field][tx_lane] for field in tx_fir_fields }
        return fir, eqinfo.pmonUlvtFreq[tx_lane]

    class LaneAccessor:
        def __init__(self, obj, lane):
            self.obj = obj
            self.lane = lane
        def __getattr__(self, name):
            return self.obj.__getattr__(name)[self.lane]
        def __getitem__(self, name):
            return self.obj[name][self.lane]
        def get(self, name, default=None):
            return self.obj.get(name, [default] * 4)[self.lane]

    tx_id = tx_port.lane_id(tx_lane)
    fir_idx = tx_port.get_tx_tuning(tx_lane)
    rx_lane = iaf.LaneId(swizzle[tx_id]).lane_num()
    rx_id = rx_port.lane_id(rx_lane)

    eq_info = LaneAccessor(rx_port.eq_info(), rx_lane)
    tx_fir, tx_pmon = get_tx_eq_data(tx_port, tx_lane)

    # when a lane is down, use predetermined calculated BER
    if tx_port.fec_mode == "NONE":
        if tx_port.crc_mode == "pLn":
            ber = rx_ber_per_lane_25g(tx_port, rx_port, rx_lane) if up_at >= 0 else BER_LANE_DOWN
        else:
            ber = rx_ber_per_port_25g(tx_port, rx_port) if up_at >= 0 else BER_LANE_DOWN
    else:
        ber = rx_ber_53g(tx_port, rx_port, rx_lane) if up_at >= 0 else BER_LANE_DOWN

    return tx_id, tx_fir, tx_pmon, fir_idx, rx_id, up_at, ber, eq_info


get_tuning_data = get_real_tuning_data


def ratio(numerator, denominator):
    """Safe division returning 0 if denominator <= 0"""
    return numerator / denominator if denominator > 0 else 0


# complete table of tuning information
def show_tuning(table, attempt, tx_port, tx_lane, rx_port, up_at):
    (tx_id,
     tx_fir,
     tx_pmon,
     fir_idx,
     rx_id,
     up_at,
     ber,
     eq_info) = get_tuning_data(tx_port, tx_lane, rx_port, up_at)

    up = up_at >= 0
    dc_gain = sum(tx_fir.values())
    agc = eq_info['agc1Ctl']
    p4t = ratio(eq_info['agc1Peak'], 4 * eq_info['agcTarg'])
    d12 = ratio(eq_info['cntrChEst[1]'], eq_info['cntrChEst[2]'])
    d32 = ratio(eq_info['cntrChEst[3]'], eq_info['cntrChEst[2]'])
    d13 = ratio(eq_info['cntrChEst[1]'], eq_info['cntrChEst[3]'])

    ok = (up
          and agc in tx_port.rules['agc_range']
          and tx_port.rules['p4t_low'] <= p4t <= tx_port.rules['p4t_high']
          and tx_port.rules['ber_low'] <= ber <= tx_port.rules['ber_high']
          and tx_port.rules['d12_low'] <= d12 <= tx_port.rules['d12_high']
          and tx_port.rules['d32_low'] <= d32 <= tx_port.rules['d32_high']
          and tx_port.rules['d13_low'] <= d13 <= tx_port.rules['d13_high'])

    table.add_row(*Tuning.row(attempt,
                              tx_id,
                              tx_fir,
                              tx_pmon,
                              fir_idx,
                              rx_id,
                              up_at,
                              ok,
                              dc_gain,
                              ber,
                              eq_info,
                              tx_port.speed or "DOWN"))

    return up, dc_gain, fir_idx


#
# SET/RESTORE TUNINGS FOR A RANGE OF PORTS
#


def set_tunings(tx_lane, ports_to_test, tuning_selection):
    for tx_port in ports_to_test:
        tx_port.disable_pair()

    start_time = time.time()
    while time.time() - start_time < link_wait_timeout:
        for tx_port in ports_to_test:
            rx_port = tx_port.neighbor
            if tx_port.update().phy_state != "DISABLED":
                break
            if rx_port.update().phy_state != "DISABLED":
                break
        else:
            break
        time.sleep(1)

    for tx_port in ports_to_test:
        tx_port.set_tx_tuning(tx_lane, tuning_selection(tx_port, tx_lane))

    for tx_port in ports_to_test:
        tx_port.enable_pair()
        tx_port.up_at = 0

    # Make sure connections to be tested have an opportunity to come up
    start_time = time.time()
    while time.time() - start_time < link_wait_timeout:
        for tx_port in ports_to_test:
            rx_port = tx_port.neighbor
            if tx_port.update().down():
                break
            if rx_port.update().down():
                break
            tx_port.up_at = int(time.time() - start_time)
        else:
            break
        time.sleep(1)


def restore_tunings(tx_ports, tx_lane, path_list):
    for path in path_list:
        tx_ports[path].disable_pair()

    for path in path_list:
        tx_port = tx_ports[path]
        tx_port.set_tx_tuning(tx_lane, tx_port.initial_tuning[tx_lane])

    start_time = time.time()
    while time.time() - start_time < link_wait_timeout:
        for path in path_list:
            tx_port = tx_ports[path]
            rx_port = tx_port.neighbor
            if tx_port.update().phy_state != "DISABLED":
                break
            if rx_port.update().phy_state != "DISABLED":
                break
        else:
            break
        time.sleep(1)

    for path in path_list:
        tx_ports[path].enable_pair()


#
# COMMAND LINE PARSING
#


def parse_command_line():
    """Parse command line options"""
    global link_wait_timeout

    def ask(opts, *warning):
        """Produce a warning and check whether it is OK to continue"""
        out.warn(*warning)
        if opts.yes:
            out.warn("continuing anyway since --yes specified")
        else:
            answer = input("Continue anyway? ")
            if answer[:1].lower() != "y":
                print("...operation aborted...", file=opts.log)
                out.error("aborted")

    def int_in_range(low, high):
        """type check for int value within a range"""
        def argument(s):
            val = int(s)
            if val < low or val > high:
                out.warn(f"argument value {val} not in range [{low},{high}]")
                raise ValueError("out of range")
            return val
        return argument

    def try_open(file_type, file_name):
        """Try to open a file by name, error out if not possible"""
        try:
            file = file_type(file_name)
        except:
            out.error(f"Could not open file {file_name}, check permissions")

        return file

    input_file = argparse.FileType('r', encoding='utf-8-sig')
    output_file = argparse.FileType('w')

    help_format = lambda prog: argparse.HelpFormatter(prog,
                                                      max_help_position=40)

    version = valid_version.Version(__file__)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
            "-v", "--version",
            action="version",
            version=str(version),
            help="report version and exit")

    parser.add_argument(
            "-d", "--device",
            metavar="DEVICE",
            action="append",
            help="limit calibration to device[:subdevice[:port]]")

    parser.add_argument(
            "-s", "--system",
            metavar="SYSTEM",
            help="automatically name output files with system name")

    parser.add_argument(
            "-f", "--format",
            choices=["csv", "spaces", "table", "unix", "tabs", "list"],
            default="csv",
            metavar="FORMAT",
            help="format: csv/spaces/table/unix/tabs/list (default csv)")

    parser.add_argument(
            "-n", "--no-timestamp",
            action="store_true",
            help="do not timestamp system name")

    parser.add_argument(
            "-y", "--yes",
            action="store_true",
            help="do not ask for confirmations")

    timeout = link_wait_timeout
    parser.add_argument(
            "--link-wait-timeout",
            type=int_in_range(0, MAX_TIMEOUT),
            default=timeout,
            metavar="SECONDS",
            help=f"seconds to wait for link to come up (default {timeout})")

    parser.add_argument(
            "--delay",
            type=int_in_range(0, MAX_DELAY),
            default=0,
            metavar="SECONDS",
            help="seconds delay before gathering BER (default 0)")

    parser.add_argument(
            "--dwell",
            type=int_in_range(0, MAX_DWELL),
            default=3,
            metavar="SECONDS",
            help="seconds to gather BER data (default 3)")

    parser.add_argument(
            "--lane",
            type=int_in_range(0, 7),
            metavar="LANE",
            help="limit tuning one lane (0-3 forward, 4-7 reverse)")

    parser.add_argument(
            "--accurate-starting-ber",
            action="store_true",
            help="find accurate BER of starting point")

    parser.add_argument(
            "--log",
            type=output_file,
            metavar="FILE",
            help="log results to file (default coarse.log)")

    parser.add_argument(
            "--output-start",
            type=output_file,
            metavar="FILE",
            help="output starting tuning data to file (default start.FORMAT)")

    parser.add_argument(
            "--output-coarse",
            type=output_file,
            metavar="FILE",
            help="output coarse tuning data to file (default coarse.FORMAT)")

    parser.add_argument(
            "--output-rules",
            type=output_file,
            metavar="FILE",
            help="output channel condition rules")

    parser.add_argument(
            "--output-lane-map",
            type=output_file,
            metavar="FILE",
            help="output lane mapping to file")

    parser.add_argument(
            "--output-fir-table",
            type=output_file,
            metavar="FILE",
            help="output SERDES FW TX FIR mappings to file")

    parser.add_argument(
            "--override-lane-map",
            type=input_file,
            metavar="FILE",
            help="override lane mapping from file")

    parser.add_argument(
            "--verbose",
            action="store_true",
            help="report additional detail")

    opts = parser.parse_args()

    out.pr("coarse calibration data requested")

    if opts.lane is not None and (opts.lane < 0 or opts.lane >= 8):
        out.error("--lane must be in range 0-7")

    if opts.system:
        basename = opts.system + "_"
        if not opts.no_timestamp:
            basename += datetime.datetime.utcnow().strftime("%Y%m%d%H%M_")

        if not opts.log:
            opts.log = try_open(output_file,
                                basename + "coarse.log")

        if not opts.output_start:
            opts.output_start = try_open(output_file,
                                         basename + "start." + opts.format)

        if not opts.output_coarse:
            opts.output_coarse = try_open(output_file,
                                          basename + "coarse." + opts.format)

        if opts.verbose:
            if not opts.output_rules:
                opts.output_rules = try_open(output_file,
                                             basename + "rules." + opts.format)
            if not opts.output_lane_map:
                opts.output_lane_map = try_open(output_file,
                                                basename + "lanemap." + opts.format)
            if not opts.output_fir_table:
                opts.output_fir_table = try_open(output_file,
                                                 basename + "firtable." + opts.format)
    else:
        if not opts.log:
            opts.log = try_open(output_file, "coarse.log")
        if not opts.output_start:
            opts.output_start = try_open(output_file, "start." + opts.format)
        if not opts.output_coarse:
            opts.output_coarse = try_open(output_file, "coarse." + opts.format)

    # Recognize defaulted opts.device and convert it into a list
    if not opts.device:
        opts.device = ["all:all:all"]
        if opts.verbose:
            out.pr("Implicitly selecting all devices")

    for bad in [d for d in opts.device if len(d.split(":")) > 3]:
        good = ":".join(bad.split(":")[:3])
        out.warn("--device selects to port level only, treating",
                 bad,
                 "as",
                 good)

    data.default_format = opts.format
    link_wait_timeout = opts.link_wait_timeout
    iaf.verbose_reporting = opts.verbose

    print(f"Logging results to {opts.log.name}")

    print(f"{version.prog} version: {version}", file=opts.log)
    now = datetime.datetime.utcnow().strftime("%Y/%m/%d %H:%M")
    print(f"UTC time: {now}", file=opts.log)
    print(f"Log file: {opts.log.name}", file=opts.log)

    print(file=opts.log)
    print("Output files:", file=opts.log)
    print(f"Data format: {opts.format}", file=opts.log)
    print(f"Start data: {opts.output_start.name}", file=opts.log)
    print(f"Coarse data: {opts.output_coarse.name}", file=opts.log)
    if opts.output_rules:
        print(f"Rules data: {opts.output_rules.name}", file=opts.log)
    if opts.output_lane_map:
        print(f"Lane map: {opts.output_lane_map.name}", file=opts.log)
    if opts.output_fir_table:
        print(f"FIR table: {opts.output_fir_table.name}", file=opts.log)
    print(file=opts.log)

    print("Measurement settings:", file=opts.log)
    if opts.lane:
        print(f"Calibrating only lane: {opts.lane}", file=opts.log)
    print(f"Link timeout: {opts.link_wait_timeout}", file=opts.log)
    print(f"Delay: {opts.delay}", file=opts.log)
    use_check = "USED" if opts.accurate_starting_ber else "NOT used"
    print(f"Dwell: {opts.dwell} ({use_check} for starting BER)", file=opts.log)

    print(file=opts.log)
    print("OS settings:", file=opts.log)
    print(f"Release: {os.uname().release}", file=opts.log)
    print(f"Version: {os.uname().version}", file=opts.log)
    print(file=opts.log)
    print("IAF module parameters:", file=opts.log)
    try:
        for parameter,value in sorted(iaf.module_parameters().items()):
            print(f"{parameter}: {value}", file=opts.log)
    except:
        print(" error reading module parameters, check permissions", file=opts.log)
    print(file=opts.log)

    # Additional argument validation
    if opts.dwell > MAX_RECOMMENDED_DWELL:
        ask(opts,
            f"very long data collection time ({opts.dwell}s),",
            f"recommended maximum: {MAX_RECOMMENDED_DWELL}")
    if link_wait_timeout > MAX_RECOMMENDED_TIMEOUT:
        ask(opts,
            f"very long link timeout ({link_wait_timeout}s),",
            f"recommended maximum: {MAX_RECOMMENDED_TIMEOUT}")

    return opts


#
# ANALYZE SYSTEM AND CALIBRATE ALL SELECTED PORTS
#


def calibrate_coarse(opts):
    global swizzle

    #
    # SYSTEM ANALYSIS
    #

    # configure system as needed (will auto-restore on exit)
    iaf.disable_flapping_detection(opts.verbose and sys.stdout)
    iaf.disable_routing(opts.verbose and sys.stdout)

    # analyze fabric
    out.pr("\nAnalyzing fabric")
    devs = iaf.get_devs()

    firmware = " ".join(iaf.Subdevice.fw_versions)
    print(f"IAF firmware version(s): {firmware}", file=opts.log)
    print(file=opts.log)

    # determine which ports are being requested
    requested_ports = {}
    for sel in [d.split(":") for d in opts.device]:
        d = sel[0]
        s = "sd." + sel[1] if sel[1:] else "sd.all"
        p = sel[2] if sel[2:] else "all"
        for devname, dev in devs.items():
            if d in [devname, dev.fabric_id, "all"]:
                for sdname, sd in dev.sds.items():
                    if s in [sdname, "sd.all"]:
                        for pname, port in sd.ports.items():
                            if p in [pname, "all"]:
                                requested_ports[port.path] = port

    # if provided, limit requested ports based on lane map overrides
    if opts.override_lane_map:
        lane_map = data.Reader(opts.override_lane_map).data()
        iaf.Port.filter_list(requested_ports,
                             {row['txLane'] for row in lane_map})
    else:
        lane_map = []

    #
    # TEST SUPPORT FOR SCRIPT DEVELOPMENT
    #

    # If test overrides are requested, read input table(s) and override
    # functions/options as needed
    test_override_files = os.environ.get("CALIBRATE_OVERRIDE_DATA")

    if test_override_files:
        global get_tuning_data

        out.pr("\nCALIBRATE_OVERRIDE_DATA SET, USING TEST OVERRIDES!\n")
        override_data = {}
        col_fn = {"txLane" : str,
                       "condMet" : str,
                       "rxLane" : str,
                       "agcPeak4" : float,
                       "ber" : float}

        for file in [open(f) for f in test_override_files.split(",")]:
            for row in data.Reader(file).data():
                idx = row['txLane'] + "," + row['firIdx']
                override_data.setdefault(idx, {'pass':0, 'data':[]})
                d = override_data[idx]['data']
                d.append({f : col_fn.get(f, int)(v) for f, v in row.items()})

        if override_data:
            # suppress unnecessary delays
            global link_wait_timeout

            link_wait_timeout = 0
            opts.delay = 0
            opts.dwell = 0

            # suppress unnecessary behavior
            iaf.Port.block_enable_control = True

            # further limit requested ports based on available test data
            iaf.Port.filter_list(requested_ports,
                                 {idx.split(",")[0]
                                  for idx in override_data.keys()})

            # provide access to override data
            def get_test_data(tx_id, tx_fir):
                override = override_data.get(tx_id + "," + str(tx_fir))
                if override:
                    this_pass = override['pass']
                    override['pass'] = this_pass + 1 if this_pass + 1 < len(override['data']) else 0
                    return override['data'][this_pass]

                if tx_fir > 35 and (tx_fir - 35) % 11:
                    mid = (tx_fir - 35) % 11
                    right = mid // 2
                    left = mid - right
                    override = override_data.get(tx_id + "," + str(35 + 11 * ((tx_fir - 35) // 11)))
                    if override:
                        interpolated_data = {f : v for f, v in override['data'][0].items()}
                        interpolated_data["txFirEh[1]"] -= left
                        interpolated_data["txFirEh[2]"] += mid
                        interpolated_data["txFirEh[3]"] -= right
                        return interpolated_data

                return None

            # replacement get_tuning_data function
            def get_phony_tuning_data(tx_port, tx_lane, rx_port, up_at):
                tx_id = tx_port.lane_id(tx_lane)
                fir_idx = tx_port.get_tx_tuning(tx_lane)

                eq_info = get_test_data(tx_id, fir_idx)
                if eq_info:
                    tx_fir = {field:eq_info[field] for field in tx_fir_fields}
                    tx_pmon = eq_info['txPmon']
                    rx_id = rx_port.lane_id(iaf.LaneId(swizzle[tx_id]).lane_num())
                    up_at = eq_info['sToUp']
                    ber = eq_info['ber']
                    eq_info['pmonUlvtFreq'] = eq_info['rxPmon']
                    eq_info['agc1Peak'] = eq_info['agcPeak4'] * 4

                    return tx_id, tx_fir, tx_pmon, fir_idx, rx_id, up_at, ber, eq_info
                else:
                    return get_real_tuning_data(tx_port, tx_lane, rx_port, up_at)

            # replace tuning data query function, preferring phony
            # override data
            get_tuning_data = get_phony_tuning_data

    #
    # VALIDATE REQUESTED PORTS ARE SUPPORTED AND SPLIT REQUESTED PORTS
    # INTO TWO LISTS
    #

    tx_port_paths = []
    unused_port_paths = []
    tx_ports = {}

    for path in sorted(requested_ports.keys()):
        tx_port = requested_ports[path]
        # Currently only support healthy 53G and 25G ports with all four lanes
        # working
        if (tx_port.up()
                and tx_port.neighbor
                and (tx_port.speed == "53G" or tx_port.speed == "25G")
                and tx_port.tx_width == 4):
            tx_port_paths.append(path)
            tx_ports[path] = tx_port
        else:
            unused_port_paths.append(path)

    if unused_port_paths:
        out.warn("The following ports cannot be tuned now:")
        port_list(requested_ports,
                  unused_port_paths,
                  sys.stderr,
                  format="table")
        out.warn("If needed, use --device to filter to working devices/ports")
        out.error("Stopping...")

    if tx_port_paths:
        out.pr("Tuning the following ports:")
        port_list(requested_ports,
                  tx_port_paths,
                  sys.stdout,
                  format="table")
        print("Ports being analyzed:", file=opts.log)
        print(file=opts.log)
        port_list(requested_ports,
                  tx_port_paths,
                  opts.log,
                  format="table")
    else:
        out.error("No ports selected for tuning")

    tune_first = []
    tune_second = []
    rx_ports = {}

    for path in tx_port_paths:
        if path in rx_ports:
            tune_second.append(path)
        else:
            tune_first.append(path)
        rx_ports[tx_ports[path].neighbor.path] = tx_ports[path].neighbor

    #
    # DETERMINE LANE/SWIZZLE MAP
    #

    out.pr("\nConstructing lane map")

    swizzle = {}

    for row in lane_map:
        swizzle[row["txLane"]] = row["rxLane"]

    for path, tx_port in tx_ports.items():
        tx_lanes_available = set(range(NUM_LANES))
        rx_lanes_available = set(range(NUM_LANES))
        for rx_lane, tx_lane in enumerate(tx_port.neighbor.rx_swizzle):
            if tx_lane is not None:
                tx_id = tx_port.lane_id(tx_lane)
                rx_id = tx_port.neighbor.lane_id(rx_lane)
                if tx_id not in swizzle:
                    swizzle[tx_id] = rx_id
                elif swizzle[tx_id] != rx_id:
                    out.lane_warn(tx_port,
                                  tx_lane,
                                  "lane mapped to",
                                  swizzle[tx_id],
                                  "but hw indicates",
                                  rx_id)
                    swizzle[tx_id] = tx_port.neighbor.lane_id(iaf.LaneId(swizzle[tx_id]).lane_num())
                    out.lane_warn(tx_port,
                                  tx_lane,
                                  "remapped to",
                                  swizzle[tx_id],
                                  "instead")
                tx_lanes_available.discard(tx_lane)
                rx_lanes_available.discard(iaf.LaneId(swizzle[tx_id]).lane_num())
        for tx_lane in list(tx_lanes_available):
            tx_id = tx_port.lane_id(tx_lane)
            if tx_id in swizzle:
                tx_lanes_available.discard(tx_lane)
                rx_lanes_available.discard(iaf.LaneId(swizzle[tx_id]).lane_num())
        for tx_lane in tx_lanes_available:
            rx_lane = rx_lanes_available.pop()
            rx_id = tx_port.neighbor.lane_id(rx_lane)
            swizzle[tx_port.lane_id(tx_lane)] = rx_id
            out.lane_warn(tx_port,
                          tx_lane,
                          "remote lane mapping not detected, guessing",
                          rx_id)

    if opts.output_lane_map:
        table = data.Writer(opts.output_lane_map,
                            "txLane".ljust(iaf.LaneId.WIDTH),
                            "rxLane".ljust(iaf.LaneId.WIDTH))
        for path in tx_port_paths:
            tx_port = tx_ports[path]
            for tx_lane in range(NUM_LANES):
                tx_id = tx_port.lane_id(tx_lane)
                table.add_row(tx_id, swizzle[tx_id])

    #
    # IDENTIFY DC GAIN TO TX FIR TABLE MAPPINGS
    #

    dc_gain_table = {'53G': {16: range(35, 46),
                             17: range(46, 57),
                             18: range(57, 68),
                             19: range(68, 79),
                             20: range(79, 90),
                             21: range(90, 101),
                             22: range(101, 112),
                             23: range(112, 123),
                             24: range(123, 134),
                             25: range(134, 145),
                             26: range(145, 156),
                             27: range(156, 167),
                             28: range(167, 178),
                             29: range(178, 189),
                             30: range(189, 200),
                             32: range(200, 211),
                             34: range(211, 222),
                             36: range(222, 233),
                             38: range(233, 244),
                             40: range(244, 255)}}
    dc_gain_table['25G'] = dc_gain_table['53G']

    if opts.output_fir_table:
        table = data.Writer(opts.output_fir_table,
                            "speed",
                            "dcGain",
                            "low",
                            "high")

        for speed, rules in sorted(dc_gain_table.items()):
            for gain, rule in sorted(rules.items()):
                table.add_row(speed, gain, rule[0], rule[-1])

    dc_coarse = {}
    for speed, gain_table in dc_gain_table.items():
        dc_coarse[speed] = { g : r[0] for g, r in gain_table.items() }

    #
    # ESTABLISH RULES FOR AGC/CHEST/BER CONDITIONS
    #

    field_rules = {'53G': {'agc': {'low': 15.0, 'high': 127.0},
                                   'p4t': {'low': 0.90, 'high': 1.20},
                                   'ber': {'low': 0.00, 'high': 1e-5},
                                   'd12': {'low': 0.05, 'high': 0.35},
                                   'd32': {'low': 0.05, 'high': 0.35},
                                   'd13': {'low': 0.833, 'high': 1.20}}}

    field_rules['25G'] = field_rules['53G']

    if opts.output_rules:
        table = data.Writer(opts.output_rules,
                            "speed",
                            "field",
                            "low     ",
                            "high    ")

        for speed, rules in sorted(field_rules.items()):
            for field, rule in sorted(rules.items()):
                table.add_row(speed,
                              field,
                              f"{rule['low']:.3g}",
                              f"{rule['high']:.3g}")

    #
    # STARTING POINT FOR INITIAL BER CALCULATIONS
    #

    if opts.accurate_starting_ber:
        read_start_lcbs(tx_ports.values())
        time.sleep(opts.dwell)
    else:
        clear_start_lcbs(tx_ports.values())

    #
    # QUERY INITIAL STATUS FOR ALL LANES AND EXTEND PORT STRUCTURES FOR
    # LATER ANALYSES
    #

    out.pr("\nDetermining initial status")

    table = data.Writer(opts.output_start, *Tuning.headings)

    # looping is by port (all ports in sorted order) then lane number
    for path in tx_port_paths:
        tx_port = tx_ports[path]
        speed_rules = field_rules[tx_port.speed]
        tx_port.dc_coarse = dc_coarse[tx_port.speed]
        tx_port.dc_fine = dc_gain_table[tx_port.speed]
        tx_port.rules = {}

        tx_port.rules['agc_range'] = range(int(speed_rules['agc']['low']),
                                           int(speed_rules['agc']['high']) + 1)
        for field in ('p4t', 'ber', 'd12', 'd32', 'd13'):
            tx_port.rules[field + '_low'] = speed_rules[field]['low']
            tx_port.rules[field + '_high'] = speed_rules[field]['high']

        # per-lane initial tunings and valid coarse gains
        tx_port.initial_tuning = [0] * NUM_LANES
        tx_port.coarse = [{} for i in range(NUM_LANES)]

        rx_port = tx_port.neighbor
        for tx_lane in range(NUM_LANES):
            up, dc_gain, fir_idx = show_tuning(table,
                                               0,
                                               tx_port,
                                               tx_lane,
                                               rx_port,
                                               0)

            # save initial fir_indices
            tx_port.initial_tuning[tx_lane] = fir_idx

            # list gains to search in either direction for coarse tuning
            coarse_info = tx_port.coarse[tx_lane]
            all_gains = sorted(tx_port.dc_coarse.keys())
            gain_index = all_gains.index(dc_gain) if dc_gain in all_gains else len(all_gains) // 2
            coarse_info['higherGains'] = all_gains[gain_index:]
            coarse_info['lowerGains'] = list(reversed(all_gains[:gain_index]))

            # set initial search direction
            coarse_info['nextGain'] = 'higherGains'
            coarse_info['validGainDetected'] = False

    if opts.lane is None:
        selected_path_lists = [tune_first, tune_second]
        selected_lanes = range(NUM_LANES)
    elif opts.lane < 4:
        selected_path_lists = [tune_first]
        selected_lanes = [opts.lane]
    else:
        selected_path_lists = [tune_second]
        selected_lanes = [opts.lane - 4]
    step_count = len(selected_path_lists) * len(selected_lanes)

    #
    # PERFORM COARSE TUNING
    #
    out.pr("\nPerforming coarse tuning")
    table = data.Writer(opts.output_coarse, *Tuning.headings)

    # looping is by set (first/second), then lane number, then
    # repeatedly by port until all valid gains/lane are tried
    current_step = 0
    for path_list in selected_path_lists:
        for tx_lane in selected_lanes:
            out.pr(f"Completed {current_step}/{step_count} steps")
            current_step += 1
            more_gains_to_try = True
            while more_gains_to_try:
                more_gains_to_try = False

                # search through gains in alternating directions
                # finding current gain to try for each lane
                for path in path_list:
                    tx_port = tx_ports[path]
                    coarse_info = tx_port.coarse[tx_lane]
                    coarse_info['currentGain'] = None
                    coarse_info['currentList'] = None
                    this_direction = coarse_info['nextGain']
                    if this_direction:
                        if this_direction == 'higherGains':
                            other_direction = 'lowerGains'
                        else:
                            other_direction = 'higherGains'
                        this_way = coarse_info[this_direction]
                        other_way = coarse_info[other_direction]
                        if this_way:
                            coarse_info['currentGain'] = this_way.pop(0)
                            coarse_info['currentList'] = this_direction
                        elif other_way:
                            coarse_info['currentGain'] = other_way.pop(0)
                            coarse_info['currentList'] = other_direction
                        if other_way:
                            coarse_info['nextGain'] = other_direction
                        elif this_way:
                            # coarse_info['nextGain'] is already
                            # this_direction
                            pass
                        else:
                            # no more gains to try after the current one
                            coarse_info['nextGain'] = None

                ports_to_test = []
                for path in path_list:
                    tx_port = tx_ports[path]
                    coarse_info = tx_port.coarse[tx_lane]
                    dc_gain = coarse_info['currentGain']
                    if dc_gain:
                        ports_to_test.append(tx_port)

                set_tunings(tx_lane, ports_to_test, lambda p, l:p.dc_coarse[p.coarse[l]['currentGain']])

                # starting point for rough BER calculations
                time.sleep(opts.delay)
                read_start_lcbs(ports_to_test)
                time.sleep(opts.dwell)

                for tx_port in ports_to_test:
                    rx_port = tx_port.neighbor
                    up_at = tx_port.up_at if rx_port.up() else -1

                    up, dc_gain, fir_idx = show_tuning(table,
                                                       0,
                                                       tx_port,
                                                       tx_lane,
                                                       rx_port,
                                                       up_at)

                    # if link comes up, add gain to the list, if not
                    # truncate the current list
                    coarse_info = tx_port.coarse[tx_lane]
                    if up:
                        coarse_info['validGainDetected'] = True
                    elif coarse_info['validGainDetected']:
                        coarse_info[coarse_info['currentList']] = []
                        this_direction = coarse_info['nextGain']
                        if this_direction == coarse_info['currentList']:
                            other_direction = 'lowerGains' if this_direction == 'higherGains' else 'higherGains'
                            coarse_info['nextGain'] = other_direction if coarse_info[other_direction] else None

                    # keep going as long as any port contains
                    # unchecked gains
                    if coarse_info['lowerGains'] or coarse_info['higherGains']:
                        more_gains_to_try = True

            # restore original FIR values before moving to next lane
            restore_tunings(tx_ports, tx_lane, path_list)

    out.pr(f"Completed {current_step}/{step_count} steps")


def main():
    opts = parse_command_line()
    if iaf.dla_enabled():
        out.warn("DLA is enabled and must be disabled.")
        out.warn("Restart the driver with the firmware_roption bit 13 set which disables DLA")
        out.warn("Using default settings the firmware_roption would be 0x40002201")
        out.error("Stopping...")
    calibrate_coarse(opts)


if __name__ == "__main__":
    main()
