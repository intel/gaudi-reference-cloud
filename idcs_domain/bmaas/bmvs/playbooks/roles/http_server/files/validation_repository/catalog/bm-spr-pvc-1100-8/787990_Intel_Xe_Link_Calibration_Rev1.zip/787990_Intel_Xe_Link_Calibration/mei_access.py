#!/usr/bin/env python3

# Copyright (C) 2023 Intel Corporation
# SPDX-License-Identifier: MIT

#
# This module requires the 'igsc' tool be installed (and in the PATH) to
# function.
#
# As a program, this module reports all PVC MEI devices ('igsc list-devices')
# and identifies the corresponding IAF fabric IDs and the location of the
# 'nvmem' SYSFS entry for the .PSC region (i.e., region 13, where IAF PSC and
# TXCAL data are stored).
#
# As a library module, get_spi_map() provides a mapping of MEI device names to
# NVMEM locations, existing_blob_data() uses this mapping to validate that all
# data is the same and extract the combined blob, and write_blob() writes a
# combined blob to a given MEI device.
#

"""Access PSC and TXCAL blob data via MEI/SPI interface"""

import argparse
from pathlib import Path
import re
from subprocess import run, CalledProcessError, PIPE
import sys


#
# CONSTANTS
#

# Tool details
SUMMARY = "Query PVC MEI/SPI locations"
DETAIL = """
Query MEI device names and corresponding fabric IDs and SPI nvmem locations
for PVC PSC/TXCAL blob data.
"""

# Device tree
DEV_TOP = Path("/sys/devices")

# SPI name
MTD_PSC_NAME = re.compile(r".*\.PSC")

# MEI access
MEI_DEVICE_NAME = re.compile(r"(/dev/)?mei\d+")
MEI_PATH = Path("/dev")
MEI_LIST_CMD = ["igsc", "list-devices"]
MEI_LIST_OUT = re.compile(r"(?m)^Device \[\d+\] '/dev/(\w+)':")
MEI_WRITE_CMD = ["igsc", "iaf", "update", "--device"]


#
# FUNCTIONS
#

def device_identifier(name):
    """MEI device or fabric ID"""
    if MEI_DEVICE_NAME.fullmatch(name):
        return Path(name).name
    return int(name, 16)


def parse_command_line():
    """Parse command line options"""

    def help_format(prog):
        """preferred help format"""
        return argparse.HelpFormatter(prog, max_help_position=40)

    parser = argparse.ArgumentParser(description=SUMMARY,
                                     epilog=DETAIL,
                                     formatter_class=help_format)

    parser.add_argument(
        '-d', '--device',
        type=device_identifier,
        action='append',
        metavar="DEV",
        help="device (MEI device or fabric ID) to query (default: all)"
    )

    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help="do not print header"
    )

    return parser.parse_args()


def device_node(mei_device):
    """Locate device node for an MEI device"""
    # throw ValueError if rglob does not return exactly one match
    node, = [*DEV_TOP.rglob(mei_device)]
    while node.match('mei*') or node.match('i915.mei*'):
        node = node.parent
    return node


def psc_mtd(node):
    """Find PSC mtd# file for a device node"""
    # throw ValueError if glob does not return exactly one match
    spi_node, = [*node.glob('i915[._-]spi*/mtd')]
    names = [n for n in spi_node.rglob('name') if n.is_file()]
    # throw ValueError if search does not return exactly one match
    psc, = [n.parent for n in names if MTD_PSC_NAME.fullmatch(n.read_text().strip())]
    return Path('/dev') / psc.name


def fabric_id(node):
    """Find fabric ID for a device node"""
    # throw ValueError if glob does not return exactly one match
    iaf_node, = [*node.glob('i915.iaf.*')] + [*node.glob('iaf.*')]
    fabric_id_node = iaf_node / 'iaf_fabric_id'
    # throw OSError or ValueError on error
    return int(fabric_id_node.read_text(), 16)


def get_mei_devices():
    """Get list of all MEI devices"""
    try:
        result = run(MEI_LIST_CMD, stdout=PIPE, stderr=PIPE, check=True)
        output = result.stdout.decode()
        devices = [i.group(1) for i in MEI_LIST_OUT.finditer(output)]
    except OSError as err:
        print(f"ERROR: IGSC process failure: {err}", file=sys.stderr)
        print("Do you have root/sudo permissions?", file=sys.stderr)
        sys.exit(30)
    except CalledProcessError as err:
        print(f"ERROR: IGSC process returned error: {err.returncode}", file=sys.stderr)
        print(f"IGSC stderr:\n---\n{err.stderr}\n---", file=sys.stderr)
        sys.exit(31)
    except (AttributeError, IndexError):
        print("ERROR: IGSC process returned invalid data", file=sys.stderr)
        sys.exit(32)
    return devices


def get_spi_map(devices=None):
    """Get map of MEI devices to SPI nvmem"""
    spi = {}
    try:
        for mei in get_mei_devices():
            node = device_node(mei)
            fid = fabric_id(node)
            # if set, devices specifies MEI devices and/or fabric IDs
            if not devices or mei in devices or fid in devices:
                spi[mei] = psc_mtd(node)
    except ValueError:
        print("ERROR: no unique MEI/device/fid/nvmem mapping", file=sys.stderr)
        sys.exit(51)
    except OSError as err:
        print(f"ERROR: file access error: {err}", file=sys.stderr)
        print("Do you have root/sudo permissions?", file=sys.stderr)
        sys.exit(52)

    return spi


def existing_blob_data(spi, keep_going=False):
    """extract and validate existing blob data"""
    blob_data = b''
    for nvmem in spi.values():
        if blob_data:
            if blob_data != nvmem.read_bytes():
                print("ERROR: PSCBIN data not all the same", file=sys.stderr)
                if not keep_going:
                    sys.exit(40)
        else:
            blob_data = nvmem.read_bytes()

    # skip NVMEM header
    return blob_data[8192:]


def write_blob(blob_file, mei):
    """Write blob to MEI device"""
    try:
        command = [*MEI_WRITE_CMD, MEI_PATH / mei, "--image", blob_file.name]
        run(command, check=True)
    except OSError as err:
        print(f"ERROR: IGSC update failure: {err}", file=sys.stderr)
        print("Is igsc in your PATH?", file=sys.stderr)
    except CalledProcessError as err:
        print(f"ERROR: IGSC update returned error: {err.returncode}", file=sys.stderr)
        print("Do you root/sudo permissions?", file=sys.stderr)


def query(devices=None, quiet=False):
    """Query MEI devices"""
    if not quiet:
        print("MEI device Fabric ID  NVMEM path")
        print("---------- ---------- ----------")
    spi = get_spi_map(devices)
    for mei, nvmem in spi.items():
        print(f"{MEI_PATH / mei!s:10} {fabric_id(device_node(mei)):#010x} {nvmem}")
    if not existing_blob_data(spi):
        print("No SPI data found")


def main():
    """script entry point"""
    opts = parse_command_line()
    query(opts.device, opts.quiet)


if __name__ == "__main__":
    main()
