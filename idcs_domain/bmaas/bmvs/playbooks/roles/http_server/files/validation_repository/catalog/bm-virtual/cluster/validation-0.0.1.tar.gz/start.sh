#!/bin/bash -e

echo "starting bm-virtual cluster validation"
#Insert bm-virtual specific validation commands here
printenv
sleep 5
echo "end of bm-virtual cluster validation"
